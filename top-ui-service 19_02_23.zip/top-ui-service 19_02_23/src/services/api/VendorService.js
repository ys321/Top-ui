import { topApiClient } from "../topApiClient";

const headers = {
  "Content-type": "application/json",
};

const VendorService = {
  create: async function (data) {
    return await topApiClient.post(`/vendor`, data, headers);
  },
  get: async function (id) {
    return await topApiClient.get(`/vendor/${id}`);
  },
  update: async function (id, data) {
    const headers = {
      "Content-type": "multipart/form-data",
    };
    return await topApiClient.patch(`/vendor/${id}`, data, headers);
  },
  remove: async function (id) {
    return await topApiClient.delete(`/vendor/${id}`);
  },
  getAll: async function () {
    return await topApiClient.get("/vendors");
  },
  getByCodeNo: async function (code) {
    return await topApiClient.get(`/vendors?code=${code}`);
  },

  VendorTypeService: {
    getAll: async function () {
      return await topApiClient.get(`/vendor-types`);
    },
    create: async function (data) {
      return await topApiClient.post(`/vendor-type`, data, headers);
    },
    update: async function (id, data) {
      return await topApiClient.patch(`/vendor-type/${id}`, data, headers);
    },
    remove: async function (id) {
      return topApiClient.delete(`/vendor-type/${id}`);
    },
  },
  VendorCategoryLink: {
    getAll: async function (vendor, data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.get(
        `/vendor-categories/${vendor}`,
        data,
        headers
      );
    },
    update: async function (category, data) {
    const headers = {
      "Content-type": "application/json",
      };
      return await topApiClient.patch(
        `/category-vendor-link/${category}`,
        data,
        headers
      );
    },
    remove: async function (vendor, data) {
      const headers = {
        "Content-Type": "application/json",
      };
      return await topApiClient.delete(`/category-vendor-link/${vendor}`, {
        data: JSON.stringify(data),
        headers,
      });
    },
  },
};

const ProductUnlinkService = {
  remove: async (vendor_id, product_id) => {
    return await topApiClient.delete(
      `vendor/${vendor_id}/product/${product_id}/unlink`
    );
  },
};

const VendorBankServices = {
  create: async (data) => {
    return await topApiClient.post("/vendor-bank", data, headers);
  },

  update: async (vendor, data) => {
    return await topApiClient.patch(
      `/vendor/vendor-bank/${vendor.bank_info.id}`,
      data,
      headers
    );
  },

  remove: async (vendor) => {
    return await topApiClient.delete(`/vendor-bank/${vendor.bank_info.id}`);
  },

  get: async (vendor) => {
    return await topApiClient.get(`/vendor-bank/${vendor.bank_info.id}`);
  },

  getAll: async (vendor_id) => {
    return await topApiClient.get(`/vendor-banks/${vendor_id}`);
  },
};

const ProductListbyVendor = {
  getAll: async function (id) {
    return await topApiClient.get(`/vendor/${id}/products`);
  },
};

export {
  VendorService,
  VendorBankServices,
  ProductListbyVendor,
  ProductUnlinkService,
};
