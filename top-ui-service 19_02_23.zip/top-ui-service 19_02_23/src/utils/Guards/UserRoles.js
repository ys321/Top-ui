export const UserRoles = {
    TOP_ADMIN : 'top_admin',
    TOP_EMPLOYEE : 'top_employee'
}