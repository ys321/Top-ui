import { Button } from "@mui/joy";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import TOPButton from "src/components/Button/TopButton";
import {
  addEventListeners,
  removeEventListeners,
} from "./util/eventListenerUtil";

export const TimeoutLogic = () => {
  const [isWarningModalOpen, setWarningModalOpen] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    const createTimeout1 = () =>
      setTimeout(() => {
        setWarningModalOpen(true);
      }, 1500000);

    const createTimeout2 = () =>
      setTimeout(() => {
        // Implement a sign out function here
        localStorage.clear();
        window.location.href = "/login";
        setWarningModalOpen(false);
      }, 2000000);

    const listener = () => {
      if (!isWarningModalOpen) {
        clearTimeout(timeout);
        timeout = createTimeout1();
      }
    };

    // Initialization
    let timeout = isWarningModalOpen ? createTimeout2() : createTimeout1();
    addEventListeners(listener);

    // Cleanup
    return () => {
      removeEventListeners(listener);
      clearTimeout(timeout);
    };
  }, [isWarningModalOpen]);

  const hideTimeOutDialog = () => {
    isWarningModalOpen(false);
  };

  const onLogOffCall = () => {
    // Implement your logout functionality here, e.g. clear the users login cache or hit your signout server
    localStorage.clear();
    window.location.href = "/login";
  };
  return (
    <div>
      {isWarningModalOpen && (
        <Dialog
          open={isWarningModalOpen}
          onClose={() => {
            hideTimeOutDialog();
          }}
        >
          <DialogTitle>Session Timeout</DialogTitle>
          <DialogContent>
            <div>
              You're being timed out due to inactivity. Please choose to stay
              signed in or to logoff. Otherwise, you will be logged off
              automatically
            </div>
          </DialogContent>
          <DialogActions>
            <Button variant="soft" color="danger" onClick={onLogOffCall}>
              Log Off
            </Button>
            <Button
              variant="soft"
              color="primary"
              onClick={() => {
                setWarningModalOpen(false);
              }}
            >
              Stay Logged In
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </div>
  );
};
