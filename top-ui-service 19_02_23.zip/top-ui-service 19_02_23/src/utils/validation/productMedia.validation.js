import * as yup from "yup";
import { mixed } from "yup"

// const SUPPORTED_FORMATS = ["image/jpg", "image/jpeg", "image/png"];
// const FILE_SIZE = 1

// const FILE_SIZE = 500000;
// const SUPPORTED_FORMATS = null;

const productMediaValidationSchema = yup.object().shape({
    image: mixed()
    .test("required", "You need to provide a file", (file) => {
      // return file && file.size <-- u can use this if you don't want to allow empty files to be uploaded;
      if (file) return true;
      return false;
    })
    .test("fileSize", "The file is too large", (file) => {
      //if u want to allow only certain file sizes
      return file && file.size <= 1;
    })
    // image: yup
    //   .mixed()
    //   .required("A file is required")
    //   .test(
    //     "fileSize",
    //     "File too large",
    //     value => value && value.size <= FILE_SIZE
    //   )
    //   .test(
    //     "fileFormat",
    //     "Unsupported Format",
    //     value => value && SUPPORTED_FORMATS.includes(value.type)
    //   )




    // .test({
    //   message: `File too big, can't exceed ${MAX_FILE_SIZE}`,
    //   test: (file) => {
    //     const isValid = file?.size < MAX_FILE_SIZE;
    //     return isValid;
    //   }
    // })
    // image: yup.mixed()
    //     .required('Image is required')
    //     // .test("required", "image is required", value => value.length > 0),
    //     .test('fileType', 'Unsupported File Format', function (value) {
    //         const SUPPORTED_FORMATS = ['image/jpg', 'image/jpeg', 'image/png'];
    //         return SUPPORTED_FORMATS.includes(value)
    //     })
    //     .test('fileSize', "File Size is too large", value => {
    //         const sizeInBytes = 500000;//0.5MB
    //         return value <= sizeInBytes;
    //     })

    // .test("fileSize", "File Size is too large", (value) => {
    //   return value.length && value[0].size <= 5242880;
    // })
    // .test("fileType", "Unsupported File Format", (value) => {
    //         return value.length && ["image/jpeg", "image/png", "image/jpg"].includes(value[0].type)
    //     }


});


export { productMediaValidationSchema };