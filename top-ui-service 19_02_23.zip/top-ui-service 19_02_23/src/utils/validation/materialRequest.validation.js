import * as yup from "yup";

const materialRequestValidationSchema = yup.object().shape({
  po_number: yup.string().required("po no is required"),
  purchase_order_status: yup.string().required("status is required"),
  branch: yup.string().required("business location is required"),
});

export { materialRequestValidationSchema };
