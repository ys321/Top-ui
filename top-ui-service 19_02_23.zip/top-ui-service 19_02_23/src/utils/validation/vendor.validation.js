import * as yup from "yup";

const vendorFormValidationSchema = yup.object().shape({
  code: yup.string(),
  name: yup
    .string()
    .required("location name is required")
    .min(2, "name should be at least 2 character long")
    .max(50, "name should not be more than 50 character"),

  address: yup
    .string()
    .max(255, "address should not be more than 255 characters"),
  phone: yup
    .number()
    .typeError("Phone must be a number")
    .required("phone field is required.")
    .min(10),
  email: yup.string().email(),
  city : yup.string().required("city is required"),
  vendor_type: yup.string().required("vendor Type is Required"),
});

const productLinkbyVendorValidationSchema = yup.object().shape({
  product: yup.string().required("product is required"),
});

export { vendorFormValidationSchema, productLinkbyVendorValidationSchema };
