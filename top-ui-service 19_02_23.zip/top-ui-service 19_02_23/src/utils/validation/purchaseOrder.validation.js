import * as yup from "yup";

const purchaseOrderValidationSchema = yup.object().shape({
  po_number: yup
    .number()
    .typeError("Only number is Allowed")
    .required("Purchase Order No is Required"),
  vendor: yup.string().required("Vendor is required"),
  purchase_order_status: yup
    .string()
    .required("Purchase Order Status is required"),
});
const purchaseOrderItemValidationSchema = yup.object().shape({
  purchase_order_item: yup.string().required("Product is required"),
  ordered_qty: yup
    .number()
    .typeError("only Number")
    .required("Order quantity is required"),
  amount: yup
    .number()
    .typeError("only Number")
    .required("Product amount is required"),
});

export { purchaseOrderValidationSchema, purchaseOrderItemValidationSchema };
