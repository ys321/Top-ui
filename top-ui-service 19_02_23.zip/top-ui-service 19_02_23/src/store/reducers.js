import { combineReducers } from "redux";
import { alertReducer } from "./slices/alert.slice";
import { processReducer } from "./slices/process.slice";
import { userReducer } from "./slices/user.slice";

import { vendorReducers } from "./slices/vendor.slice";
import { productReducer } from "./slices/product.slice";
import { locationReducer } from "./slices/location.slice";
import { vendorTypeReducer } from "./slices/vendorType.slice";
import { cityReducer } from "./slices/city.slice";
import { categoryReducers } from "./slices/categoryReducer";

const rootReducer = combineReducers({
    user : userReducer,
    alert : alertReducer,
    process : processReducer,

    vendors: vendorReducers,
    vendor_type : vendorTypeReducer,
    city : cityReducer,
    locations : locationReducer,
    categories : categoryReducers,
    products: productReducer,
})

const RootState = typeof rootReducer;
export { RootState , rootReducer };