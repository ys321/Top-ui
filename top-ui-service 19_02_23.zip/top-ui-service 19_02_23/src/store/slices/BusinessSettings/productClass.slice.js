import { createAsyncThunk } from "@reduxjs/toolkit";
import { ProductClassService } from "src/services/api/ProductClass.service";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createProductClass = createAsyncThunk(
  "@productClass/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await ProductClassService.create(params.productClass);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Product Class",
            message: "Product Class Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Class Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateProductClass = createAsyncThunk(
  "@productClass/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.productClass.id) {
        const res = await ProductClassService.update(
          params.productClass.id,
          params.productClass
        );
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Product Class",
            message: "Product Class Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Class Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteProductClass = createAsyncThunk(
  "@productClass/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await ProductClassService.remove(params.pc.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Product Class",
            message: "Product Class Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Class Delete Failed",
            message: "Product Class Delete Failed",
          })
        );
      });
  }
);
