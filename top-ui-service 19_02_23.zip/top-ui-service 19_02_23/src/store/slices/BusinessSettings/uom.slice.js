import { createAsyncThunk } from "@reduxjs/toolkit";
import { UOMService } from "src/services/api/UOMService";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createUOM = createAsyncThunk(
  "@uom/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await UOMService.create(params.UOM);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Unit of Measurement",
            message: "Unit of Measurement Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Unit of Measurement Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateUOM = createAsyncThunk(
  "@uom/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.UOM.id) {
        const res = await UOMService.update(
          params.UOM.id,
          params.UOM
        );
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Unit of Measurement",
            message: "Unit of Measurement Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Unit of Measurement Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteUOM = createAsyncThunk(
  "@uom/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await UOMService.remove(params.pu.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Unit of Measurement",
            message: "Unit of Measurement Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Unit of Measurement Delete Failed",
            message: "Unit of Measurement Delete Failed",
          })
        );
      });
  }
);
