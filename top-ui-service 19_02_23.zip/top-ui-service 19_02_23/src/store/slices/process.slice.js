import { createSlice } from "@reduxjs/toolkit";


const initialState = {
    visible : false,
    open : false,
    loading : false
}

const processSlice = createSlice({
    name : 'process',
    initialState,
    reducers : {
        toggleProcess  :(state, {payload}) => {
            const { visible, open, loading } = payload;

            state.visible = visible || false;
            state.open = open || false;
            state.loading = loading || false;
        }
    }
});

export const { toggleProcess } = processSlice.actions;
export const processReducer = processSlice.reducer;