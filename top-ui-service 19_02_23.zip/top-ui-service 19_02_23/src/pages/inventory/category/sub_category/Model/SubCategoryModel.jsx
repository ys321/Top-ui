import {
  Grid,
  Modal,
  ModalClose,
  Sheet,
  Stack,
  TextField,
  Typography,
} from "@mui/joy";
import CancelButton from "src/components/Button/CancelButton";
import SaveButton from "src/components/Button/SaveButton";
import { EditText } from "src/components/EditText";

export default function SubCategoryModel({
  open,
  close,
  name,
  textFieldName,
  label,
  save,
  handleSubmit,
  defaultValue,
  errors,
  inputHandler,
  register,
}) {
  return (
    <>
      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={close}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            {name}
          </Typography>
          <Grid container>
            <Grid item xs={12} md={12} marginBottom={2}>
              {/* <TextField
                autoFocus
                fullWidth
                margin="dense"
                type={"text"}
                variant={"outlined"}
                id={textFieldName}
                name={textFieldName}
                label={label}
                defaultValue={defaultValue}
                {...register(textFieldName)}
                onChange={inputHandler}
                error={errors[textFieldName] ? true : false}
                helperText={errors[textFieldName]?.message}
              /> */}
              <EditText
                    name={textFieldName}
                    placeholder={label}
                    onChange={inputHandler}
                    value={textFieldName}
                    error={errors[textFieldName] ? true : false}
                    helperText={errors[textFieldName]?.message}
                  />
            </Grid>
            <Grid item xs={12} md={12}>
              <Stack
                direction={"row"}
                justifyContent={"end"}
                alignItems={"center"}
                spacing={2}
              >
                <SaveButton onClick={handleSubmit(save)} />
                <CancelButton onClick={close} />
              </Stack>
            </Grid>
          </Grid>
        </Sheet>
      </Modal>
    </>
  );
}
