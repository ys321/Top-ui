import { Box, Button, Stack,  Tooltip } from "@mui/joy";
import { useRef } from "react";
import { useDispatch } from "react-redux";
import { updateSubCategory } from "src/store/slices/category/subCategory.slice";
import { Grid } from "@mui/material";
import { Form, Formik } from "formik";
import { useQuery } from "@tanstack/react-query";
import { CategoryService } from "src/services/api/CategoryService";
import { QueryKeys } from "src/services/queryKey";
import { subCategorySchema } from "./useSubCategory";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import FormControl from "@mui/joy/FormControl";
import FormLabel from "@mui/joy/FormLabel";
import UpdateButton from "src/components/Button/UpdateButton";
import { EditText } from "src/components/EditText";

export default function SubCategoryForm({
  sub_category_id,
  productCategoryInputHandler,
  data,
  categoryID,
}) {
  const dispatch = useDispatch();

  const formRef = useRef();

  const { isLoading: subCategoryLoading, refetch } = useQuery(
    [QueryKeys.getSubCategory],
    async () => {
      return await CategoryService.SubCategoryService.get(sub_category_id);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        if (response) {
          // assign data to formik
          formRef?.current?.setValues({
            ...formRef?.current?.values,
          });
          if (response.data.name) {
            formRef.current.values.name = response.data.name;
          }
          formRef.current.values.description = response.data.description;
          formRef.current.values.identifier = response.data.identifier;
          if (response.data.image) {
            formRef.current.values.image = response.data.image;
          }

          formRef?.current?.setValues({
            ...formRef?.current?.values,
          });
        }
      },
      staleTime: 0,
    }
  );

  function saveSubCategory(values, categoryID) {
    dispatch(updateSubCategory({ values, sub_category_id, categoryID }))
      .unwrap()
      .then((res) => {
        setTimeout(() => {
          refetch();
        }, 500);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  return (
    <>
      <Formik
        initialValues={{
          name: "",
          description: "",
          identifier: "",
          image: "",
          category: categoryID,
        }}
        onSubmit={async (values) => {
          saveSubCategory(values);
        }}
        innerRef={formRef}
        validationSchema={subCategorySchema}
      >
        {({ values, errors, handleChange, setFieldValue }) => (
          <Form>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                {/* <TextField
                  margin="dense"
                  fullWidth
                  name="name"
                  label="Name"
                  variant="outlined"
                  value={values.name || ""}
                  onChange={handleChange}
                  error={errors.name ? true : false}
                  helperText={errors.name}
                /> */}
                <EditText
                  name="name"
                  placeholder="Name"
                  onChange={handleChange}
                  value={values.name}
                  error={errors.name}
                  helpertext={errors.name}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                {/* <TextField
                  margin="dense"
                  fullWidth
                  name="identifier"
                  label="External Identifier"
                  variant="outlined"
                  value={values.identifier || ""}
                  onChange={handleChange}
                  error={errors.identifier ? true : false}
                  helperText={errors.identifier}
                /> */}
                <EditText
                  name="identifier"
                  placeholder="External Identifier"
                  onChange={handleChange}
                  value={values.identifier}
                  error={errors.identifier}
                  helpertext={errors.identifier}
                />
              </Grid>
              <Grid item xs={12} md={12}>
                {/* <TextField
                  margin="dense"
                  fullWidth
                  name="description"
                  label="Description"
                  variant="outlined"
                  value={values.description || ""}
                  onChange={handleChange}
                  error={errors.description ? true : false}
                  helperText={errors.description}
                /> */}
                <EditText
                  name="description"
                  placeholder="Description"
                  onChange={handleChange}
                  value={values.description}
                  error={errors.description}
                  helpertext={errors.description}
                />
              </Grid>

              <Grid item xs={12} md={6}>
                  <FormControl>
                    <FormLabel>Image</FormLabel>
                    <Button
                      component="label"
                      variant="outlined"
                      starticon={<UploadFileIcon />}
                      size={"sm"}
                    >
                      Upload Image
                      <input
                        type="file"
                        accept="image/*"
                        hidden
                        onChange={(e) =>
                          setFieldValue("image", e.currentTarget.files[0])
                        }
                      />
                    </Button>
                  </FormControl>
                  <Box>{values?.image?.name}</Box>
                </Grid>
              <Grid item xs={12} md={12}>
                <Stack
                  direction={"row"}
                  justifyContent={"end"}
                  alignItems={"center"}
                >
      
                    <UpdateButton />
                </Stack>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    </>
  );
}
