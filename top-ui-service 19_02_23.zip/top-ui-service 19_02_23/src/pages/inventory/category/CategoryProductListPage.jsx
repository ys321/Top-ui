import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import { ProductService } from "src/services/api/ProductService";
import AddIcon from "@mui/icons-material/Add";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Box,
  Dialog,
  DialogActions,
  DialogContentText,
  DialogTitle,
  DialogContent,
  TextField,
  Paper,
  Menu,
  MenuItem,
  IconButton,
} from "@mui/material";
import { Link, Grid, Button } from "@mui/joy"
import { productValidationSchema } from "src/utils/validation/product.validation";

import SubCategoryAttributeDropDown from "src/components/Dropdown/SubCategoryAttributeDropDown";
import AutocompleteDropDown from "src/components/Dropdown/AutocomplateDropDown";

import _ from "lodash";

import { product_route_keys } from "src/utils/routes/route.keys";
import { CategoryService } from "src/services/api/CategoryService";
import { UOMService } from "src/services/api/UOMService";
import { ProductClassService } from "src/services/api/ProductClass.service";
import ToastAlert from "src/components/Toast/ToastAlert";
import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";

import { QueryKeys } from "src/services/queryKey";
import { EditText } from "src/components/EditText";
import SubmitButton from "src/components/Button/SubmitButton";
import { useCategoryProductListPage } from "./CategoryProductListPage/useCategoryProductListPage";

function CategoryProductListPage({ category }) {
  // const {
  //   register,
  //   handleSubmit,
  //   formState: { errors },
  //   reset,
  // } = useForm({
  //   resolver: yupResolver(productValidationSchema),
  // });
  const [open, showProductModel] = useState(false);

  const [products, setProducts] = useState([]);
  const [product, setProduct] = useState({});
  const [productWeight, setProductWeight] = useState({});
  const [productAttributes, setProductAttributes] = useState([]);

  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const [toastData, setToastData] = useState({
    visible: false,
    variant: "",
    title: "",
    sinceTime: "",
    body: "",
    image: "",
  });

  let specifications_string = ``;

  const { isLoading, data, error, refetch } = useQuery(
    [QueryKeys.getAllProducts],
    async () => {
      const reponse = await ProductService.getAll(
        { filter: `category=${category}` }
      );
      return reponse;
    },
    {
      onSuccess: (response) => {
        setProducts(response.data);
      },
      staleTime: 0,
    }
  );

  if (isLoading) {
    return <h1>Loading...</h1>;
  }

  function productValueHandler(e) {
    const { name, value } = e.target;
    setProduct({
      ...product,
      [name]: value,
    });
  }

  function productWeightAutocomplateHandler(option) {
    if (option) {
      setProductWeight({
        ...{ weight: { ...option } },
      });
    } else {
      setProductWeight({});
    }
  }

  function productWeightValueInputHandler(e) {
    const { value } = e.target;
    if (value) {
      productWeight.weight.value = value;
    } else {
      delete productWeight.weight.value;
    }
  }

  function IUOMValueHandler(e) {
    if (!_.isEmpty(e)) {
      setProduct({
        ...product,
        ...e,
      });
    } else delete product.iuom;
  }

  function PUOMValueHandler(e) {
    if (!_.isEmpty(e)) {
      setProduct({
        ...product,
        ...e,
      });
    } else delete product.puom;
  }

  function CategoryValueHandler(e) {
    if (!_.isEmpty(e)) {
      let category = _.get(e, "category");

      if (product.category !== category) {
        delete product.category;
        delete product.sub_category;
        setProduct({ ...product });
      }

      setProduct({
        ...product,
        ...e,
      });
    } else {
      delete product.category;
      setProduct({ ...product });
    }
  }

  function SubCategoryValueHandler(e) {
    if (!_.isEmpty(e)) {
      let subcategory = _.get(e, "sub_category");

      if (product.sub_category !== subcategory) {
        delete product.sub_category;
        setProductAttributes([]);
        setProduct({ ...product });
      }

      setProduct({
        ...product,
        ...e,
      });
    } else {
      delete product.sub_category;
      setProduct({ ...product });
    }
  }

  function ProductClassValueHandler(e) {
    if (!_.isEmpty(e)) {
      setProduct({
        ...product,
        ...e,
      });
    } else delete product.product_class;
  }

  function attributeHandler(e) {
    var isReplace = false;
    for (const each of productAttributes) {
      if (Object.keys(each).includes(Object.keys(e)[0])) {
        each[Object.keys(e)[0]] = e[Object.keys(e)[0]];
        isReplace = true;
        break;
      }
    }

    if (!isReplace) {
      productAttributes.push(e);
    }
  }

  const hideAndClearProductDailog = () => {
    showProductModel(false);
    reset();
    setProduct({});
  };
  function handleClose() {
    // close();
    // LocationRefetch();
    hideAndClearFloorDailog();
    refetch();
  }
  const {
    formik,
    errors,
    values,
    handleChange,
    handleSubmit,
    setFieldValue,
    isSubmitting,
    isSubmittingUpdate,
    setValues,
  } = useCategoryProductListPage({
    dialogHandler: handleClose,
  });
  useEffect(() => {
    setFieldValue('location', location.id)
  }, [location])


  // async function saveProduct() {
  //   product.specification = productAttributes;
  //   product.weight = productWeight.weight;

  //   await ProductService.create(product).then((response) => {
  //     if (response.status === 201) {
  //       products.push(response.data);
  //       setProduct(products);
  //       hideAndClearProductDailog();
  //       setProduct({});
  //       setToastData({
  //         visible: true,
  //         variant: "success",
  //         title: "Category Product",
  //         sinceTime: "",
  //         body: `Category Product is Addedd !`,
  //         image: "",
  //       });

  //       setTimeout(() => setToastData({ visible: false }), 3000);
  //     }
  //   });
  // }

  async function deleteCategoryProductHandler(product, index) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Category Product",
      description: `Are you sure want to delete ?`,
      confrimHandler: async function () {
        await ProductService.remove(product.id).then((response) => {
          if (response.status === 204) {
            products.pop(index);
            setConfirmationParams({ open: false });
            reset();
            refetch();
            setToastData({
              visible: true,
              variant: "success",
              title: "Category Product",
              sinceTime: "",
              body: `Category Product is Deleted !`,
              image: "",
            });

            setTimeout(() => setToastData({ visible: false }), 3000);
          }
        });
      },
    });
  }

  return (
    <>
      <div>
        <Dialog
          open={conformationParams.open}
          onClose={() => {
            setConfirmationParams({ open: false });
          }}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            {conformationParams.title}
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {conformationParams.description}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                setConfirmationParams({ open: false });
              }}
            >
              {conformationParams.cencelTitle}
            </Button>
            <Button onClick={conformationParams.confrimHandler} autoFocus>
              {conformationParams.confrimTitle}
            </Button>
          </DialogActions>
        </Dialog>
      </div>

      <Box style={{ padding: "10px" }}>
        <Grid container spacing={3} justifyContent={"flex-end"}>
          <Grid item>
            <Button
              style={{ marginRight: "10px" }}
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => {
                showProductModel(true);
              }}
            >
              Add New
            </Button>
          </Grid>
        </Grid>

        <Dialog
          maxWidth={"lg"}
          open={open}
          onClose={() => hideAndClearProductDailog()}
        >
          <DialogTitle>Product</DialogTitle>
          <DialogContent>
            <Box component={"form"} onSubmit={handleSubmit}>

              <Grid container spacing={2}>
                <Grid item xs={12} md={5}>
                  {/* <TextField
                    autoFocus
                    margin="dense"
                    id="name"
                    name="name"
                    label="Name of Product"
                    type="text"
                    fullWidth
                    variant="outlined"
                    {...register("name")}
                    onChange={(e) => productValueHandler(e)}
                    defaultValue={product.name}
                    error={errors.name ? true : false}
                    helperText={errors.name?.message}
                  /> */}
                  <EditText
                    name="name"
                    placeholder="Name of Product"
                    //   startDecorator={<Phone />}
                    onChange={handleChange}
                    value={product.name}
                    error={errors.name}
                    helpertext={errors.name}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <AutocompleteDropDown
                    name={"unit"}
                    id={"unit"}
                    label={"Product Weight Unit"}
                    dataFn={ProductService.ProductUnits.getAll}
                    valueParam={"unit"}
                    inputHandler={productWeightAutocomplateHandler}
                    validator={register}
                    errors={errors}
                  />
                </Grid>

                <Grid item xs={12} md={4}>
                  {/* <TextField
                    autoFocus
                    margin="dense"
                    id="product_unit_value"
                    name="product_unit_value"
                    label="Product Unit Value"
                    type="text"
                    fullWidth
                    variant="outlined"
                    {...register("product_unit_value")}
                    onChange={(e) => productWeightValueInputHandler(e)}
                    defaultValue={productWeight?.weight?.value}
                    disabled={_.isEmpty(productWeight)}
                    error={errors.product_unit_value ? true : false}
                    helperText={errors.product_unit_value?.message}
                    errors={errors}
                  /> */}
                  <EditText
                    name="product_unit_value"
                    placeholder="Product Unit Value"
                    onChange={handleChange}
                    value={values.product_unit_value}
                    error={errors.product_unit_value}
                    helpertext={errors.product_unit_value}
                  />
                </Grid>

                <Grid item xs={12} md={4}>
                  <AutocompleteDropDown
                    name={"category"}
                    id={"category"}
                    label={"Category"}
                    dataFn={CategoryService.getAll}
                    valueParam={"name"}
                    inputHandler={CategoryValueHandler}
                    validator={register}
                    errors={errors}
                  />
                </Grid>

                {product.category ? (
                  <>
                    <Grid item xs={12} md={4}>
                      <AutocompleteDropDown
                        name={"sub_category"}
                        id={"sub_category"}
                        label={"Sub Category"}
                        dataFn={CategoryService.SubCategoryService.getAll}
                        filterParam={product.category}
                        valueParam={"name"}
                        inputHandler={SubCategoryValueHandler}
                        validator={register}
                        errors={errors}
                      />
                    </Grid>
                  </>
                ) : (
                  <></>
                )}

                {product.sub_category ? (
                  <SubCategoryAttributeDropDown
                    subCategory={product.sub_category}
                    valueHandler={attributeHandler}
                  />
                ) : (
                  <></>
                )}

                <Grid item md={4} xs={12}>
                  <AutocompleteDropDown
                    name={"iuom"}
                    id={"iuom"}
                    label={"Inventory UOM"}
                    dataFn={UOMService.getAll}
                    valueParam={"uom"}
                    inputHandler={IUOMValueHandler}
                    validator={register}
                    errors={errors}
                  />
                </Grid>

                <Grid item md={4} xs={12}>
                  <AutocompleteDropDown
                    name={"puom"}
                    id={"puom"}
                    label={"Purchase UOM"}
                    dataFn={UOMService.getAll}
                    valueParam={"uom"}
                    inputHandler={PUOMValueHandler}
                    validator={register}
                    errors={errors}
                  />
                </Grid>

                {product.puom && product.iuom && product.puom !== product.iuom ? (
                  <Grid item xs={12} md={4}>
                    {/* <TextField
                      autoFocus
                      margin="dense"
                      id="cf"
                      name="cf"
                      label="Conversation Factor"
                      type="text"
                      fullWidth
                      variant="outlined"
                      {...register("cf")}
                      onChange={(e) => productValueHandler(e)}
                      defaultValue={product.cf}
                      error={errors.cf ? true : false}
                      helperText={errors.cf?.message}
                    /> */}
                    <EditText
                      name="cf"
                      placeholder="Conversation Factor"
                      onChange={handleChange}
                      value={values.cf}
                      error={errors.cf}
                      helpertext={errors.cf}
                    />
                  </Grid>
                ) : (
                  <></>
                )}

                <Grid item xs={12} md={4}>
                  <AutocompleteDropDown
                    name={"product_class"}
                    id={"product_class"}
                    label={"Product Class"}
                    dataFn={ProductClassService.getAll}
                    valueParam={"item_class"}
                    inputHandler={ProductClassValueHandler}
                    validator={register}
                    errors={errors}
                  />
                </Grid>
              </Grid>
            </Box>
          </DialogContent>

          <DialogActions>
            {/* <Button onClick={handleSubmit(saveProduct)}>Save</Button> */}
            <SubmitButton loading={values.action !== 'update' ? isSubmitting : isSubmittingUpdate}>Submit</SubmitButton>

            <Button onClick={() => hideAndClearProductDailog()}>Cancel</Button>
          </DialogActions>
        </Dialog>

        <TableContainer component={Paper} style={{ marginTop: "15px" }}>
          <Table sx={{ minWidth: 700 }} aria-label="customized table">
            <TableHead>
              <TableRow>
                <StyledTableCell>Code</StyledTableCell>
                <StyledTableCell>Name</StyledTableCell>
                <StyledTableCell>Product Class</StyledTableCell>
                <StyledTableCell>
                  Category <br /> Sub Category{" "}
                </StyledTableCell>
                <StyledTableCell>Specification</StyledTableCell>
                <StyledTableCell>Units</StyledTableCell>
                <StyledTableCell>Action</StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {products.map((product, index) => (
                <StyledTableRow key={index}>
                  <StyledTableCell>
                    <Link
                      href={product_route_keys.details.replace(
                        ":product_id",
                        product.id
                      )}
                    >
                      {product.code}
                    </Link>
                  </StyledTableCell>
                  <StyledTableCell>{product.name}</StyledTableCell>
                  <StyledTableCell>
                    {product.product_class.class}
                  </StyledTableCell>
                  <StyledTableCell>
                    {product.category.name} <br />
                    {product.sub_category.name}
                  </StyledTableCell>
                  <StyledTableCell>
                    {product.specification?.map((e, i) => {
                      for (let _e of Object.keys(e)) {
                        specifications_string += `<div>${_e} : ${e[_e]}<div/>`;
                      }
                    })}
                    <div
                      dangerouslySetInnerHTML={{
                        __html: specifications_string,
                      }}
                    ></div>
                    {(specifications_string = ``)}
                  </StyledTableCell>
                  <StyledTableCell>
                    {product.units.iuom} <br /> {product.units.poum} <br />{" "}
                    {product.units.cf} <br /> {product.units.title}
                  </StyledTableCell>
                  <StyledTableCell>
                    <CategoryProductDelete
                      product={product}
                      deleteActionHandler={deleteCategoryProductHandler}
                    />
                  </StyledTableCell>
                </StyledTableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
      <ToastAlert {...toastData}></ToastAlert>
    </>
  );
}

function CategoryProductDelete({ product, deleteActionHandler }) {
  const [anchorEl, setAnchorEl] = useState(null);
  const openDropdown = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleCloseDropdown = () => {
    setAnchorEl(null);
  };
  return (
    <>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={openDropdown ? "long-menu" : undefined}
        aria-expanded={openDropdown ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={openDropdown}
        onClose={handleCloseDropdown}
        PaperProps={{
          style: {
            maxHeight: 48 * 4.5,
            width: "20ch",
          },
        }}
      >
        <MenuItem onClick={() => deleteActionHandler(product)}>Delete</MenuItem>
      </Menu>
    </>
  );
}

export default CategoryProductListPage;
