import { Button,  Stack, Box, Grid } from "@mui/joy";
import { EditText } from "src/components/EditText";
import { Form, Formik } from "formik";
import { useRef } from "react";
import { useDispatch } from "react-redux";
import { updateProductCategory } from "src/store/slices/category/category.slice";
import { categoryValidationSchema } from "./CategoryData";
import { useQuery } from "@tanstack/react-query";
import { QueryKeys } from "src/services/queryKey";
import { CategoryService } from "src/services/api/CategoryService";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import FormControl from "@mui/joy/FormControl";
import FormLabel from "@mui/joy/FormLabel";
import UpdateButton from "src/components/Button/UpdateButton";

export default function CategoryForm({ categoryID }) {
  const dispatch = useDispatch();
  const formRef = useRef();

  const { isLoading, error, data, refetch } = useQuery(
    [QueryKeys.getCategory],
    async () => {
      return await CategoryService.get(categoryID);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        if (response) {
          if (formRef?.current?.values) {
            formRef.current.values.name = "";
          } else return null;

          //assing data to Formik
          formRef?.current?.setValues({
            ...formRef?.current?.values,
          });

          formRef.current.values.name = response.data.name;
          formRef.current.values.description = response.data.description;
          formRef.current.values.identifier = response.data.identifier;
          if (response.data.image) {
            formRef.current.values.image = response.data.image;
          }

          formRef?.current?.setValues({
            ...formRef?.current?.values,
          });
        }
        // setProductCategory(response.data);
      },
      staleTime: 0,
    }
  );

  function saveProductCategory(values) {
    dispatch(updateProductCategory({ values, categoryID }))
      .unwrap()
      .then((res) => {
        setTimeout(() => {
          refetch();
        }, 500);
      });
  }
  return (
    <>
      <Box margin={1}>
        <Formik
          initialValues={{
            name: "",
            description: "",
            identifier: "",
            image: "",
            category: categoryID,
          }}
          enableReinitialize={true}
          onSubmit={async (values) => {
            saveProductCategory(values);
          }}
          innerRef={formRef}
          validationSchema={categoryValidationSchema}
        >
          {({ values, errors, handleChange, setFieldValue }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                <EditText
                    name="name"
                    placeholder="Name"
                    onChange={handleChange}
                    value={values.name}
                    error={errors.name ? true : false}
                    helpertext={errors.name}
                  />
                  {/* <TextField
                   size="md"
                    margin="dense"
                    fullWidth
                    name="name"
                    label="Name"
                    variant="outlined"
                    value={values.name}
                    onChange={handleChange}
                    error={errors.name ? true : false}
                    helperText={errors.name}
                  /> */}
                </Grid>
                <Grid item xs={12} md={6}>
                <EditText
                    name="identifier"
                    placeholder="External Identifier"
                    onChange={handleChange}
                    value={values.identifier}
                    error={errors.identifier ? true : false}
                    helpertext={errors.identifier}
                  />
                  {/* <TextField
                   size="md"
                    margin="dense"
                    fullWidth
                    name="identifier"
                    label="External Identifier"
                    variant="outlined"
                    value={values.identifier}
                    onChange={handleChange}
                    error={errors.identifier ? true : false}
                    helperText={errors.identifier}
                  /> */}
                </Grid>
                <Grid item xs={12} md={12}>
                <EditText
                    name="description"
                    placeholder="Description"
                    onChange={handleChange}
                    value={values.description}
                    error={errors.description ? true : false}
                    helpertext={errors.description}
                  />
                  {/* <TextField
                   size="md"
                    margin="dense"
                    fullWidth
                    name="description"
                    label="Description"
                    variant="outlined"
                    value={values.description}
                    onChange={handleChange}
                    error={errors.description ? true : false}
                    helperText={errors.description}
                  /> */}
                </Grid>

                <Grid item xs={12} md={6}>
                  <FormControl>
                    <FormLabel>Image</FormLabel>
                    <Button
                      component="label"
                      variant="outlined"
                      starticon={<UploadFileIcon />}
                      size={"sm"}
                    >
                      Upload Image
                      <input
                        type="file"
                        accept="image/*"
                        hidden
                        onChange={(e) =>
                          setFieldValue("image", e.currentTarget.files[0])
                        }
                      />
                    </Button>
                  </FormControl>
                  <Box>{values?.image?.name}</Box>
                </Grid>
                <Grid item xs={12} md={12} marginTop={1}>
                  <Stack
                    direction={"row"}
                    justifyContent={"end"}
                    alignItems={"center"}
                    spacing={2}
                  >
                    <UpdateButton 
                    
                    />
                  </Stack>
                </Grid>
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>
    </>
  );
}
