import React from "react";
import {
  IconButton,
  Paper,
  Table,
  TableHead,
  TableContainer,
  TableRow,
  TableBody,
} from "@mui/material";
import { Stack, Link, Grid,Chip} from "@mui/joy";
import { useState } from "react";

import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import DeleteIcon from "@mui/icons-material/Delete";
import { useQuery } from "@tanstack/react-query";
import { PurchaseOrderService } from "src/services/api/PurchaseOrderService";
import { useNavigate } from "react-router-dom";
import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";
import { QueryKeys } from "src/services/queryKey";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { useDispatch } from "react-redux";
import { deletePurchaseOrder } from "src/store/slices/purchase-order";
import { Button, Modal, ModalClose, Sheet, Typography } from "@mui/joy";
import MainButton from "src/components/Button/MainButton";

export default function PurchaseOrdersListPage() {
  const [page, setPage] = useState(1);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [open, setOpen] = useState(false);
  const [currentRow, setCurrentRow] = useState();
  let navigate = useNavigate();

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const { isLoading: purchaseOrderLoading, refetch: purchaseOrderRefetch } =
    useQuery(
      [[QueryKeys.getAllPurchaseOrders], page],
      async () => {
        return await PurchaseOrderService.getAll(page);
      },
      {
        onSuccess: (response) => {
          setPurchaseOrders(response.data);
        },
        keepPreviousData: true,
        staleTime: 0,
      }
    );

  const dispatch = useDispatch();
  function deleteRow() {
    dispatch(deletePurchaseOrder({ currentRow }))
      .unwrap()
      .then((response) => {
        handleClose();
        setTimeout(() => {
          purchaseOrderRefetch();
        }, 500);
        setCurrentRow(null);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  if (purchaseOrderLoading) {
    return <>Loading....</>;
  }

  function addPurchaseOrder() {
    navigate(`/inventory/purchase-order/form`);
  }

  return (
    <>
      <Grid container spacing={3} padding={2}>
        <Grid item xs={5} md={2} sm={5}>
          <MainButton
            name={"Add New"}
            onClick={addPurchaseOrder}
          />
        </Grid>
      </Grid>

      <Stack spacing={6} direction="row" justifyContent={"flex-end"}>
        <IconButton
          color="primary"
          aria-label="Previous"
          component="button"
          onClick={() => setPage((prevState) => Math.max(prevState - 1, 0))}
          disabled={purchaseOrders.previous === null}
        >
          <ArrowBackIosIcon /> &nbsp; Previous
        </IconButton>
        <IconButton
          color="primary"
          aria-label="Next"
          component="button"
          onClick={() => setPage((prevState) => prevState + 1)}
          disabled={purchaseOrders.next === null}
        >
          Next &nbsp; <ArrowForwardIosIcon />
        </IconButton>
      </Stack>
      <Grid container spacing={3} padding={2}>
        <Grid item xs={12} md={12}>
          {purchaseOrders && purchaseOrders?.results?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align="center">PO No.</StyledTableCell>
                      <StyledTableCell align="center">Vendor</StyledTableCell>
                      <StyledTableCell align="center">Date</StyledTableCell>
                      <StyledTableCell align="center">
                        Contact Person
                      </StyledTableCell>
                      <StyledTableCell align="center">
                        Mobile No.
                      </StyledTableCell>
                      <StyledTableCell align="center">Email</StyledTableCell>
                      <StyledTableCell align="center">Status</StyledTableCell>
                      <StyledTableCell align="center">Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {purchaseOrders.results.map((po, index) => {
                      return (
                        <StyledTableRow key={index}>
                          <StyledTableCell align="center">
                            <Link
                              href={`/inventory/purchase-order/:purchase_order_id`.replace(
                                ":purchase_order_id",
                                po.id
                              )}
                            >
                              {po.po_number}
                            </Link>
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {po.vendor?.name}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {po.date}
                          </StyledTableCell>

                          <StyledTableCell>{po.contact_person}</StyledTableCell>
                          <StyledTableCell align="center">
                            {po.mobile_no}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {po.email}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {po.status}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            <IconButton
                              aria-label="delete"
                              size="large"
                              color="error"
                              onClick={() => {
                                handleClickOpen();
                                setCurrentRow(po);
                              }}
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>

      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={handleClose}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            {"Delete Purchase Order"}
          </Typography>
          <Typography
            component={"div"}
            id="modal-desc"
            marginBottom={2}
            textColor="text.tertiary"
          >
            Are you sure want to delete Purchase Order <br />{" "}
            <Chip label={currentRow?.po_number} />
          </Typography>

          <Grid container spacing={1}>
            <Grid item xs={12} md={6}>
              <Button
                fullWidth
                variant="solid"
                color="success"
                onClick={handleClose}
              >
                No
              </Button>
            </Grid>
            <Grid item xs={12} md={6}>
              <Button
                fullWidth
                variant="solid"
                color="danger"
                onClick={deleteRow}
              >
                Yes
              </Button>
            </Grid>
          </Grid>
        </Sheet>
      </Modal>
    </>
  );
}
