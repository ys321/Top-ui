import { useState } from "react";
import {
  Grid,
  Chip,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Stack,
  Link,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import {
  StyledTableCell,
  StyledTableRow,
  Transition
} from "src/components/Table/TableStyle";
import { QueryKeys } from "src/services/queryKey";
import { useDispatch } from "react-redux";

import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import DeleteIcon from "@mui/icons-material/Delete";
import { useQuery } from "@tanstack/react-query";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import TOPButton from "src/components/Button/TopButton";
import { useNavigate } from "react-router-dom";
import MainButton from "src/components/Button/MainButton";

export default function OutwardSiteListPage() {
  const [page, setPage] = useState(1);
  const [outwardSites, setOutwardSites] = useState([]);
  const [open, setOpen] = useState(false);
  const [currentRow, setCurrentRow] = useState();
  let navigate = useNavigate();

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const { isLoading: outwardSiteLoading, refetch: outwardSiteRefetch } =
    useQuery(
      [[QueryKeys.getAllOutwardSite], page],
      async () => {
        return await InwardOutwardService.OutwardSite.getAll(page);
      },
      {
        onSuccess: (response) => {
          setOutwardSites(response.data);
        },
        keepPreviousData: true,
        staleTime: 0,
      }
    );

  const dispatch = useDispatch();
  // function deleteRow() {
  //   dispatch(deleteOutwardSite({ currentRow }))
  //     .unwrap()
  //     .then((response) => {
  //       handleClose();
  //       setTimeout(() => {
  //         outwardSiteRefetch();
  //       }, 500);
  //       setCurrentRow(null);
  //     })
  //     .catch((e) => {
  //       console.log(e);
  //     });
  // }

  if (outwardSiteLoading) {
    return <>Loading....</>;
  }

  function addOutwardSite() {
    navigate(`/inventory/outward-site/form`);
  }
  return (
    <>
      <Grid container spacing={1} padding={2}>
      <Grid item xs={12} md={12}>
      <MainButton 
name={"ADD NEW"} 
onClick={addOutwardSite}
 />
        </Grid>
      </Grid>

      <Stack spacing={6} direction="row" justifyContent={"flex-end"}>
        <IconButton
          color="primary"
          aria-label="Previous"
          component="button"
          onClick={() => setPage((prevState) => Math.max(prevState - 1, 0))}
          disabled={outwardSites.previous === null}
        >
          <ArrowBackIosIcon /> &nbsp; Previous
        </IconButton>
        <IconButton
          color="primary"
          aria-label="Next"
          component="button"
          onClick={() => setPage((prevState) => prevState + 1)}
          disabled={outwardSites.next === null}
        >
          Next &nbsp; <ArrowForwardIosIcon />
        </IconButton>
      </Stack>

      <Grid container spacing={3} padding={2}>
        <Grid item xs={12} md={12}>
          <>
            <TableContainer component={Paper} >
              <Table sx={{ minWidth: 700 }} aria-label="customized table">
                <TableHead>
                  <TableRow>
                    <StyledTableCell align="center">ID</StyledTableCell>
                    <StyledTableCell align="center">Site Name</StyledTableCell>
                    <StyledTableCell align="center">
                      Location Name
                    </StyledTableCell>
                    <StyledTableCell align="center">Date</StyledTableCell>
                    <StyledTableCell align="center">Remarks</StyledTableCell>
                    <StyledTableCell align="center">Action</StyledTableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {outwardSites.map((site, index) => {
                    return (
                      <StyledTableRow key={index}>
                        <StyledTableCell align="center">
                          <Link
                            href={`/inventory/outward-site/:outward_site_id`.replace(
                              ":outward_site_id",
                              site.id
                            )}
                          >
                            {site.id}
                          </Link>
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          {site.site_name}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          {site.location?.name}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          {site.date}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          {site.remarks}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          <IconButton
                            aria-label="delete"
                            size="large"
                            color="error"
                            onClick={() => {
                              handleClickOpen();
                              setCurrentRow(site);
                            }}
                          >
                            <DeleteIcon fontSize="inherit" />
                          </IconButton>
                        </StyledTableCell>
                      </StyledTableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </>

        </Grid>
      </Grid>

      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        aria-describedby="product-delete-confirm-dailog"
      >
        <DialogTitle>{"Delete Outward Site"}</DialogTitle>
        <DialogContent>
          Are you sure want to delete Outward Site <br />{" "}
          <Chip label={currentRow?.site_name} />
        </DialogContent>
        <DialogActions>
          <TOPButton
            // onClick={deleteRow}
            variant="danger" text={"Yes"} />
          <TOPButton onClick={handleClose} variant="info" text={"No"} />
        </DialogActions>
      </Dialog>
    </>
  );
}
