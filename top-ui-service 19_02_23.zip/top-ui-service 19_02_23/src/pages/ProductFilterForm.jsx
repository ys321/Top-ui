import {
  FormControl,
  InputLabel,
  MenuItem,
  TextField,
} from "@mui/material";
import { Stack, Select, Grid, Button } from "@mui/joy";
import { useEffect, useState } from "react";
import { VendorService } from "src/services/api/VendorService";
import SearchIcon from "@mui/icons-material/Search";
import { CategoryService } from "src/services/api/CategoryService";
import { EditText } from "src/components/EditText";

export default function ProductFilterForm({
  onFilter,
  onClear,
  tableData,
  onSearch,
  searchQuery,
}) {
  const [code, setCode] = useState("");
  const [vendors, setVendors] = useState("");
  console.log(vendors);
  const [vendorOptions, setVendorOptions] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [category, setCategory] = useState("");
  console.log(category);

  useEffect(() => {
    (async () => {
      const options = await VendorService.getAll();
      setVendorOptions(renderOptions(options.data, "vendor"));
    })();
  }, []);

  useEffect(() => {
    (async () => {
      const options = await CategoryService.getAll();
      setCategoryOptions(renderOptions(options.data, "category"));
    })();
  }, []);

  function renderOptions(data, lookup) {
    const _ea = [];
    data.map((el, index) => {
      _ea.push(
        <MenuItem key={index} value={el.id}>
          {el.name || el[lookup] || el.type}
        </MenuItem>
      );
    });
    return _ea;
  }

  const clear = () => {
    setCode("");
    setVendors("");
    setCategory("");
  };

  return (
    <>
      <Grid item xs={12} md={12}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={2}>
            <FormControl fullWidth>
              <InputLabel id={"vendors"} size="small">
                {"Vendors"}
              </InputLabel>
              <Select
                margin="dense"
                size="small"
                autoFocus
                labelId={"vendors"}
                id={"vendors"}
                label={"Vendors"}
                name={"vendors"}
                value={vendors.vendors || ""}
                onChange={(e) => {
                  const { name, value } = e.target;
                  setVendors({
                    ...vendors,
                    [name]: value,
                  });
                }}
              >
                {vendorOptions}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={2}>
            <FormControl fullWidth>
              <InputLabel id={"category"} size="small">
                {"Categories"}
              </InputLabel>
              <Select
                margin="dense"
                size="small"
                autoFocus
                labelId={"category"}
                id={"category"}
                label={"Categories"}
                name={"category"}
                value={category.category || ""}
                onChange={(e) => {
                  const { name, value } = e.target;
                  setCategory({
                    ...category,
                    [name]: value,
                  });
                }}
              >
                {categoryOptions}
              </Select>
            </FormControl>
          </Grid>
          <Grid
            item
            xs={6}
            md={2}
            style={{ display: "flex", alignItems: "center" }}
          >
            <Stack direction={"row"} spacing={1} style={{ width: "100%" }}>
              <Button
                variant="contained"
                onClick={() => {
                  onFilter?.({
                    vendors: vendors.vendors,
                    category: category.category,
                    code: code,
                  });
                }}
                fullWidth
              >
                Filter
              </Button>
              <Button
                variant="outlined"
                color="error"
                onClick={() => {
                  onClear?.();
                  clear();
                }}
                fullWidth
              >
                Clear
              </Button>
            </Stack>
          </Grid>
        </Grid>
        <Grid container spacing={2} marginTop={1}>
          <Grid item xs={12} md={4}>
            {/* <Grid item xs={8} md={8}> */}
            {/* <TextField
              fullWidth
              size="small"
              placeholder="Search"
              onChange={(e) => {
                searchQuery?.(e.target.value);
              }}
            /> */}
            <EditText
              placeholder="Search"
              onChange={(e) => {
                searchQuery?.(e.target.value);
              }}
            />
          </Grid>
          <Grid item xs={4} md={2}>
            <Button
              variant="outlined"
              color="warning"
              fullWidth
              startIcon={<SearchIcon />}
              onClick={() => {
                onSearch?.();
              }}
            >
              Search
            </Button>
            {/* </Grid> */}
          </Grid>
        </Grid>
      </Grid>
    </>
  );
}
