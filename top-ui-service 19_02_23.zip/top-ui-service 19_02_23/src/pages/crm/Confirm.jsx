import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import { Button,Grid } from '@mui/joy';

const useStyles = makeStyles(theme => ({
    textCenter: {
        textAlign: 'center'
    },
    button: {
        margin: theme.spacing(1)
    }
}));
const debug = true;

export const Confirm = ({ formData, prevStep, nextStep }) => {
    const classes = useStyles();
    console.log(formData);
    const { liftType,
        noOfBasement,
        noOfFloor,
        liftQuantity,
        floor,
        machineType,
        machineMake,
        machineRoom,
        counterWtPosition,
        machinePlacement } = formData;
    return (
        <>
            <Grid container spacing={2} margin={2}>
                <Grid item xs={12} md={12}>
                    <div>
                        {debug && (
                            <>
                                <pre >
                                    <strong>FormData</strong>
                                    <br />
                                    {JSON.stringify(formData, null, 2)}
                                </pre>
                            </>
                        )}
                        <div className={classes.textCenter}>
                            <Button
                                color='secondary'
                                variant='contained'
                                className={classes.button}
                                onClick={() => prevStep()}
                            >
                                Back
                            </Button>

                            {/* <Button
                        color='primary'
                        variant='contained'
                        className={classes.button}
                        onClick={() => nextStep()}
                    >
                        Confirm & Continue
                    </Button> */}
                        </div>
                    </div>
                </Grid>
            </Grid>
        </>
    );
};

Confirm.propTypes = {
    formData: PropTypes.object.isRequired,
    prevStep: PropTypes.func.isRequired,
    nextStep: PropTypes.func.isRequired
};
