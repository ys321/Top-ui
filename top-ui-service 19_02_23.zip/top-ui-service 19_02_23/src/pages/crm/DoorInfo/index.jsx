import { Breadcrumbs, Button, Chip, TextField,Box, Grid, Stack } from "@mui/joy";
import { Form, Formik } from "formik";
import PropTypes from 'prop-types';
import { BaseDropdown } from "src/components/Dropdown/BaseDropdown";
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';

const options = [
    {
        'id': 1,
        'name': 'Test 1'
    },
    {
        'id': 2,
        'name': 'Test 2'
    },
    {
        'id': 3,
        'name': 'Test 3'
    },
]

export const DoorInfo = ({ formData, setFormData, nextStep, prevStep, jumpStep }) => {

    return (
        <>
            <Box margin={2}>
                <Formik
                    initialValues={formData}
                    onSubmit={values => {
                        setFormData(values);
                        nextStep();
                    }}
                // validationSchema={validationSchema}
                >
                    {({ errors, touched, handleChange }) => (
                        <Form >
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={12}>
                                    <Breadcrumbs area-label="breadcrumb">
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(1)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Site Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(2)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Machine Room</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(3)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                            endDecorator={<RadioButtonCheckedIcon fontSize="md" />}
                                        >Door Info</Chip>
                                    </Breadcrumbs>
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "doorType",
                                            onChange: handleChange,
                                            defaultValue: formData.doorType ?? '',
                                        }}
                                        options={options}
                                        label='Door Type'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "landingDoorSelection",
                                            onChange: handleChange,
                                            defaultValue: formData.landingDoorSelection ?? '',
                                        }}
                                        options={options}
                                        label='Landing Door Selection'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "glassDoor",
                                            onChange: handleChange,
                                            defaultValue: formData.glassDoor ?? '',
                                        }}
                                        options={options}
                                        label='Glass Door'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "visiblePanel",
                                            onChange: handleChange,
                                            defaultValue: formData.visiblePanel ?? '',
                                        }}
                                        options={options}
                                        label='Visible Panel'
                                    />
                                </Grid>
                                <Grid item xs={12} md={6}>
                                    <BaseDropdown
                                        props={{
                                            name: "doorBrand",
                                            onChange: handleChange,
                                            defaultValue: formData.doorBrand ?? '',
                                        }}
                                        options={options}
                                        label='Door Brand'
                                    />
                                </Grid>
                                <Grid item xs={12} md={6}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="doorOpration"
                                        label='Door Operation'
                                        defaultValue={formData.doorOpration}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.doorOpration && errors.doorOpration}
                                    // helperText={touched.doorOpration && errors.doorOpration}
                                    />
                                </Grid>

                                <Grid item xs={12} md={12}>
                                    <Stack
                                        direction={"row"}
                                        justifyContent={"space-between"}
                                        alignItems={"center"}
                                    >
                                        <Button
                                            variant='outlined'
                                            color="info"
                                            onClick={() => prevStep()}
                                        >
                                            Back To Machine Room
                                        </Button>
                                        <Button
                                            type='submit'
                                            variant='outlined'
                                            color='primary'
                                        >
                                            Continue To Cabin Info
                                        </Button>
                                    </Stack>
                                </Grid>

                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Box>

        </>
    );
}

DoorInfo.propTypes = {
    formData: PropTypes.object.isRequired,
    setFormData: PropTypes.func.isRequired,
    nextStep: PropTypes.func.isRequired
};

export default DoorInfo;