import { Breadcrumbs, Button, Chip, List, ListItem, TextField,Box, Grid, Stack } from "@mui/joy";

import { Form, Formik } from "formik";
import PropTypes from 'prop-types';
import { KeyboardArrowRight } from "@mui/icons-material";
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';
import { BaseDropdown } from "src/components/Dropdown/BaseDropdown";

const options = [
    {
        'id': 1,
        'name': 'Test 1'
    },
    {
        'id': 2,
        'name': 'Test 2'
    },
    {
        'id': 3,
        'name': 'Test 3'
    },
]

export const LiftSpecification = ({ formData, setFormData, nextStep, prevStep, jumpStep }) => {

    return (
        <>
            <Box margin={2}>
                <Formik
                    initialValues={formData}
                    onSubmit={values => {
                        setFormData(values);
                        nextStep();
                    }}
                // validationSchema={validationSchema}
                >
                    {({ errors, touched, handleChange }) => (
                        <Form >
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={12}>
                                    <Breadcrumbs area-label="breadcrumb">
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(1)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Site Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(2)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Machine Room</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(3)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Door Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(4)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Cabin Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(5)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Controller Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(6)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                            endDecorator={<RadioButtonCheckedIcon fontSize="md" />}
                                        >Lift Specification</Chip>
                                    </Breadcrumbs>
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <List>
                                        <ListItem>
                                            Lift Type
                                            <KeyboardArrowRight />
                                            <b>
                                                {formData.liftType}</b>
                                        </ListItem>
                                        <ListItem>
                                            Lift Quantity
                                            <KeyboardArrowRight />
                                            <b>
                                                {formData.liftQuantity}</b>
                                        </ListItem>
                                    </List>
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="loadCapacity"
                                        label='Load Capacity'
                                        defaultValue={formData.loadCapacity}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carInsideWide && errors.carInsideWide}
                                    // helperText={touched.carInsideWide && errors.carInsideWide}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "speed",
                                            onChange: handleChange,
                                            defaultValue: formData.speed ?? '',
                                        }}
                                        options={options}
                                        label='Speed'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="powerSupply"
                                        label='Power Supply'
                                        defaultValue={formData.powerSupply}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carEnclosure && errors.carEnclosure}
                                    // helperText={touched.carEnclosure && errors.carEnclosure}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "col_lop",
                                            onChange: handleChange,
                                            defaultValue: formData.col_lop ?? '',
                                        }}
                                        options={options}
                                        label='COL/LOP'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "cop_lop_displayType",
                                            onChange: handleChange,
                                            defaultValue: formData.cop_lop_displayType ?? '',
                                        }}
                                        options={options}
                                        label='COP/LOP Display Type'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "security",
                                            onChange: handleChange,
                                            defaultValue: formData.security ?? '',
                                        }}
                                        options={options}
                                        label='Security'
                                    />
                                </Grid>

                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="rate"
                                        label='Rate'
                                        defaultValue={formData.rate}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carCarpetArea && errors.carCarpetArea}
                                    // helperText={touched.carCarpetArea && errors.carCarpetArea}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="amount"
                                        label='Amount'
                                        defaultValue={formData.amount}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carCarpetArea && errors.carCarpetArea}
                                    // helperText={touched.carCarpetArea && errors.carCarpetArea}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="gst"
                                        label='GST'
                                        defaultValue={formData.gst}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carCarpetArea && errors.carCarpetArea}
                                    // helperText={touched.carCarpetArea && errors.carCarpetArea}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="total"
                                        label='Total'
                                        // defaultValue={formData.total}
                                        variant="outlined"
                                        disabled
                                    />
                                </Grid>
                                <Grid item xs={12} md={12}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="signal"
                                        label='Singal'
                                        defaultValue={formData.signal}
                                        variant="outlined"
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="srNo"
                                        label='SR No.'
                                        defaultValue={formData.srNo}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carCarpetArea && errors.carCarpetArea}
                                    // helperText={touched.carCarpetArea && errors.carCarpetArea}
                                    />
                                </Grid>
                                <Grid item xs={12} md={9}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="note"
                                        label='Note'
                                        defaultValue={formData.note}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carCarpetArea && errors.carCarpetArea}
                                    // helperText={touched.carCarpetArea && errors.carCarpetArea}
                                    />
                                </Grid>

                                <Grid item xs={12} md={12}>
                                    <Stack
                                        direction={"row"}
                                        justifyContent={"space-between"}
                                        alignItems={"center"}
                                    >
                                        <Button
                                            variant='outlined'
                                            color="info"
                                            onClick={() => prevStep()}
                                        >
                                            Back To Controller Info
                                        </Button>
                                        <Button
                                            type='submit'
                                            variant='outlined'
                                            color='primary'
                                        >
                                            Continue To Terms And Condition
                                        </Button>
                                    </Stack>
                                </Grid>

                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Box>
        </>
    );
}

LiftSpecification.propTypes = {
    formData: PropTypes.object.isRequired,
    setFormData: PropTypes.func.isRequired,
    nextStep: PropTypes.func.isRequired
}

export default LiftSpecification;