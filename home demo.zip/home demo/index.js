// $(document).ready(function(){
//     $('.owl-carousel').owlCarousel();
//   });


  
var owl = $('.owl-carousel');
owl.owlCarousel({
   centre:true,
   items:2,
    loop:true,
    nav:true,
    margin:10,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },            
        960:{
            items:2
        },
        1200:{
            items:2
        }
    }
});
owl.on('mousewheel', '.owl-stage', function (e) {
    if (e.deltaY>0) {
        owl.trigger('next.owl');
    } else {
        owl.trigger('prev.owl');
    }
    e.preventDefault();
});