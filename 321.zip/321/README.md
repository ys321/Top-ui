# TOP INDIA ELEVATOR PVT LTD

project setup:

### `npm install` 
to install all dependancies

### goto depandancies.txt
take one by one all listed dependancies and install it manually

### `for local dev server run : npm run start`