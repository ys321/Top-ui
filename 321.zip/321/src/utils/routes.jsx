import React, { lazy } from "react";
//WAREHOUSE IMPORT
import LocationList from "src/pages/BusinessLocation/BusinessLocationPage";
import LocationDetailPage from "src/pages/BusinessLocation/BusinessLocationDetails";
import SectionPage from "src/pages/BusinessLocation/SectionPage";
import RackPage from "src/pages/BusinessLocation/RackPage";
import ShelfPage from "src/pages/BusinessLocation/ShelfPage";
import BinPage from "src/pages/BusinessLocation/BinPage";

//INVENTORY/PRODUCT IMPORT
import ProductPage from "src/pages/inventory/products/ProductPage";
import ProductDetails from "src/pages/inventory/products/ProductDetails";

//INWARD IMPORT
import InwardPage from "src/pages/inventory/inward_outward/InwardPage";
import InwardBranchBasicInformationForm from "src/pages/inventory/inward_outward/InwardBranch/InwardBranchBasicInformationForm";
import InwardBranchListPage from "src/pages/inventory/inward_outward/InwardBranch/InwardBranchListPage";
import InwardSiteForm from "src/pages/inventory/inward_outward/InwardSite/InwardSiteForm";
import InwardSiteListPage from "src/pages/inventory/inward_outward/InwardSite/InwardSiteListPage";
import InwardVendorBasicInformationForm from "src/pages/inventory/inward_outward/InwardVendor/InwardVendorBasicInformationForm";
import InwardListVendorPage from "src/pages/inventory/inward_outward/InwardVendor/InwardListVendorPage";
import InwardCustomerListPage from "src/pages/inventory/inward_outward/InwardCustomer/InwardCustomerListPage";
import InwardCustomerForm from "src/pages/inventory/inward_outward/InwardCustomer/InwardCustomerForm";


//OUTWARD IMPORT
import OutwardBranchBasicInformationForm from "src/pages/inventory/inward_outward/OutwardBranch/OutwardBranchBasicInformationForm";
import OutwardBranchListPage from "src/pages/inventory/inward_outward/OutwardBranch/OutwardBranchListPage";
import OutwardSiteForm from "src/pages/inventory/inward_outward/OutwardSite/OutwardSiteForm";
import OutwardSiteListPage from "src/pages/inventory/inward_outward/OutwardSite/OutwardSiteListPage";
import OutwardVendorForm from "src/pages/inventory/inward_outward/OutwardVendor/OutwardVendorForm";
import OutwardVendorListPage from "src/pages/inventory/inward_outward/OutwardVendor/OutwardVendorListPage";

//CATEGORY MANAGEMENT IMPORT
import CategoryPage from "src/pages/inventory/category/CategoryPage";
import CategoryDetails from "src/pages/inventory/category/CategoryDetails";
import SubCategoryDetailPage from "src/pages/inventory/category/sub_category/SubCategoryDetailPage";

//VENDOR MANAGEMENT IMPORT
import VendorList from "src/pages/vendors/VendorList";
import VendorDetails from "src/pages/vendors/VendorDetails";

//PURCHASE ORDER IMPORT
import { PurchaseOrderForm } from "src/pages/inventory/PurchaseOrders/PurchaseOrderForm";
import PurchaseOrdersListPage from "src/pages/inventory/PurchaseOrders/PurchaseOrdersListPage";

//MATERIAL REQUEST IMPORT
import MaterialRequestForm from "src/pages/inventory/MaterialRequest/MaterialRequestForm";
import MaterialRequestListPage from "src/pages/inventory/MaterialRequest/MaterialRequestListPage";

//BUSINESS SETTING IMPORT
import BusinessSettings from "src/pages/BusinessSettings/BusinessSettings";
import CityManagement from "src/pages/BusinessSettings/CityManagement";
import ProductClass from "src/pages/BusinessSettings/ProductClass";
import ProductUnit from "src/pages/BusinessSettings/ProductUnit";
import VendorType from "src/pages/BusinessSettings/VendorType";

//CRM PAGE IMPORT
import CRMPage from "src/pages/crm";
import CRMBasicInfo from "src/pages/crm/BasicInquiry";
import LiftProposal from "src/pages/crm/LiftProposal";

import NoPageFound from "src/components/NoPageFound";
// import Dashboard from "src/pages/Dashboard";
import AuthGuard from "./Guards/AuthGuard";
import Test from "src/pages/Test";
import { Navigate } from "react-router-dom";
import Login from "src/pages/auth/login/index";

import Dashboard from "src/pages/Dashboard";
import { UserRoles } from "./Guards/UserRoles";
import AdminGuard from "./Guards/AdminGuard";

export const routes = [
  //STARTING ROUTE
  {
    //after login success, page redirect to dashboard
    path: "/",
    element: (
      // <AuthGuard>
        <Dashboard />
      // </AuthGuard>
    ),
  },
  // {
  //   path: "/login",
  //   element: <Login />,
  // },
  {
    path: "test",
    element: <Test />,
  },

  // WAREHOUSE ROUTES
  {
    path: "/business-location",
    children: [
      // {
      //   index: true,
      //   element: <Navigate replace to="/login" />,
      // },
      {
        index : true,
        element: (
            // <AdminGuard
            //   fallback={<Navigate replace to='/' />}
            //   roles={[UserRoles.TOP_ADMIN, UserRoles.TOP_EMPLOYEE]}
            // >
            <LocationList />
            // </AdminGuard>
        ),
      },
      {
        path: ":location_id",
        element: (
          // floor data based on location id or location details
          // <AuthGuard>
            <LocationDetailPage />
          // </AuthGuard>
        ),
      },
      {
        //section data based on floor id
        path: ":location_id/floor/:floor_id",
        element: (
          // <AuthGuard>
            <SectionPage />
          // </AuthGuard>
        ),
      },
      {
        //rack data based on section id
        path: ":location_id/floor/:floor_id/section/:section_id",
        element: (
          // <AuthGuard>
            <RackPage />
          // </AuthGuard>
        ),
      },
      {
        //shelf data based on rack id
        path: ":location_id/floor/:floor_id/section/:section_id/rack/:rack_id",
        element: (
          // <AuthGuard>
            <ShelfPage />
          // </AuthGuard>
        ),
      },
      {
        //bin data based on shelf id
        path: ":location_id/floor/:floor_id/section/:section_id/rack/:rack_id/shelf/:shelf_id",
        element: (
          // <AuthGuard>
            <BinPage />
          // </AuthGuard>
        ),
      },
      {
        path: ":location_id/floor/:floor_id/section/:section_id/rack/:rack_id/shelf/:shelf_id/bin/:bin_id",
        element: (
          // <AuthGuard>
            <BinPage />
          // </AuthGuard>
        ),
      },
    ],
  },

  //INVENTORY/PRODUCT ROUTES
  {
    path: "inventory/product",
    children: [
      {
        index: true,
        element: (
          // <AuthGuard>
            <ProductPage />
          // </AuthGuard>
        ),
      },
      {
        path: ":product_id",
        element: (
          //product details based on product id
          // <AuthGuard>
            <ProductDetails />
          // </AuthGuard>
        ),
      },
    ],
  },

  //INWARD-OUWARD ROUTES
  {
    path: "/inventory/inward-outward",
    children: [
      {
        index: true,
        element: (
          // <AuthGuard>
            <InwardPage />
          // </AuthGuard>
        ),
      },
    ],
  },
  //INWARD VENDOR ROUTE
  {
    path: "/inventory/inward-vendor",
    children: [
      {
        index: true,
        element: <InwardListVendorPage />,
      },
      {
        path: "form",
        element: <InwardVendorBasicInformationForm />,
      },
      {
        path: ":inward_vendor_id",
        element: (
          //inward vendor details based on inward_vendor_id
          <InwardVendorBasicInformationForm />
        ),
      },
    ],
  },
  //INWARD BRANCH ROUTE
  {
    path: "/inventory/inward-branch",
    children: [
      {
        index: true,
        element: <InwardBranchListPage />,
      },
      {
        path: "form",
        element: <InwardBranchBasicInformationForm />,
      },
      // {
      //   path : ':inward_branch_id',
      //   element: (
      //     <InwardVendorBasicInformationForm />
      //   ),
      // }
    ],
  },
  //INWARD SITE ROUTE
  {
    path: "/inventory/inward-site",
    children: [
      {
        index: true,
        element: <InwardSiteListPage />,
      },
      {
        path: "form",
        element: <InwardSiteForm />,
      },
      {
        //inward site details based on inward_site_id
        path: ":inward_site_id",
        element: <InwardSiteForm />,
      },
    ],
  },

   //INWARD CUSTOMER ROUTE
   {
    path: "/inventory/inward-customer",
    children: [
      {
        index: true,
        element: <InwardCustomerListPage />,
      },
      {
        path: "form",
        element: <InwardCustomerForm />,
      },
      {
        //inward customer details based on inward_customer_id
        path: ":inward_customer_id",
        element: <InwardCustomerForm />,
      },
    ],
  },

  //OUTWARD ROUTES
  //OUTWARD VENDOR ROUTE
  {
    path: "/inventory/outward-vendor",
    children: [
      {
        index: true,
        element: <OutwardVendorListPage />,
      },
      {
        path: "form",
        element: <OutwardVendorForm />,
      },
      {
        //ouward vendor details based on outward vendor id
        path: ":outward_vendor_id",
        element: <OutwardVendorForm />,
      },
    ],
  },

  //OUTWARD BRANCH ROUTE
  {
    path: "/inventory/outward-branch",
    children: [
      {
        index: true,
        element: <OutwardBranchListPage />,
      },
      {
        path: "form",
        element: <OutwardBranchBasicInformationForm />,
      },
      {
        //outward branch details based on outward branch id
        path: ":outward_branch_id",
        element: <OutwardBranchBasicInformationForm />,
      },
    ],
  },

  //OUTWARD SITE ROUTE
  {
    path: "/inventory/outward-site",
    children: [
      {
        index: true,
        element: <OutwardSiteListPage />,
      },
      {
        path: "form",
        element: <OutwardSiteForm />,
      },
      {
        //ouward site details based on outward site id
        path: ":outward_site_id",
        element: <OutwardSiteForm />,
      },
    ],
  },

  //CATEGORY MANAGEMENT
  {
    path: "inventory/product-category",
    children: [
      {
        index: true,
        element: (
          // <AuthGuard>
            <CategoryPage />
          // </AuthGuard>
        ),
      },
      {
        path: ":category_id",
        element: (
          //product-category details based on category id
          // <AuthGuard>
            <CategoryDetails />
          // </AuthGuard>
        ),
      },
      {
        path: ":category_id/sub-category/:sub_category_id",
        element: (
          //sub category details based on category id
          <SubCategoryDetailPage />
        ),
      },
    ],
  },

  //VENDOR MANAGEMENT
  {
    path: "/vendor",
    children: [
      {
        index: true,
        element: <VendorList />,
      },
      {
        path: ":vendor_id",
        element: (
          //vendor details based on vendor id
          <VendorDetails />
        ),
      },
    ],
  },

  //PURCHASE ORDER
  {
    path: "/inventory/purchase-order",
    children: [
      {
        index: true,
        element: <PurchaseOrdersListPage />,
      },
      {
        path: "form",
        element: <PurchaseOrderForm />,
      },
      {
        //purchase order details based on purchase order id
        path: ":purchase_order_id",
        element: <PurchaseOrderForm />,
      },
    ],
  },

  //MATERIAL REQUEST
  {
    path: "/inventory/material-request",
    children: [
      {
        index: true,
        element: <MaterialRequestListPage />,
      },
      {
        path: "form",
        element: <MaterialRequestForm />,
      },
      {
        //material request details based on material request id
        path: ":material_request_id",
        element: <MaterialRequestForm />,
      },
    ],
  },

  //BUSINESS SETTINGS
  {
    path: "/business-setting",
    children: [
      {
        index: true,
        element: <BusinessSettings />,
      },
      {
        path: "product-class",
        element: <ProductClass />,
      },
      {
        path: "product-unit",
        element: <ProductUnit />,
      },
      {
        path: "vendor-type",
        element: <VendorType />,
      },
      {
        path: "city-management",
        element: <CityManagement />,
      },
    ],
  },

  //CRM
  {
    path: "/crm",
    children: [
      {
        index: true,
        element: <CRMPage />,
      },
      {
        path: "basic-info",
        element: <CRMBasicInfo />,
      },
      {
        path: "proposal",
        element: <LiftProposal />,
      },
    ],
  },

  {
    //if url pattern not matched than redirect to no page found
    path: "*",
    element: <NoPageFound />,
  },
];
