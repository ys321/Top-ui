import * as yup from "yup";

const productValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("product name is required")
    .min(2, "name should be at least 2 character long")
    .max(50, "name should not be more than 50 character"),
  category: yup.string().required("Category is required"),
  iuom: yup.string().required("iuom is required"),
  product_class: yup.string().required("Product Class is required"),
  puom: yup.string().required("iuom is required"),
  
});

const vendorValidationSchema = yup.object().shape({
  vendor: yup.string().required("vendor is required"),
});

const productDetailValidationSchema = yup.object().shape({
  code: yup.string().required("code is required"),
  name: yup.string().required("name is required"),
  category: yup.string().required("Category is required"),
  sub_category: yup.string("Sub Category is required"),
  unit: yup.string().required("unit is required"),
  product_unit_value: yup.number().when("unit", {
    is: "unit",
    then: yup
      .number()
      .typeError("Only Numbers allowed")
      .required("Product Unit Value is Required"),
    otherwise: yup.number().typeError("Only Numbers allowed"),
  }),
  iuom: yup.string().required("iuom is required"),
  puom: yup.string().required("puom is required"),
  cf: yup.string().required("cf is required"),
  product_class: yup.string().required("product class is required"),
});

export {
  productValidationSchema,
  vendorValidationSchema,
  productDetailValidationSchema,
};
