import React from "react";
import {  Paper } from "@mui/material";
import { Button,Link } from "@mui/joy";

function TopButton({
    text,
    onClick,
    variant,
    link,
    size,
    disabled
}) {


    return (
        <>
            <Paper style={{
                borderRadius: '15px'
            }} elevation={3}>
                {link ? (<>
                    <Link underline="none" href={link} color={'white'}>
                        <Button
                            variant="solid"
                            // style={{
                            //     backgroundColor: backgroundColors[variant],
                            //     color: 'white',
                            //     padding: '7px',
                            //     borderRadius: '15px'
                            // }}
                            fullWidth
                        >
                            {text}
                        </Button>
                    </Link>
                </>) : (
                    <>
                        <Button
                            onClick={onClick}
                            variant='solid'
                            // style={{
                            //     backgroundColor: backgroundColors[variant],
                            //     color: 'white',
                            //     padding: '5px',
                            //     borderRadius: '15px'
                            // }}
                            fullWidth
                            disabled={disabled}
                        >
                            {text}
                        </Button>
                    </>)}
            </Paper>
        </>
    )
}

export default TopButton;