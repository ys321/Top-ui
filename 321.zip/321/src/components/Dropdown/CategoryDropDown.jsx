import { useCategoryData } from "src/Hooks/useCategoryData";
import { BaseDropdown } from "./BaseDropdown";

export default function CategoryDropDown({ props, label, helperText }) {
  const options = useCategoryData();
  return (
    <>
      <BaseDropdown
        props={props}
        options={options}
        label={label}
        helperText={helperText}
      />
    </>
  );
}
