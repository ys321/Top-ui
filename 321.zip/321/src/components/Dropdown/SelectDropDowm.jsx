import React, { useEffect } from 'react';
import {Select, FormControl,MenuItem,InputLabel} from '@mui/material/Select';
import { useState } from 'react';

export default function SelectDropDown({ 
  id, name, label, valueParam, dataFn, filterPram, defaultValue, validator, inputHandler 
}) {
  const [options, setOptions] = useState([]);
  const [value, setValue] = useState('');

  useEffect(() => {
    (async () => {
      const response = await dataFn(filterPram);
      setOptions(response.data);

      if(defaultValue) {
        setValue(defaultValue);
      }

    })();
  }, [options.length]);
  
  return (
        <FormControl fullWidth margin='dense'>
          <InputLabel id={id}>{label}</InputLabel>
          <Select
            labelId={id}
            id={id}
            name={name}
            value={value}
            label={label}
            onChange={(e) => { setValue(e.target.value); inputHandler(e) }}
          >
              {options.map((option, index) => {
                  return (<MenuItem key={index} value={option.id}>{option[valueParam]}</MenuItem>)
              })}          
          </Select>
        </FormControl>      
  );
}