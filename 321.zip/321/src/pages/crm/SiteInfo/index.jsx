import { Breadcrumbs, Button, Checkbox, Chip, TextField, Box, Grid, Stack } from "@mui/joy";

import { Field, Form, Formik } from "formik";
import * as yup from 'yup';
import PropTypes from 'prop-types';
import { BaseDropdown } from "src/components/Dropdown/BaseDropdown";
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';

const validationSchema = yup.object({
    liftType: yup
        .string()
        .required('Lift Type is required')
        .max(20),
});
export const SiteInfo = ({ formData, setFormData, nextStep, jumpStep }) => {
    const options = [
        {
            'id': 1,
            'name': 'Hospital'
        },
        {
            'id': 2,
            'name': 'Building'
        },
        {
            'id': 3,
            'name': 'Warehouse'
        },
        {
            'id': 4,
            'name': 'Store'
        }]
    const openingSideData = [
        {
            'id': 1,
            'name': 'Yes'
        },
        {
            'id': 2,
            'name': 'No'
        },
    ]
    const machineRoomData = [
        {
            'id': 1,
            'name': 'Yes'
        },
        {
            'id': 2,
            'name': 'No'
        },
    ]
    const hoistData = [
        {
            'id': 1,
            'name': 'RCC'
        },
    ]
    return (
        <>
            <Box margin={2}>
                <Formik
                    initialValues={formData}
                    onSubmit={values => {
                        setFormData(values);
                        nextStep();
                    }}
                    validationSchema={validationSchema}
                >
                    {({ errors, touched, handleChange }) => (
                        <Form >
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={12}>
                                    <Breadcrumbs area-label="breadcrumb">
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(1)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                            endDecorator={<RadioButtonCheckedIcon fontSize="md" />}
                                        >Site Info</Chip>
                                    </Breadcrumbs>
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "liftType",
                                            onChange: handleChange,
                                            defaultValue: formData.liftType ?? '',
                                            error: errors.liftType,
                                        }}
                                        options={options}
                                        label={"Lift Type"}
                                        // helperText={'Select Valid Lift Type'}
                                        helperText={errors.liftType}
                                    />

                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="noOfBasement"
                                        label="No of Basement"
                                        variant="outlined"
                                        defaultValue={formData.noOfBasement}
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3} marginTop={4}>
                                    <Field
                                        name='groundFloor'
                                        label='Ground Floor'
                                        margin='normal'
                                        as={Checkbox}
                                        defaultValue={formData.groundFloor || ''}
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="noOfFloor"
                                        label='No of Floor'
                                        variant="outlined"
                                        defaultValue={formData.noOfFloor}
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="liftQuantity"
                                        label='Lift Quantity'
                                        defaultValue={formData.liftQuantity}
                                        variant="outlined"
                                        onChange={handleChange}
                                    />

                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="floor"
                                        label='Floor'
                                        defaultValue={formData.floor}
                                        variant="outlined"
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "openingSide",
                                            onChange: handleChange,
                                            defaultValue: formData.openingSide ?? '',
                                        }}
                                        options={openingSideData}
                                        label='All Opening at Same Side'
                                        helperText={'Select Valid Opening Side'}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name='floor_height'
                                        label='Floor Height in Meter(mtr Approx)'
                                        defaultValue={formData.floor_height}
                                        variant="outlined"
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name='noOfStops'
                                        label='No of Stops'
                                        defaultValue={formData.noOfStops}
                                        variant="outlined"
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name='noOfOpening'
                                        label='No of Opening'
                                        defaultValue={formData.noOfOpening}
                                        variant="outlined"
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name='hoistWayAvailable'
                                        label='Hoist Way Available'
                                        defaultValue={formData.hoistWayAvailable}
                                        variant="outlined"
                                        onChange={handleChange}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "hoistWayStructure",
                                            onChange: handleChange,
                                            defaultValue: formData.hoistWayStructure ?? '',
                                        }}
                                        options={hoistData}
                                        label='Hoist Way Structure'
                                        helperText={'Select Valid Hoist Way Structure'}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "machineRoomAvailable",
                                            onChange: handleChange,
                                            defaultValue: formData.machineRoomAvailable ?? '',
                                        }}
                                        options={machineRoomData}
                                        label='Machine Room Available'
                                        helperText={'Select Valid Machine Room Available'}
                                    />
                                </Grid>

                                <Grid item xs={12} md={12}>
                                    <Stack
                                        direction={"row"}
                                        justifyContent={"end"}
                                        alignItems={"center"}
                                    >
                                        <Button
                                            type='submit'
                                            variant='outlined'
                                            color='primary'
                                        >
                                            Continue to Machine Room
                                        </Button>
                                    </Stack>
                                </Grid>

                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Box>

        </>
    );
}

SiteInfo.propTypes = {
    formData: PropTypes.object.isRequired,
    setFormData: PropTypes.func.isRequired,
    nextStep: PropTypes.func.isRequired
};

export default SiteInfo;