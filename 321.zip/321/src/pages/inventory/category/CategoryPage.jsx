import {
  Box,
  Button,
  Grid,
  Modal,
  ModalClose,
  Sheet,
  Stack,
  styled,
  TextField,
  Tooltip,
  Typography,
} from "@mui/joy";
import { Form, Formik } from "formik";
import { useState } from "react";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import { categoryValidationSchema } from "./CategoryData";
import {
  createCategory,
  deleteProductCategory,
} from "src/store/slices/category/category.slice";
import { useDispatch } from "react-redux";
import { QueryKeys } from "src/services/queryKey";
import { CategoryService } from "src/services/api/CategoryService";
import { useQuery } from "@tanstack/react-query";
import CategoryCard from "src/components/cards/CategoyCard";
import NoRecordFound from "src/components/Table/NoRecordFound";
import DeleteModel from "src/components/Model/DeleteModel";
import FormControl from "@mui/joy/FormControl";
import FormLabel from "@mui/joy/FormLabel";
import MainButton from "src/components/Button/MainButton";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

const Item = styled(Sheet)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.vars.palette.text.tertiary,
}));

export default function CategoryPage() {
  const [open, setOpen] = useState(false);
  const [categories, setCategories] = useState([]);

  const dispatch = useDispatch();

  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const { isLoading, refetch: refetchCategories } = useQuery(
    [QueryKeys.getAllCategories],
    async () => {
      return CategoryService.getAll();
    },
    {
      onSuccess: (response) => {
        setCategories(response.data);
      },
      staleTime: 0,
    }
  );

  if (isLoading) {
    setTimeout(() => {
      refetchCategories();
    }, 500);
  }

  const hideAndClearCategoryDailog = () => {
    setOpen(false);
  };

  function saveCategory(values) {
    dispatch(createCategory({ values }))
      .unwrap()
      .then((res) => {
        hideAndClearCategoryDailog();
        setTimeout(() => {
          refetchCategories();
        }, 500);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  function deleteCategory(category) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: `${category.name}`,
      description: `Are you sure want to delete ${category.name} ?`,
      confrimHandler: async function () {
        dispatch(deleteProductCategory({ category }))
          .unwrap()
          .then((response) => {
            setConfirmationParams({ open: false });
            setTimeout(() => {
              refetchCategories();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }
  return (
    <>
      <Grid
        container
        sx={{ flexGrow: 1 }}
        justifyContent={"flex-end"}
        direction="row"
      >
        <Grid>
          <Item>
            <Tooltip title={`Add New Category`} variant="soft">
              <MainButton
                name={" Add New Category"}
                onClick={() => setOpen(true)}
              />
            </Tooltip>
          </Item>
        </Grid>
      </Grid>

      {categories && categories?.length > 0 ? (
        <Grid container spacing={4} justifyContent="center" marginTop={1}>
          {categories.map((category, index) => {
            return (
              <Grid item key={index}>
                <CategoryCard
                  link={`/inventory/product-category/:category_id`.replace(
                    ":category_id",
                    category.id
                  )}
                  name={category}
                  deleteHandler={() => deleteCategory(category, index)}
                />
              </Grid>
            );
          })}
        </Grid>
      ) : (
        <>
          <NoRecordFound />
        </>
      )}

      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => hideAndClearCategoryDailog()}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 800,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            Category
          </Typography>

          <Box margin={1}>
            <Formik
              initialValues={{
                name: "",
                description: "",
                identifier: "",
                image: "",
              }}
              onSubmit={async (values) => {
                saveCategory(values);
                console.log(values);
              }}
              // innerRef={formRef}
              validationSchema={categoryValidationSchema}
            >
              {({
                values,
                errors,
                handleChange,
                setValues,
                touched,
                setFieldValue,
              }) => (
                <Form>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <TextField
                        size="md"
                        margin="dense"
                        fullWidth
                        name="name"
                        label="Name"
                        variant="outlined"
                        value={values.name}
                        onChange={handleChange}
                        error={errors.name ? true : false}
                        helperText={errors.name}
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <TextField
                        size="md"
                        margin="dense"
                        fullWidth
                        name="description"
                        label="Description"
                        variant="outlined"
                        value={values.description}
                        onChange={handleChange}
                        error={errors.description ? true : false}
                        helperText={errors.description}
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <TextField
                        id="identifier"
                        label="External Identifier"
                        type="text"
                        fullWidth
                        variant="outlined"
                        defaultValue={values.identifier}
                        onChange={handleChange("identifier")}
                        error={errors.identifier ? true : false}
                        helperText={errors.identifier?.message}
                      />
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <FormControl>
                        <FormLabel>Image</FormLabel>
                        <Button
                          component="label"
                          variant="outlined"
                          starticon={<UploadFileIcon />}
                          size={"sm"}
                        >
                          Upload Image
                          <input
                            type="file"
                            accept="image/*"
                            hidden
                            onChange={(e) =>
                              setFieldValue("image", e.currentTarget.files[0])
                            }
                          />
                        </Button>
                      </FormControl>
                      <Box>{values?.image?.name}</Box>
                    </Grid>

                    <Grid item xs={12} md={12}>
                      <Stack
                        direction={"row"}
                        justifyContent={"end"}
                        alignItems={"center"}
                        spacing={2}
                      >
                        <SaveButton />
                        <CancelButton
                          onClick={() => hideAndClearCategoryDailog()}
                        />
                      </Stack>
                    </Grid>
                  </Grid>
                </Form>
              )}
            </Formik>
          </Box>
        </Sheet>
      </Modal>

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}
