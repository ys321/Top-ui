import { useState } from "react";
import { useParams } from "react-router-dom";

import { CategoryService } from "src/services/api/CategoryService";

import { Grid } from "@mui/material";

import { useQuery } from "@tanstack/react-query";

import SubCategoryListPage from "src/pages/inventory/category/sub_category/SubCategoryListPage";
// import CategoryMedia from "src/pages/inventory/category/category_media";

import { QueryKeys } from "src/services/queryKey";
// import VendorCategoryList from "./vendor_category.page";
// import { updateProductCategory } from "src/store/slices/category/category.slice";
import { AspectRatio, Box, Breadcrumbs, Link, Sheet } from "@mui/joy";
import CategoryForm from "./CategoryForm";

function CategoryDetails() {
  const { category_id } = useParams();
  const [productCategory, setProductCategory] = useState({});
  const [subCategories, setSubCategories] = useState([]);

  const { isLoading, error, data, refetch } = useQuery(
    [QueryKeys.getCategory],
    async () => {
      return await CategoryService.get(category_id);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setProductCategory(response.data);
        setSubCategories(response.data.sub_category);
      },
      staleTime: 0,
    }
  );

  return (
    <>
      <Grid>
        <Grid item>
          <Breadcrumbs aria-label="breadcrumb">
            <Link underline="hover" color="neutral" fontSize="inherit" href="/">
              Top Lift
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href="/inventory/product-category"
            >
              Category
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={""}
              aria-current="page"
            >
              {productCategory.name}
            </Link>
          </Breadcrumbs>
        </Grid>

        <Box padding={4}>
          <Sheet
            variant="outlined"
            sx={{
              display: "flex",
              gap: 2,
              p: 2,
              minWidth: 300,
              borderRadius: "sm",
            }}
          >
            <Grid container spacing={4}>
              <Grid item xs={12} md={5}>
                <AspectRatio
                  objectFit="contain"
                  sx={{
                    flexBasis: 300,
                    borderRadius: "sm",
                    overflow: "auto",
                  }}
                >
                  <img
                    src={productCategory.image}
                    srcSet={productCategory.image}
                    alt=""
                  />
                </AspectRatio>
              </Grid>
              <Grid item xs={12} md={7}>
                <CategoryForm categoryID={category_id} />
              </Grid>
            </Grid>
          </Sheet>
        </Box>

        <Box padding={2}>
          <SubCategoryListPage
            subCategories={subCategories}
            category_id={category_id}
            refetch={refetch}
            isLoading={isLoading}
          />
        </Box>
      </Grid>
    </>
  );
}

export default CategoryDetails;
