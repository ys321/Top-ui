import {
  Box,
  Grid,
  IconButton,
  Link,
  Paper,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";
import DeleteIcon from "@mui/icons-material/Delete";
import {  useState } from "react";
import { vendorValidationSchema } from "src/utils/validation/product.validation";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { useQuery } from "@tanstack/react-query";
import { CategoryService } from "src/services/api/CategoryService";
import { QueryKeys } from "src/services/queryKey";
import { useDispatch } from "react-redux";
import {
  createCategoryVendorLink,
  deleteCategoryVendorLink,
} from "src/store/slices/category/category.slice";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { Modal, ModalClose, Sheet, Typography, Button, Stack } from "@mui/joy";
import { VendorDropdown } from "src/components/Dropdown/VendorDropdown";
import { Form, Formik } from "formik";
import MainButton from "src/components/Button/MainButton";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

export default function VendorCategoryList({ category }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(vendorValidationSchema),
  });
  const [open, showVendorModel] = useState(false);
  const [vendorDailog, setVendorDailog] = useState(false);

  const [vendor, setVendor] = useState({});
  console.log(vendor);
  const [vendors, setVendors] = useState([]);

  const [conformationParams, setConfirmationParams] = useState({ open: false });


  const handleClose = () => {
    setConfirmationParams({ open: false });
  };

  const handleOpen = () => {
    setConfirmationParams({ open: true });
  };

  const dispatch = useDispatch();

  const { isLoading, data, error, refetch } = useQuery(
    [QueryKeys.getCategory],
    async () => {
      const reponse = await CategoryService.get(category);
      return reponse;
    },
    {
      onSuccess: (response) => {
        setVendors(response.data.vendors);
      },
      staleTime: 0,
    }
  );

  function saveCategoryVendorLink(values) {
    dispatch(createCategoryVendorLink({ values }))
      .unwrap()
      .then((response) => {
        hideAndClearVendorDailog(false);
        setTimeout(() => {
          refetch();
        }, 500);
        setVendor({});
      })
      .catch((error) => {
        console.log(error);
      });
  }

  const hideAndClearVendorDailog = () => {
    showVendorModel(false);
    reset();
    setVendor("");
    setVendorDailog("CREATE");
  };

  function vendorInputHadnler(e, dropDown = null) {
    console.log(dropDown);

    setVendor(dropDown);
  }

  function deleteVendorHandler(vendor) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Category Vendor Unlink",
      description: `Are you sure want to delete ${vendor.name} ?`,
      confrimHandler: async function () {
        console.log(category);
        console.log(vendor.id);
        vendor.category = category;
        dispatch(deleteCategoryVendorLink({ category, vendor }))
          .unwrap()
          .then((res) => {
            handleClose();
            setTimeout(() => {
              refetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  return (
    <>
      <>{isLoading ? <h1>Loading...</h1> : <></>}</>
      <div></div>

      <div>
        <Modal
          aria-labelledby="modal-title"
          aria-describedby="modal-desc"
          open={conformationParams.open}
          onClose={() => {
            handleClose();
          }}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Sheet
            variant="outlined"
            sx={{
              maxWidth: 500,
              borderRadius: "md",
              p: 3,
              boxShadow: "lg",
            }}
          >
            <ModalClose
              variant="outlined"
              sx={{
                top: "calc(-1/4 * var(--IconButton-size))",
                right: "calc(-1/4 * var(--IconButton-size))",
                boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
                borderRadius: "50%",
                bgcolor: "background.body",
              }}
            />
            <Typography
              component="h2"
              id="modal-title"
              level="h4"
              textColor="inherit"
              fontWeight="lg"
              mb={1}
            >
              {conformationParams.title}
            </Typography>
            <Typography id="modal-desc" textColor="text.tertiary">
              {conformationParams.description}
            </Typography>

            <Grid container marginTop={1} spacing={1}>
              <Grid item xs={12} md={6}>
                <Button
                  fullWidth
                  variant="solid"
                  color="success"
                  onClick={() => {
                    handleClose();
                  }}
                >
                  {conformationParams.cencelTitle}
                </Button>
              </Grid>
              <Grid item xs={12} md={6}>
                <Button
                  fullWidth
                  variant="solid"
                  color="danger"
                  onClick={conformationParams.confrimHandler}
                >
                  {conformationParams.confrimTitle}
                </Button>
              </Grid>
            </Grid>
          </Sheet>
        </Modal>
      </div>

      <Grid container spacing={10} justifyContent={"flex-end"} marginBottom={2}>
        <Grid item xs={5} md={2} sm={5}>
          <MainButton
            name={"Link Vendors"}
            onClick={() => {
              showVendorModel(true);
            }}
          />
        </Grid>
      </Grid>

      <Box style={{ padding: "10px" }}>
        <Grid container spacing={3} justifyContent={"flex-end"}>
          {vendors && vendors?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell>Code</StyledTableCell>
                      <StyledTableCell>Type</StyledTableCell>
                      <StyledTableCell>Name</StyledTableCell>
                      <StyledTableCell>Billing Name</StyledTableCell>
                      <StyledTableCell>Contact Person</StyledTableCell>
                      <StyledTableCell>Phone</StyledTableCell>
                      <StyledTableCell>Email</StyledTableCell>
                      <StyledTableCell>Website</StyledTableCell>
                      <StyledTableCell>City</StyledTableCell>
                      <StyledTableCell>GST</StyledTableCell>

                      <StyledTableCell>Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {vendors.map((vendor, index) => (
                      <StyledTableRow key={index}>
                        <StyledTableCell>
                          <Link
                            href={`/vendor/:vendor_id`.replace(
                              ":vendor_id",
                              vendor.id
                            )}
                          >
                            {vendor.code}
                          </Link>
                        </StyledTableCell>
                        <StyledTableCell>
                          {vendor.vendor_type.name}
                        </StyledTableCell>
                        <StyledTableCell>{vendor.name}</StyledTableCell>
                        <StyledTableCell>{vendor.billing_name}</StyledTableCell>
                        <StyledTableCell>
                          {vendor.contact_person_name}
                        </StyledTableCell>
                        <StyledTableCell>{vendor.phone}</StyledTableCell>
                        <StyledTableCell>{vendor.email}</StyledTableCell>
                        <StyledTableCell>{vendor.website}</StyledTableCell>
                        <StyledTableCell>{vendor?.city?.name}</StyledTableCell>
                        <StyledTableCell>{vendor.gst}</StyledTableCell>
                        <StyledTableCell>
                          <IconButton
                            area-label="delete"
                            size="large"
                            color="error"
                            onClick={() => {
                              deleteVendorHandler(vendor);
                            }}
                          >
                            <DeleteIcon fontSize="inherit" />
                          </IconButton>
                        </StyledTableCell>
                      </StyledTableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Box>

      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => hideAndClearVendorDailog()}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 800,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            Link Vendor to Category
          </Typography>
          <Box margin={1}>
            <Formik
              initialValues={{
                vendor: "",
                category: category,
              }}
              onSubmit={async (values) => {
                saveCategoryVendorLink(values);
                console.log(values);
              }}
              // innerRef={formRef}
              validationSchema={vendorValidationSchema}
            >
              {({
                values,
                errors,
                handleChange,
                setValues,
                touched,
                setFieldValue,
              }) => (
                <Form>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={12}>
                      <VendorDropdown
                        props={{
                          name: "vendor",
                          placeholder: "Select Vendor",
                          size: "md",
                          value: values.vendor || "",
                          onChange: handleChange,
                          error: errors.vendor,
                        }}
                        label={"Select Vendor"}
                        helperText={errors.vendor}
                      />
                    </Grid>
                    <Grid item xs={12} md={12}>
                      <Stack
                        direction={"row"}
                        justifyContent={"end"}
                        alignItems={"center"}
                        spacing={2}
                      >
                        <SaveButton />
                        <CancelButton
                          onClick={() => hideAndClearVendorDailog()}
                        />
                      </Stack>
                    </Grid>
                  </Grid>
                </Form>
              )}
            </Formik>
          </Box>
        </Sheet>
      </Modal>
    </>
  );
}
