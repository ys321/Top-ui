import * as yup from "yup";

const errorMessage = {
  name: "Sub Category Name is Required",
  value: "Value is Required",
};

export const subCategorySchema = yup.object().shape({
  name: yup.string().required(errorMessage.name).typeError(errorMessage.name),
});

export const attributeValueValidationSchema = yup.object().shape({
  value: yup
    .string()
    .required(errorMessage.value)
    .typeError(errorMessage.value),
});
