import React, { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
} from "@mui/material";

import {
  Stack,
  Grid,
  Breadcrumbs,
  Button,
  Link,
  TextField,
  Modal,
  Sheet,
  ModalClose,
  Typography,
  Tooltip,
  Card,
  AspectRatio,
  List,
  ListItem,
  ListItemButton,
} from "@mui/joy";

import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";

import { subCategoryAttibuteSchema } from "src/utils/validation/category.validation";
import { CategoryService } from "src/services/api/CategoryService";
import ProductTable from "src/pages/inventory/products/ProductTable";
import ProductForm from "../../products/ProductForm";

import { ProductService } from "src/services/api/ProductService";

import { QueryKeys } from "src/services/queryKey";
import VendorCategoryList from "../VendorCategoryList";
import SubCategoryForm from "./SubCategoryForm";
import SearchIcon from "@mui/icons-material/Search";
import NoRecordFound from "src/components/Table/NoRecordFound";
import SubCategoryModel from "./Model/SubCategoryModel";
import MainButton from "src/components/Button/MainButton";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

function SubCategoryDetailPage() {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(subCategoryAttibuteSchema),
  });

  const { category_id, sub_category_id } = useParams();
  const [category, setCategory] = useState({});
  const [subCategory, setSubCategory] = useState({});

  const [page, setPage] = useState(1);
  const [products, setProducts] = useState([]);
  const [productDailog, setProductDailog] = useState(false);

  const [attributeDailog, setAttirbuteDialog] = useState(false);
  const [attributes, setAttributes] = useState([]);

  // Filter Atrribute Search
  const [filteredData, setFilteredData] = useState([]);
  const [filterName, setFilterName] = useState("");

  const [filteredValue, setFilteredValue] = useState([]);

  const [attributeValues, setAttributeValues] = useState([]);

  const [attribute, setAttribute] = useState({});
  const [attributeAction, setAttributeAction] = useState("CREATE");

  const [attributeValue, setAttributeValue] = useState({});
  const [attributeValueDailog, setAttirbuteValueDialog] = useState(false);
  const [attributeValueAction, setAttributeValueAction] = useState("CREATE");

  const [currentAttribute, setCurrentAttribute] = useState();

  const [value, setTabValue] = React.useState("1");

  const handleChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const { isLoading: productLoading, refetch: productRefetch } = useQuery(
    [QueryKeys.getAllProducts, page],
    async () => {
      return await ProductService.getAll({
        page: page,
        filter: `category=${category_id}&sub_category=${sub_category_id}`,
      });
    },
    {
      onSuccess: (response) => {
        setProducts(response.data);
      },
      staleTime: 0,
    }
  );

  const {
    isLoading: categoryLoading,
    error,
    data,
  } = useQuery(
    [QueryKeys.getCategory],
    async () => {
      return await CategoryService.get(category_id);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setCategory(response.data);
      },
      staleTime: 0,
    }
  );

  const { isLoading: subCategoryLoading } = useQuery(
    [QueryKeys.getSubCategory],
    async () => {
      return await CategoryService.SubCategoryService.get(sub_category_id);
    },
    {
      onSuccess: (response) => {
        setSubCategory(response.data);
      },
      staleTime: 0,
    }
  );

  const { isLoading, refetch: referchAttributes } = useQuery(
    [QueryKeys.getAllAttributes],
    async () => {
      return await CategoryService.SubCategoryService.AttributeService.getAll(
        sub_category_id
      );
    },
    {
      onSuccess: (response) => {
        setAttributes(response.data.attributes);
        setFilteredData(response.data.attributes);
      },
      staleTime: 0,
    }
  );

  const handleSearch = (event) => {
    let value = event.target.value;
    setFilterName(value);
    let result = [];
    result = attributes.filter((data) => {
      return data.name.search(value) != -1;
    });
    setFilteredData(result);
  };

  const { mutate: saveAttribute } = useMutation(
    async () => {
      let response = null;
      attribute.sub_category = subCategory.id;
      switch (attributeAction) {
        case "CREATE":
          response =
            await CategoryService.SubCategoryService.AttributeService.create(
              attribute
            );
          return response.data;
        case "UPDATE":
          response =
            await CategoryService.SubCategoryService.AttributeService.update(
              attribute.id,
              attribute
            );
          return response.data;
      }
    },
    {
      onSuccess: (response) => {
        hideAndClearAttributeDailog();
        referchAttributes();
      },
    }
  );

  const { mutate: saveAttributeValue } = useMutation(
    async () => {
      let response = null;
      attributeValue.attribute = currentAttribute?.id;

      switch (attributeValueAction) {
        case "CREATE":
          response =
            await CategoryService.SubCategoryService.AttributeService.addValue(
              attributeValue
            );
          return response;
        case "UPDATE":
          response =
            await CategoryService.SubCategoryService.AttributeService.updateValue(
              attributeValue.id,
              attributeValue
            );
          return response;
      }
    },
    {
      onSuccess: (response) => {
        hideAndClearAttributeValueDailog();
        referchAttributes();
      },
    }
  );

  function productCategoryInputHandler(e) {
    const { name, value } = e.target;

    setSubCategory({
      ...subCategory,
      [name]: value,
    });
  }

  function attributeInputHandler(e) {
    const { name, value } = e.target;
    if (!value) return;

    setAttribute({
      ...attribute,
      [name]: value,
    });
  }

  function attributeValueInputHandler(e) {
    const { name, value } = e.target;
    if (!value) return;

    setAttributeValue({
      ...attributeValue,
      [name]: value,
    });
  }

  function hideAndClearAttributeDailog() {
    setAttirbuteDialog(false);
    setAttribute({});
    reset();
    setAttributeAction("CREATE");
  }

  function hideAndClearAttributeValueDailog() {
    setAttirbuteValueDialog(false);
    setAttributeValue({});
    reset();
    setAttributeValueAction("CREATE");
  }

  function preapreForUpdate(attr) {
    setAttribute(attr);
    setAttirbuteDialog(true);
    setAttributeAction("UPDATE");
  }

  function preapreForUpdateAttributeValue(value) {
    setAttributeValue(value);
    setAttirbuteValueDialog(true);
    setAttributeValueAction("UPDATE");
  }

  if (productLoading) {
    return (
      <>
        <h1>Loading...</h1>
      </>
    );
  }

  return (
    <>
      <Grid>
        <Grid item>
          <Breadcrumbs aria-label="breadcrumb">
            <Link underline="hover" color="neutral" fontSize="inherit" href="/">
              Top Lift
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href="/inventory/product-category"
            >
              Category
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={`/inventory/product-category/:category_id`.replace(
                ":category_id",
                category_id
              )}
              aria-current="page"
            >
              {category.name}
            </Link>

            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={""}
              aria-current="page"
            >
              {subCategory.name}
            </Link>
          </Breadcrumbs>
        </Grid>

        <Box padding={4}>
          <Sheet
            variant="outlined"
            sx={{
              display: "flex",
              gap: 2,
              p: 2,
              minWidth: 300,
              borderRadius: "sm",
            }}
          >
            <Grid container spacing={4}>
              <Grid item xs={12} md={5}>
                <AspectRatio
                  objectFit="contain"
                  sx={{
                    flexBasis: 300,
                    borderRadius: "sm",
                    overflow: "auto",
                  }}
                >
                  <img
                    src={subCategory.image}
                    srcSet={subCategory.image}
                    alt=""
                  />
                </AspectRatio>
              </Grid>
              <Grid item xs={12} md={7}>
                <SubCategoryForm
                  categoryID={category_id}
                  sub_category_id={sub_category_id}
                  data={subCategory}
                  productCategoryInputHandler={productCategoryInputHandler}
                />
              </Grid>
            </Grid>
          </Sheet>
        </Box>

        <Grid item md={12} xs={12} padding={3}>
          <Box sx={{ width: "100%", typography: "body1" }}>
            <TabContext value={value}>
              <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                <TabList
                  onChange={handleChange}
                  aria-label="lab API tabs example"
                >
                  <Tab label="Attributes" value="1" />
                  <Tab label="Product" value="2" />
                  <Tab label="Vendor" value="3" />
                </TabList>
              </Box>

              <TabPanel value="1">
                {subCategoryLoading ? (
                  <>
                    <h1>Loading...</h1>
                  </>
                ) : (
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={12}>
                      <>
                        <Grid item xs={12} md={12}>
                          <Stack
                            flexDirection={"row"}
                            justifyContent={"space-between"}
                          >
                            <Typography fontWeight="lg" fontSize={30}>
                              Attributes
                            </Typography>

                            <Tooltip title={`Add New Attribute`} variant="soft">
                              <MainButton
                                name={"Add New Attribute"}
                                onClick={() => {
                                  setAttirbuteDialog(true);
                                }}
                              />
                            </Tooltip>
                          </Stack>
                        </Grid>
                        <Grid container marginTop={1}>
                          <Grid item xs={12} md={3}>
                            <TextField
                              size="md"
                              margin="dense"
                              fullWidth
                              name="name"
                              label="Search Attribute"
                              variant="soft"
                              value={filterName || ""}
                              onChange={(event) => handleSearch(event)}
                              startDecorator={<SearchIcon />}
                            />
                          </Grid>
                        </Grid>

                        {attributes && attributes?.length > 0 ? (
                          <Grid container spacing={2} marginTop={1}>
                            {filteredData ? (
                              <>
                                {filteredData?.map((attr, i) => {
                                  return (
                                    <Grid item key={i}>
                                      <Card
                                        variant="outlined"
                                        row
                                        sx={{
                                          width: 300,
                                          "&:hover": {
                                            boxShadow: "md",
                                            borderColor:
                                              "neutral.outlinedHoverBorder",
                                            cursor: "pointer",
                                          },
                                          marginBottom: "15px",
                                        }}
                                      >
                                        <Stack sx={{ width: "100%" }}>
                                          <Stack
                                            direction={"row"}
                                            alignItems={"center"}
                                            justifyContent={"space-between"}
                                          >
                                            <Typography
                                              key={i}
                                              level="display2"
                                              fontSize="20px"
                                              mb={0.5}
                                              onClick={() => {
                                                preapreForUpdate(attr);
                                              }}
                                            >
                                              {attr?.name}
                                            </Typography>
                                            <Stack
                                              direction={"row"}
                                              spacing={1}
                                            >
                                              <MainButton
                                                name={"Add Values"}
                                                onClick={() => {
                                                  setAttirbuteValueDialog(true);
                                                  setCurrentAttribute(attr);
                                                }}
                                              />
                                            </Stack>
                                          </Stack>

                                          <Stack
                                            direction={"row"}
                                            spacing={1}
                                            marginTop={2}
                                          >
                                            <Sheet
                                              variant="outlined"
                                              sx={{
                                                width: 320,
                                                maxHeight: 250,
                                                overflow: "auto",
                                                borderRadius: "sm",
                                              }}
                                            >
                                              {attr?.values.map(
                                                (value, valueIdx) => {
                                                  return (
                                                    <div
                                                      key={valueIdx}
                                                      style={{
                                                        display: "flex",
                                                        flexWrap: "wrap",
                                                        gap: "1px",
                                                      }}
                                                    >
                                                      <List>
                                                        <ListItem
                                                          key={valueIdx}
                                                        >
                                                          <ListItemButton
                                                            onClick={() => {
                                                              preapreForUpdateAttributeValue(
                                                                value
                                                              );
                                                            }}
                                                          >
                                                            {value.value}
                                                          </ListItemButton>
                                                        </ListItem>
                                                      </List>
                                                    </div>
                                                  );
                                                }
                                              )}
                                            </Sheet>
                                          </Stack>
                                        </Stack>
                                      </Card>
                                    </Grid>
                                  );
                                })}
                              </>
                            ) : (
                              <>
                                {attributes?.map((attr, i) => {
                                  return (
                                    <Grid item key={i}>
                                      <Card
                                        variant="outlined"
                                        row
                                        sx={{
                                          width: 300,
                                          "&:hover": {
                                            boxShadow: "md",
                                            borderColor:
                                              "neutral.outlinedHoverBorder",
                                            cursor: "pointer",
                                          },
                                          marginBottom: "15px",
                                        }}
                                      >
                                        <Stack sx={{ width: "100%" }}>
                                          <Stack
                                            direction={"row"}
                                            alignItems={"center"}
                                            justifyContent={"space-between"}
                                          >
                                            <Typography
                                              key={i}
                                              level="display2"
                                              fontSize="20px"
                                              mb={0.5}
                                              onClick={() => {
                                                preapreForUpdate(attr);
                                              }}
                                            >
                                              {attr?.name}
                                            </Typography>
                                            <Stack
                                              direction={"row"}
                                              spacing={1}
                                            >
                                              <Button
                                                variant="solid"
                                                size="sm"
                                                onClick={() => {
                                                  setAttirbuteValueDialog(true);
                                                  setCurrentAttribute(attr);
                                                }}
                                              >
                                                Add Values
                                              </Button>
                                            </Stack>
                                          </Stack>

                                          <Stack
                                            direction={"row"}
                                            spacing={1}
                                            marginTop={2}
                                          >
                                            <Sheet
                                              variant="outlined"
                                              sx={{
                                                width: 320,
                                                maxHeight: 250,
                                                overflow: "auto",
                                                borderRadius: "sm",
                                              }}
                                            >
                                              {attr?.values.map(
                                                (value, valueIdx) => {
                                                  return (
                                                    <div
                                                      key={valueIdx}
                                                      style={{
                                                        display: "flex",
                                                        flexWrap: "wrap",
                                                        gap: "1px",
                                                      }}
                                                    >
                                                      <List>
                                                        <ListItem
                                                          key={valueIdx}
                                                        >
                                                          <ListItemButton
                                                            onClick={() => {
                                                              preapreForUpdateAttributeValue(
                                                                value
                                                              );
                                                            }}
                                                          >
                                                            {value.value}
                                                          </ListItemButton>
                                                        </ListItem>
                                                      </List>
                                                    </div>
                                                  );
                                                }
                                              )}
                                            </Sheet>
                                          </Stack>
                                        </Stack>
                                      </Card>
                                    </Grid>
                                  );
                                })}
                              </>
                            )}
                          </Grid>
                        ) : (
                          <>
                            <NoRecordFound />
                          </>
                        )}
                      </>
                    </Grid>
                  </Grid>
                )}
              </TabPanel>
              <TabPanel value="2">
                <>
                  <Grid container spacing={2} padding={2}>
                    <Grid item xs={5} md={2} sm={5}>
                      <MainButton
                        name={" Add New Product"}
                        onClick={() => setProductDailog(true)}
                      />

                      <Dialog
                        maxWidth="lg"
                        fullWidth
                        open={productDailog}
                        onClose={() => {
                          setProductDailog(false);
                        }}
                      >
                        <DialogTitle>Product</DialogTitle>
                        <DialogContent>
                          <ProductForm
                            dailogHandler={setProductDailog}
                            successCallback={productRefetch}
                            data={{
                              category: {
                                id: category_id,
                              },
                              sub_category: {
                                id: sub_category_id,
                              },
                            }}
                          />
                        </DialogContent>
                      </Dialog>
                    </Grid>
                    <Grid item xs={12} md={12}>
                      <ProductTable
                        rows={products}
                        paginationHelper={setPage}
                        successCallback={productRefetch}
                      />
                    </Grid>
                  </Grid>
                </>
              </TabPanel>
              <TabPanel value="3">
                <VendorCategoryList category={category_id} />
              </TabPanel>
            </TabContext>
          </Box>
        </Grid>
      </Grid>
      <>
        {/* add attribute dialog */}
        <SubCategoryModel
          open={attributeDailog}
          close={() => hideAndClearAttributeDailog()}
          name={`Attribute`}
          textFieldName={"name"}
          label={`Attribute Name`}
          save={saveAttribute}
          handleSubmit={handleSubmit}
          defaultValue={attribute?.name}
          inputHandler={(e) => {
            attributeInputHandler(e);
          }}
          register={register}
          errors={errors}
        />
      </>
      <>
        {/* add attribute values dailog */}
        <Modal
          aria-labelledby="modal-title"
          aria-describedby="modal-desc"
          open={attributeValueDailog}
          onClose={() => hideAndClearAttributeValueDailog()}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Sheet
            variant="outlined"
            sx={{
              maxWidth: 500,
              borderRadius: "md",
              p: 3,
              boxShadow: "lg",
            }}
          >
            <ModalClose
              variant="outlined"
              sx={{
                top: "calc(-1/4 * var(--IconButton-size))",
                right: "calc(-1/4 * var(--IconButton-size))",
                boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
                borderRadius: "50%",
                bgcolor: "background.body",
              }}
            />
            <Typography
              component="h2"
              id="modal-title"
              level="h4"
              textColor="inherit"
              fontWeight="lg"
              mb={1}
            >
              Attribute value
            </Typography>
            <Grid container>
              <Grid item xs={12} md={12}>
                <TextField
                  fullWidth
                  margin="dense"
                  type={"text"}
                  variant={"outlined"}
                  id="value"
                  name="value"
                  label={`Value Name`}
                  defaultValue={attributeValue.value}
                  onChange={(e) => {
                    attributeValueInputHandler(e);
                  }}
                  error
                  helperText="Value Field is Required"
                  {...setValue("value", attributeValue.value)}
                  required
                />
              </Grid>
              <Grid item xs={12} md={12}>
                <Stack
                  direction={"row"}
                  justifyContent={"end"}
                  alignItems={"center"}
                  spacing={2}
                >
                  <SaveButton onClick={saveAttributeValue} disabled={!attributeValue.value} />
                  <CancelButton
                    onClick={() => hideAndClearAttributeValueDailog()}
                  />
                </Stack>
              </Grid>
            </Grid>
          </Sheet>
        </Modal>
      </>
    </>
  );
}

export default SubCategoryDetailPage;
