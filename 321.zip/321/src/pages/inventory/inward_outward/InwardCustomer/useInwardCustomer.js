import { createAsyncThunk } from "@reduxjs/toolkit";
import { useFormik } from "formik";
import moment from "moment";
import { useDispatch } from "react-redux";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { errorAlert, successAlert, warningAlert } from "src/store/slices/alert.slice";
import { toggleProcess } from "src/store/slices/process.slice";
import * as yup from "yup";

const errorMessage = {
  inward_date: "Please Select Inward Date",
  location: "Please Select Valid Location",
  branch: "Make sure you have valid branch in your Material Request",
  material_request: "Please set valid Material Request",
  mr_date: "Please Select Material Request Date",
  customer_name: "Please Enter Customer Name",
  transport: "Please Enter Transport Name",
  lr_number: "Please Enter LR Number",
  lr_date: "Please Select LR Date",
  received_date: "Please Select Received Date",
  supplier_bill_no: "Please Provide Supplier Bill No",
  supplier_bill_date: "Please Select Supplier Bill Date",
  remarks: "Please make sure your remarks if you have any within 500 characters",

  //entries message
  product: "Product Not Added",
  order_qty: "Please provide Valid Ordered Quentity",
  received_qty: "Please set received quantity",
  rate_per_qty: "Please set basic rate for each quatity",
  amount: "Please set valid amount for single quanity",
  specification: "Please check specifiction, if everything is okay with your order",
};

const inventoryLocationSchema = yup.object().shape({
  floor: yup.number().integer().optional().nullable().typeError('Please select valid Floor'),
  section: yup.number().integer().optional().nullable().typeError('Please select valid Section'),
  rack: yup.number().integer().optional().nullable().typeError('Please select valid Rack'),
  shelf: yup.number().integer().optional().nullable().typeError('Please select valid Shelf'),
  bin: yup.number().integer().optional().nullable().typeError('Please select valid Bin'),
  qty: yup.number().integer().optional().nullable().typeError('Please set valid Quantity for product')
});

let date_today = moment().tz(moment.tz.guess()).format("YYYY-MM-DD");
let initialValues = {
  date: "" || date_today,
  location: "",
  customer_name: "",
  remarks: "",
  entries: [],
  action: "save",
};

const inwardEntriesSchema = yup.object().shape({
  product: yup.number().nullable().required(errorMessage.product).typeError(errorMessage.product),
  location: yup.number().nullable().required(errorMessage.location).typeError(errorMessage.location),
  ordered_qty: yup.number().integer().required(errorMessage.order_qty).typeError(errorMessage.order_qty),
  received_qty: yup.number().integer().required(errorMessage.received_qty).typeError(errorMessage.received_qty),
  rate_per_qty: yup.number().required(errorMessage.basic_rate).typeError(errorMessage.basic_rate),
  amount: yup.number().required().typeError(),
  specification: yup.boolean().required(errorMessage.specification).typeError(errorMessage.specification),
  inventory_location: yup.array().of(inventoryLocationSchema).
    min(1, 'You have distribute your product based on your warehouse location')
});

export const inwardSchema = yup.object().shape({
  branch: yup.number().nullable().required(errorMessage.branch).typeError(errorMessage.branch),
  customer_name: yup.string().required(errorMessage.customer_name).typeError(errorMessage.customer_name),
  entries: yup.array(yup.object({
    received_qty: yup.number().integer().required(errorMessage.received_qty).typeError(errorMessage.received_qty).min(1, 'You Have to set More Then 0 Quantity'),
  })),
});

let inventoryLocationInitialValues = {
  inventory_location_entry: '',
  floor: '',
  section: '',
  rack: '',
  shelf: '',
  bin: '',
  qty: ''
};


let inwardEntriesIntialValues = {
  product: '',
  location: '',
  ordered_qty: 0,
  received_qty: 0,
  rate_per_qty: 0,
  amount: 0,
  specification: false,
  inventory_location: []
}


let inwardIntialValues = {
  date: moment().utc().tz(moment.tz.guess()).format('YYYY-MM-DD'),
  location: '',
  branch: '',
  material_request: '',
  customer_name: '',
  transport: '',
  lr_number: '',
  lr_date: '',
  received_date: '',
  supplier_bill_no: '',
  supplier_bill_date: '',
  remarks: '',
  entries: [],
};

export const createInwardFromCustomer = createAsyncThunk(
  "@inwardFromCustomer/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true
      })
    );
    (async () => {
      const res = await InwardOutwardService.InwardCustomer.create(params.values);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: 'Inward From Customer',
            message: 'Inward From Customer Create Successfully'
          })
        )
      })
      .catch((e) => {
        dispatch(
          warningAlert({
            visible: true,
            title: 'Inward From Customer Create Failed',
            message: e.error.response.data.details,
          })
        )
      })
  }
)

export const updateInwardFromCustomer = createAsyncThunk(
  "@updateInwardFromCustomer/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await InwardOutwardService.InwardCustomer.update(params.values, params.inward_Customer_id);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: 'Inward From Customer',
            message: 'Inward From Customer Update Successfully'
          })
        )
      })
      .catch((e) => {
        dispatch(
          warningAlert({
            visible: true,
            title: 'Inward From Customer Update Failed',
            message: e.error.response.data.details
          })
        )
      })

  }
)

export const deleteInwardFromCustomer = createAsyncThunk(
  "@inwardFromCustomer/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await InwardOutwardService.InwardCustomer.remove(params.currentRow.id);
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: 'Inward From Customer',
            message: 'Inward From Customer Delete Successfully'
          })
        )
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: 'Inward From Customer Delete Failed',
            message: 'Inward From Customer Delete Failed'
          })
        )
      })
  }
)

const saveInwardCustomer = createAsyncThunk("inwardCustomer/save", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );

  const { action } = params;

  if (action === "save") {
    InwardOutwardService.InwardCustomer.create(params)
      .then((res) => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );

        dispatch(
          successAlert({
            visible: true,
            title: "New Inward Customer",
            message: "New Inward Customer has been Saved !",
          })
        );
        callback?.();
      })
      .catch(() => {
        dispatch(
          errorAlert({
            visible: true,
            title: "New Inward Customer",
            message: "Failed to save Inward Customer :(",
          })
        );
      })
      .finally(() => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );
      });
  }
  if (action === "update") {
    InwardOutwardService.InwardCustomer.update(params?.id, params)
      .then(() => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );
        dispatch(
          successAlert({
            visible: true,
            title: "Update Inward Customer",
            message: "Inward Customer has been Saved !",
          })
        );
        callback?.();
      })
      .catch(() => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Update Inward Customer",
            message: "Failed to save Inward Customer",
          })
        );
      })
      .finally(() => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );
      });
  }
});

export const useInwardCustomer = (props) => {
  const { onSuccess, dataObj } = props;
  const dispatch = useDispatch();

  let finalInitValues = initialValues;
  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: inwardSchema,
    validateOnChange: true,
    onSubmit: (values, { ressetForm }) => {
      console.log(values);
      const callback = () => {
        ressetForm?.();
        onSuccess?.();
      };

      const params = { ...values, callback };
      dispatch(saveInwardCustomer(params));
    },
  });
  return {
    formik,
    onSave: formik.handleSubmit,
  };
};

export const useInwardEntries = (props) => {
  const { onSuccess, dataObj } = props;

  let finalInitValues = inwardEntriesIntialValues;

  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: inwardEntriesSchema,
    validateOnChange: false,
    onSubmit: (values, { resetForm }) => {
      const callback = () => {
        onSuccess?.();
      };
      callback();
      console.log(values);
    },
  });
  return {
    formik,
    onEntrySave: formik.handleSubmit,
  };
};

export const useInventoryLocation = (props) => {
  const { onSuccess, dataObj } = props;
  let finalInitValues = inventoryLocationInitialValues;

  if (dataObj) {
    finalInitValues = dataObj;
  }

  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: inventoryLocationSchema,
    validateOnChange: false,
    onSubmit: (values, { resetForm }) => {
      const callback = () => {
        onSuccess?.();
      };
      callback();
      console.log(values);
    },
  });
  return {
    formik,
    onEntrySave: formik.handleSubmit,
  };
};