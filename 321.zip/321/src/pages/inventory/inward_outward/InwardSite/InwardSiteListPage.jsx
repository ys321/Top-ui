import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import {  useState } from "react";
import {
  StyledTableCell,
  StyledTableRow,
  Transition,
} from "src/components/Table/TableStyle";
import { useNavigate } from "react-router-dom";
import {  Chip } from "@mui/joy";
import { useQuery } from "@tanstack/react-query";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import NoRecordFound from "src/components/Table/NoRecordFound";
import DeleteIcon from "@mui/icons-material/Delete";
import TOPButton from "src/components/Button/TopButton";
import { useDispatch } from "react-redux";
import { deleteInwardFromSite } from "./useInwardSite";
import MainButton from "src/components/Button/MainButton";

export default function InwardSiteListPage() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [inwardSite, setInwardSite] = useState([]);
  const [currentRow, setCurrentRow] = useState();
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const { isLoading, refetch } = useQuery(
    ["getAllInwardFromSite"],
    async () => {
      return await InwardOutwardService.InwardSite.getAll();
    },
    {
      onSuccess: (response) => {
        console.log(response.data);
        setInwardSite(response.data);
      },
      staleTime: 0,
    }
  );

  function deleteRow() {
    dispatch(deleteInwardFromSite({ currentRow }))
      .unwrap()
      .then((res) => {
        handleClose();
        setTimeout(() => {
          refetch();
        }, 500);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  if (isLoading) {
    return <>...Loading</>;
  }

  function addInwadFromSite() {
    navigate(`/inventory/inward-site/form`);
  }
  return (
    <>
      <Grid container spacing={1} padding={2}>
        <Grid item xs={12} md={12}>
          <MainButton name={"ADD NEW"} onClick={addInwadFromSite} />
        </Grid>
        <Grid item xs={12} md={12}>
          {inwardSite && inwardSite?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customize Table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align="center">ID</StyledTableCell>
                      <StyledTableCell align="center">Date</StyledTableCell>
                      <StyledTableCell align="center">
                        Site Name
                      </StyledTableCell>
                      <StyledTableCell align="center">
                        Location Name
                      </StyledTableCell>
                      <StyledTableCell align="center">Remarks</StyledTableCell>
                      <StyledTableCell align="center">Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {inwardSite?.map((site, index) => {
                      return (
                        <StyledTableRow key={index}>
                          <StyledTableCell align="center">
                            {site.id}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {site.date}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {site.site_name}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {site.location?.name}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {site.remarks}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            <IconButton
                              aria-label="delete"
                              size="large"
                              color="error"
                              onClick={() => {
                                handleClickOpen();
                                setCurrentRow(site);
                              }}
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        aria-describedby="outward-vendor-delete-confirm-dailog"
      >
        <DialogTitle>{"Delete Inward From Site "}</DialogTitle>
        <DialogContent>
          Are You Sure Want to delete Inward From Site <br /> {""}
          <Chip label={currentRow?.name} />
        </DialogContent>
        <DialogActions>
          <TOPButton onClick={deleteRow} variant="danger" text={"Yes"} />
          <TOPButton onClick={handleClose} variant="info" text={"No"} />
        </DialogActions>
      </Dialog>
    </>
  );
}
