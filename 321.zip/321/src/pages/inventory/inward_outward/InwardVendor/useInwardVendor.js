import { createAsyncThunk } from "@reduxjs/toolkit";
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { errorAlert, successAlert, warningAlert } from "src/store/slices/alert.slice";
import { toggleProcess } from "src/store/slices/process.slice";
import * as yup from "yup";
import moment from 'moment-timezone';

const errorMessage = {
  inward_date: "Please Select Inward Date",
  branch: "Please Select Valid Location",
  vendor: "Make sure you have valid vendor in your purchase order",
  purchase_order: "Please set valid purchase order",
  po_date: "Please Select Purchase Order Date",
  site_name: "Please Enter Site Name",
  transport: "Please Enter Transport Name",
  lr_number: "Please Enter LR Number",
  lr_date: "Please Select LR Date",
  received_date: "Please Select Received Date",
  supplier_bill_no: "Please Provide Supplier Bill No",
  supplier_bill_date: "Please Select Supplier Bill Date",
  remarks: "Please make sure your remarks if you have any within 500 characters",

  //entries message
  product: "Product Not Added",
  order_qty: "Please provide Valid Ordered Quentity",
  received_qty: "Please set received quantity",
  rate_per_qty: "Please set basic rate for each quatity",
  amount: "Please set valid amount for single quanity",
  specification: "Please check specifiction, if everything is okay with your order",
};

const inventoryLocationSchema = yup.object().shape({
  floor: yup.number().integer().optional().nullable().typeError('Please select valid Floor'),
  section: yup.number().integer().optional().nullable().typeError('Please select valid Section'),
  rack: yup.number().integer().optional().nullable().typeError('Please select valid Rack'),
  shelf: yup.number().integer().optional().nullable().typeError('Please select valid Shelf'),
  bin: yup.number().integer().optional().nullable().typeError('Please select valid Bin'),
  qty: yup.number().integer().optional().nullable().typeError('Please set valid Quantity for product')
});

const inwardEntriesSchema = yup.object().shape({
  product: yup.number().nullable().required(errorMessage.product).typeError(errorMessage.product),
  location: yup.number().nullable().required(errorMessage.location).typeError(errorMessage.location),
  ordered_qty: yup.number().integer().required(errorMessage.order_qty).typeError(errorMessage.order_qty),
  received_qty: yup.number().integer().required(errorMessage.received_qty).typeError(errorMessage.received_qty),
  rate_per_qty: yup.number().required(errorMessage.basic_rate).typeError(errorMessage.basic_rate),
  amount: yup.number().required().typeError(),
  specification: yup.boolean().required(errorMessage.specification).typeError(errorMessage.specification),
  inventory_location: yup.array().of(inventoryLocationSchema).
    min(1, 'You have distribute your product based on your warehouse location')
});

export const inwardSchema = yup.object().shape({
  entries: yup.array(yup.object({
    received_qty: yup.number().integer().required(errorMessage.received_qty).typeError(errorMessage.received_qty).min(1, 'You Have to set More Then 0 Quantity'),
    rate_per_qty: yup.number().required(errorMessage.rate_per_qty).typeError(errorMessage.basic_rate).min(1, 'Basic Rate can not be 0 or less'),
    amount: yup.number().required(errorMessage.amount).typeError(errorMessage.amount).min(1, 'Amount can not be 0 or less'),
  })),
  branch: yup.number().nullable().required(errorMessage.branch).typeError(errorMessage.branch),
  purchase_order: yup.number().integer(errorMessage.purchase_order).required(errorMessage.purchase_order).typeError(errorMessage.purchase_order),
  site_name: yup.string().optional().nullable(errorMessage.site_name),
  transport: yup.string().required(errorMessage.transport).typeError(errorMessage.transport),
  lr_number: yup.string().required(errorMessage.lr_number).typeError(errorMessage.lr_number),
  lr_date: yup.string().optional().nullable(errorMessage.lr_date),
  received_date: yup.string().optional().nullable(errorMessage.received_date),
  supplier_bill_no: yup.string().required(errorMessage.supplier_bill_no).typeError(errorMessage.supplier_bill_no),
  supplier_bill_date: yup.string().optional().nullable(errorMessage.supplier_bill_date),
  remarks: yup.string().optional().nullable(errorMessage.remarks).max(500, errorMessage.remarks)
});


let inventoryLocationInitialValues = {
  inventory_location_entry: '',
  floor: '',
  section: '',
  rack: '',
  shelf: '',
  bin: '',
  qty: ''
};


let inwardEntriesIntialValues = {
  product: '',
  location: '',
  ordered_qty: 0,
  received_qty: 0,
  rate_per_qty: 0,
  amount: 0,
  specification: false,
  inventory_location: []
}


let inwardIntialValues = {
  date: moment().utc().tz(moment.tz.guess()).format('YYYY-MM-DD'),
  location: '',
  vendor: '',
  purchase_order: '',
  site_name: '',
  transport: '',
  lr_number: '',
  lr_date: '',
  received_date: '',
  supplier_bill_no: '',
  supplier_bill_date: '',
  remarks: '',
  entries: [],
};

export const createInwardFromVendor = createAsyncThunk(
  "@inwardFromVendor/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await InwardOutwardService.InwardVendor.create(params.values);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Inward From Vendor",
            message: "Inward From Vendor Create Successfully",
          })
        )
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Inward From Vendor Create Failed",
            message: "Invalid Data",
          })
        )
      })
  }
)

export const updateInwardFromVendor = createAsyncThunk(
  "@updateInwardFromVendor/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await InwardOutwardService.InwardVendor.update(params.inward_vendor_id, params.values);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Inward From Vendor",
            message: "Inward From Vendor Update Successfully",
          })
        )
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Inward From Vendor Update Failed",
            message: "Invalid Data",
          })
        )
      })
  }
)

export const deleteInwardFromVendor = createAsyncThunk(
  "@inwardFromVendor/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await InwardOutwardService.InwardVendor.delete(params.currentRow.id);
    })().then((res) => {
      dispatch(
        warningAlert({
          visible: true,
          title: "Inward From Vendor",
          message: "Inward From Vendor Delete Successfully !",
        })
      );
    }).catch((e) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Inward From Vendor Delete Failed",
          message: "Inward From Vendor Delete Failed",
        })
      );
    })
  }
)

const saveInwardVendor = createAsyncThunk(
  "inwardVendor/save",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );

    const { action } = params;
    delete params["action"];
    if (action === "save") {
      InwardOutwardService.InwardVendor.create(params)
        .then((response) => {
          dispatch(
            toggleProcess({
              visible: false,
              open: false,
              loading: false,
            })
          );
          dispatch(
            successAlert({
              visible: true,
              title: "Inward from Vendor",
              message: "Inward from Vendor has been Saved !",
            })
          );
          callback?.();
        })
        .catch(() => {
          dispatch(
            errorAlert({
              visible: true,
              title: "New Inward from Vendor",
              message: "Failed to save Inward form Vendor :(",
            })
          );
        })
        .finally(() => {
          dispatch(
            toggleProcess({
              visible: false,
              open: false,
              loading: false,
            })
          );
        });
    }
  }
);

export const useInwardVendor = (props) => {
  const { onSuccess, dataObj } = props;
  const dispatch = useDispatch();

  let finalInitValues = inwardIntialValues;
  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: inwardSchema,
    validateOnChange: false,
    onSubmit: (values) => {
      console.log(values);
      // const callback = () => {
      //   onSuccess?.();
      // };
      // const params = { ...values, callback };
      // dispatch(saveInwardVendor(params));
      // console.log(params);
    },
  });
  return {
    formik,
    onSave: formik.handleSubmit,
  };
};

export const useInwardEntries = (props) => {
  const { onSuccess, dataObj } = props;

  let finalInitValues = inwardEntriesIntialValues;

  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: inwardEntriesSchema,
    validateOnChange: false,
    onSubmit: (values, { resetForm }) => {
      const callback = () => {
        onSuccess?.();
      };
      callback();
      console.log(values);
    },
  });
  return {
    formik,
    onEntrySave: formik.handleSubmit,
  };
};

export const useInventoryLocation = (props) => {
  const { onSuccess, dataObj } = props;
  let finalInitValues = inventoryLocationInitialValues;

  if (dataObj) {
    finalInitValues = dataObj;
  }

  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: inventoryLocationSchema,
    validateOnChange: false,
    onSubmit: (values, { resetForm }) => {
      console.log(values);

      const callback = () => {
        onSuccess?.();
      };
      callback();

    },
  });
  return {
    formik,
    onEntrySave: formik.handleSubmit,
  };
};