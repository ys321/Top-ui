import {
  Paper,
  Box,
} from "@mui/material";
import {
  Typography,
  Stack,
  Link,
  Grid,
  Avatar,
  Button,
  Card,
  IconButton,
  Tooltip,
} from "@mui/joy";
import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";

// For Image Swiper
import { useTheme } from "@mui/material/styles";
import { autoPlay } from "react-swipeable-views-utils";
import { useState } from "react";
import SwipeableViews from "react-swipeable-views";
import MobileStepper from "@mui/material/MobileStepper";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRight from "@mui/icons-material/KeyboardArrowRight";

const AutoPlaySwipeableViews = autoPlay(SwipeableViews);

const images = [
  {
    label: "San Francisco – Oakland Bay Bridge, United States",
    imgPath:
      "https://images.unsplash.com/photo-1537944434965-cf4679d1a598?auto=format&fit=crop&w=400&h=250&q=60",
  },
  {
    label: "Bird",
    imgPath:
      "https://images.unsplash.com/photo-1538032746644-0212e812a9e7?auto=format&fit=crop&w=400&h=250&q=60",
  },
  {
    label: "Bali, Indonesia",
    imgPath:
      "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=400&h=250",
  },
  {
    label: "Goč, Serbia",
    imgPath:
      "https://images.unsplash.com/photo-1512341689857-198e7e2f3ca8?auto=format&fit=crop&w=400&h=250&q=60",
  },
];

export default function ProductCard({
  product,
  setOpeningStockModel,
  setCurrentRow,
  handleClickOpen,
}) {
  const theme = useTheme();

  const [activeStep, setActiveStep] = useState(0);
  const maxSteps = images.length;

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStepChange = (step) => {
    setActiveStep(step);
  };
  return (
    <>
      <Card
        variant="outlined"
        sx={(theme) => ({
          width: 400,
          gridColumn: "span 2",
          flexDirection: "row",
          flexWrap: "wrap",
          overflow: "hidden",
          gap: "clamp(0px, (100% - 360px + 32px) * 999, 16px)",
          transition: "transform 0.3s, border 0.3s",
          "&:hover": {
            borderColor: theme.vars.palette.primary.outlinedHoverBorder,
            transform: "translateY(-2px)",
          },
          "& > *": {
            minWidth: "clamp(0px, (360px - 100%) * 999,100%)",
          },
        })}
      >
        {/* <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 2,
                        maxWidth: 400,
                      }}
                    > */}
        {/* <Box sx={{ display: "flex", gap: 1.5, mt: "auto" }}> */}
        <Grid container spacing={3}>
          <Grid item xs={12} md={2}>
            <Avatar variant="soft" color="neutral" size="lg">
              <Typography level="display1" sx={{ fontSize: "25px" }}>
                {product.product_class.name}
              </Typography>
            </Avatar>
          </Grid>

          <Grid item xs={12} md={5}>
            <Stack>
              <Typography level="body2" textColor="text.primary" mb={0.5}>
                <Tooltip
                  title={`View More about ${product.name}`}
                  variant="soft"
                >
                  <Link
                    href={`/inventory/product/:product_id`.replace(
                      ":product_id",
                      product.id
                    )}
                    underline={"none"}
                  >
                    {product.code}
                  </Link>
                </Tooltip>
              </Typography>
              <Typography level="body3" textColor="text.tertiary">
                {product.name}
              </Typography>
            </Stack>
          </Grid>
          <Grid xs={12} md={4} marginTop={4}>
            <Button
              variant="soft"
              size="sm"
              sx={{
                width: "90px",
              }}
              onClick={() => {
                setOpeningStockModel(true);
                setCurrentRow(product);
              }}
              startDecorator={<AddIcon />}
            >
              Opening Stock
            </Button>
          </Grid>
          <Grid xs={12} md={1} marginTop={3}>
            <Tooltip title={`Delete ${product.name} Record`} variant="soft">
              <IconButton
                size="md"
                variant="soft"
                color="danger"
                sx={{ ml: "auto", alignSelf: "flex-start" }}
                onClick={() => {
                  handleClickOpen();
                  setCurrentRow(product);
                }}
              >
                <DeleteIcon color="danger" />
              </IconButton>
            </Tooltip>
          </Grid>
        </Grid>
        <Grid container>
          <Box sx={{ maxWidth: 400, flexGrow: 1 }} marginTop={2}>
            <AutoPlaySwipeableViews
              axis={theme.direction === "rtl" ? "x-reverse" : "x"}
              index={activeStep}
              onChangeIndex={handleStepChange}
              enableMouseEvents
            >
              {images.map((step, index) => (
                <div key={step.label}>
                  {Math.abs(activeStep - index) <= 2 ? (
                    <Box
                      component="img"
                      sx={{
                        height: 255,
                        display: "block",
                        maxWidth: 400,
                        overflow: "hidden",
                        width: "100%",
                      }}
                      src={step.imgPath}
                      alt={step.label}
                    />
                  ) : null}
                </div>
              ))}
            </AutoPlaySwipeableViews>

            <MobileStepper
              steps={maxSteps}
              position="static"
              activeStep={activeStep}
              nextButton={
                <Button
                  size="small"
                  onClick={handleNext}
                  disabled={activeStep === maxSteps - 1}
                >
                  Next
                  {theme.direction === "rtl" ? (
                    <KeyboardArrowLeft />
                  ) : (
                    <KeyboardArrowRight />
                  )}
                </Button>
              }
              backButton={
                <Button
                  size="small"
                  onClick={handleBack}
                  disabled={activeStep === 0}
                >
                  {theme.direction === "rtl" ? (
                    <KeyboardArrowRight />
                  ) : (
                    <KeyboardArrowLeft />
                  )}
                  Back
                </Button>
              }
            />
            <Paper
              square
              elevation={0}
              sx={{
                display: "flex",
                alignItems: "center",
                height: 50,
                pl: 2,
                bgcolor: "background.default",
              }}
            >
              <Grid container>
                <Grid item xs={12} md={6}>
                  <Stack>
                    <Typography>
                      Category : {product?.category?.name}
                    </Typography>
                    <Typography>
                      Sub Category : {product?.sub_category?.name}
                    </Typography>
                  </Stack>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography>QR Code</Typography>
                </Grid>
              </Grid>
            </Paper>
          </Box>
        </Grid>
      </Card>
    </>
  );
}
