import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import {  Grid, Link,Select} from "@mui/joy";
import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogActions,
  DialogTitle,
  DialogContent,
  DialogContentText,
  IconButton,
  FormControl,
  InputLabel,
  MenuItem,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { vendorValidationSchema } from "src/utils/validation/product.validation";
import { useState } from "react";
import CancelIcon from "@mui/icons-material/Cancel";

import { ProductService } from "src/services/api/ProductService";

import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";
import { QueryKeys } from "src/services/queryKey";
import DeleteIcon from "@mui/icons-material/Delete";
import { useDispatch } from "react-redux";
import {
  createProductVendorLink,
  deleteProductVendorLink,
} from "src/store/slices/product.slice";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { VendorService } from "src/services/api/VendorService";
import { Button } from "@mui/joy";
import MainButton from "src/components/Button/MainButton";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

function VendorList({ product }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(vendorValidationSchema),
  });

  const [vendorDailog, setVendorDailog] = useState(false);

  const [vendor, setVendor] = useState("");
  const [vendors, setVendors] = useState([]);
  const [open, showVendorModel] = useState(false);

  const [vendorOptions, setVendorOptions] = useState([]);

  React.useEffect(() => {
    (async () => {
      const options = await VendorService.getAll();
      setVendorOptions(renderOptions(options.data, "vendor"));
    })();
  }, []);

  function renderOptions(data, lookup) {
    const _ea = [];
    data.map((el, index) => {
      _ea.push(
        <MenuItem key={index} value={el.id}>
          {el.name || el[lookup] || el.type}
        </MenuItem>
      );
    });
    return _ea;
  }

  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const dispatch = useDispatch();

  const handleClose = () => {
    setConfirmationParams({ open: false });
  };

  const handleOpen = () => {
    setConfirmationParams({ open: true });
  };

  const { isLoading, data, error, refetch } = useQuery(
    [QueryKeys.getProduct],
    async () => {
      const reponse = await ProductService.get(product);
      return reponse;
    },
    {
      onSuccess: (response) => {
        setVendors(response.data.vendors);
      },
      staleTime: 0,
    }
  );

  const hideAndClearVendorDailog = () => {
    showVendorModel(false);
    reset();
    setVendor("");
    setVendorDailog("CREATE");
  };

  function saveProductVendorLink() {
    vendor.product = product;
    dispatch(createProductVendorLink({ product, vendor }))
      .unwrap()
      .then((response) => {
        hideAndClearVendorDailog(false);
        setTimeout(() => {
          refetch();
        }, 500);
        setVendor({});
      })
      .catch((error) => {
        console.log(error);
      });
  }


  function deleteVendorHandler(vendor) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Product Vendor Unlink",
      description: `Are you sure want to delete ${vendor.name} ?`,
      confrimHandler: async function () {
        console.log(product);
        console.log(vendor.id);
        vendor.product = product;
        dispatch(deleteProductVendorLink({ product, vendor }))
          .unwrap()
          .then((res) => {
            handleClose();
            setTimeout(() => {
              refetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  return (
    <>
      <>{isLoading ? <h1>Loading...</h1> : <></>}</>
      <div></div>

      <div>
        <Dialog
          open={conformationParams.open}
          onClose={() => {
            handleClose();
          }}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            {conformationParams.title}
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {conformationParams.description}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                handleClose();
              }}
            >
              {conformationParams.cencelTitle}
            </Button>
            <Button onClick={conformationParams.confrimHandler} autoFocus>
              {conformationParams.confrimTitle}
            </Button>
          </DialogActions>
        </Dialog>
      </div>
      <Grid container justifyContent={"flex-end"} paddingRight={3}>
        <Grid item>
          <MainButton
            name={"Link Vendors"}
            onClick={() => {
              showVendorModel(true);
            }}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3} justifyContent={"flex-end"}>
        <Grid item xs={12} md={12}>
          {vendors && vendors?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell>Code</StyledTableCell>
                      <StyledTableCell>Type</StyledTableCell>
                      <StyledTableCell>Name</StyledTableCell>
                      <StyledTableCell>Billing Name</StyledTableCell>
                      <StyledTableCell>Contact Person</StyledTableCell>
                      <StyledTableCell>Phone</StyledTableCell>
                      <StyledTableCell>Email</StyledTableCell>
                      <StyledTableCell>Website</StyledTableCell>
                      <StyledTableCell>City</StyledTableCell>
                      <StyledTableCell>GST</StyledTableCell>

                      <StyledTableCell>Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {vendors.map((vendor, index) => (
                      <StyledTableRow key={index}>
                        <StyledTableCell>
                          <Link
                            href={`/vendor/:vendor_id`.replace(
                              ":vendor_id",
                              vendor.id
                            )}
                          >
                            {vendor.code}
                          </Link>
                        </StyledTableCell>
                        <StyledTableCell>
                          {vendor.vendor_type.name}
                        </StyledTableCell>
                        <StyledTableCell>{vendor.name}</StyledTableCell>
                        <StyledTableCell>{vendor.billing_name}</StyledTableCell>
                        <StyledTableCell>
                          {vendor.contact_person_name}
                        </StyledTableCell>
                        <StyledTableCell>{vendor.phone}</StyledTableCell>
                        <StyledTableCell>{vendor.email}</StyledTableCell>
                        <StyledTableCell>{vendor.website}</StyledTableCell>
                        <StyledTableCell>{vendor?.city?.name}</StyledTableCell>
                        <StyledTableCell>{vendor.gst}</StyledTableCell>
                        <StyledTableCell>
                          <IconButton
                            area-label="delete"
                            size="large"
                            color="error"
                            onClick={() => {
                              deleteVendorHandler(vendor);
                            }}
                          >
                            <DeleteIcon fontSize="inherit" />
                          </IconButton>
                        </StyledTableCell>
                      </StyledTableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>

      <Dialog
        maxWidth={"lg"}
        open={open}
        onClose={() => hideAndClearVendorDailog()}
        aria-labelledby="max-width-dialog-title"
      >
        <DialogTitle id="max-width-dialog-title">
          Link Vendor to Product
        </DialogTitle>
        <DialogContent>
          <Grid container justifyContent={"center"} marginTop={1}>
            <FormControl fullWidth>
              <InputLabel id={"vendor"} size="small">
                {"Vendor"}
              </InputLabel>
              <Select
                margin="dense"
                size="small"
                autoFocus
                labelId={"vendor"}
                id={"vendor"}
                label={"Vendor"}
                name={"vendor"}
                value={vendor.vendor || ""}
                {...register("vendor")}
                onChange={(e) => {
                  const { name, value } = e.target;
                  setVendor({
                    ...vendor,
                    [name]: value,
                  });
                }}
                error={errors.vendor ? true : false}
                helpertext={errors.vendor?.message}
              >
                {vendorOptions}
              </Select>
            </FormControl>
          </Grid>
        </DialogContent>
        <DialogActions>
          <SaveButton onClick={handleSubmit(saveProductVendorLink)} />
          <CancelButton
            startDecorator={<CancelIcon />}
            onClick={() => {
              hideAndClearVendorDailog();
            }}
          />
        </DialogActions>
      </Dialog>
    </>
  );
}

export default VendorList;
