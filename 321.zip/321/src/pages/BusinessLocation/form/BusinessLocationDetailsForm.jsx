import { Box, Button, Grid, Stack, TextField, Tooltip } from "@mui/joy";
import { useQuery } from "@tanstack/react-query";
import { Form, Formik } from "formik";
import { useRef } from "react";
import { useDispatch } from "react-redux";
import { LocationService } from "src/services/api/LocationService";
import { QueryKeys } from "src/services/queryKey";
import { locationValidationSchema } from "../BusinessLocationData";
import { updateBusinessLocation } from "src/store/slices/location/location.slice";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import EditLocationAltIcon from "@mui/icons-material/EditLocationAlt";
import {FormControl,FormLabel} from "@mui/material";
import UpdateButton from "src/components/Button/UpdateButton";

export default function LocationForm({ locationID }) {
  const dispatch = useDispatch();
  const formRef = useRef();

  const { refetch } = useQuery(
    [QueryKeys.getLocation],
    async () => {
      return await LocationService.get(locationID);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        if (response) {
          if (formRef?.current?.values) {
            formRef.current.values.name = "";
          } else return null;

          //assign data to formik
          formRef?.current?.setValues({
            ...formRef?.current?.values,
          });
          formRef.current.values.name = response.data.name;
          formRef.current.values.address = response.data.address;
          formRef.current.values.phone = response.data.phone;
          formRef.current.values.email = response.data.email;
          formRef.current.values.state = response.data.state;
          if (response.data.image) {
            formRef.current.values.image = response.data.image;
          }

          formRef?.current?.setValues({
            ...formRef?.current?.values,
          });
        }
      },
      staleTime: 0,
    }
  );

  function UpdateBusinessLocation(values) {
    dispatch(updateBusinessLocation({ values }))
      .unwrap()
      .then(() => {
        setTimeout(() => {
          refetch();
        }, 500);
      })
      .catch((e) => {
        console.log(e);
      });
  }
  return (
    <>
      <Box margin={1}>
        <Formik
          initialValues={{
            name: "",
            address: "",
            phone: "",
            email: "",
            state: "",
            image: "",
            location: locationID,
          }}
          onSubmit={async (values) => {
            UpdateBusinessLocation(values);
          }}
          innerRef={formRef}
          validationSchema={locationValidationSchema}
        >
          {({ values, errors, handleChange, setFieldValue }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="name"
                    label="Name"
                    variant="outlined"
                    value={values.name}
                    onChange={handleChange}
                    error={errors.name ? true : false}
                    helperText={errors.name}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="address"
                    label="Address"
                    variant="outlined"
                    value={values.address}
                    onChange={handleChange}
                    error={errors.address ? true : false}
                    helperText={errors.address}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="phone"
                    label="Phone"
                    variant="outlined"
                    value={values.phone}
                    onChange={handleChange}
                    error={errors.phone ? true : false}
                    helperText={errors.phone}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="email"
                    label="Email"
                    variant="outlined"
                    value={values.email}
                    onChange={handleChange}
                    error={errors.email ? true : false}
                    helperText={errors.email}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="state"
                    label="State"
                    variant="outlined"
                    value={values.state}
                    onChange={handleChange}
                    error={errors.state ? true : false}
                    helperText={errors.state}
                  />
                </Grid>

                <Grid item xs={12} md={6}>
                  <FormControl>
                    <FormLabel>Image</FormLabel>
                    <Button
                      component="label"
                      variant="outlined"
                      starticon={<UploadFileIcon />}
                      size={"sm"}
                    >
                      Upload Image
                      <input
                        type="file"
                        accept="image/*"
                        hidden
                        onChange={(e) =>
                          setFieldValue("image", e.currentTarget.files[0])
                        }
                      />
                    </Button>
                  </FormControl>
                  <Box>{values?.image?.name}</Box>
                </Grid>

                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"end"}
                    alignItems={"center"}
                    spacing={2}
                  >
                    <Tooltip
                      title={`Update ${values.name} Record`}
                      variant="soft"
                    >
                      <UpdateButton 
                        startDecorator={<EditLocationAltIcon />}
                      />
                    </Tooltip>
                  </Stack>
                </Grid>
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>
    </>
  );
}
