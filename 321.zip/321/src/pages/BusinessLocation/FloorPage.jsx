import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import { Box, Grid } from "@mui/material";

import { LocationService } from "src/services/api/LocationService";
import { locationFloorValidationSchema } from "src/utils/validation/location.validation";
import { useQuery } from "@tanstack/react-query";

import { QueryKeys } from "src/services/queryKey";
import { useDispatch } from "react-redux";
import {
  createFloor,
  floorDelete,
  updateFloor,
} from "src/store/slices/location/location.slice";
import FloorCard from "src/components/cards/FloorCard";
import {
  Modal,
  ModalClose,
  Sheet,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/joy";
import NoRecordFound from "src/components/Table/NoRecordFound";
import DeleteModel from "src/components/Model/DeleteModel";
import MainButton from "src/components/Button/MainButton";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

function FloorPage({ location }) {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(locationFloorValidationSchema),
  });
  const dispatch = useDispatch();
  const [floors, setFloors] = useState([]);
  const [floor, setFloor] = useState("");
  const [open, showFloorModel] = useState(false);

  const [floorDailogAction, setFloorDailogAction] = useState("CREATE");
  const [currentFloor, setCurrentFloor] = useState({});
  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const fetchFloors = async () => {
    const response = await LocationService.FloorService.getAll(location.id);
    return response.data;
  };

  const { isLoading, error, data, refetch } = useQuery(
    [QueryKeys.getAllFloors],
    async () => {
      return fetchFloors();
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setFloors(response);
      },
      staleTime: 0,
    }
  );

  function saveFloor() {
    // eslint-disable-next-line default-case
    switch (floorDailogAction) {
      case "CREATE":
        dispatch(createFloor({ floor, location }))
          .unwrap()
          .then((response) => {
            hideAndClearFloorDailog();
            setTimeout(() => {
              refetch();
            }, 500);
            setFloor("");
          })
          .catch((e) => {
            console.log(e);
          });
        break;
      case "UPDATE":
        dispatch(updateFloor({ currentFloor, floor, location }))
          .unwrap()
          .then((response) => {
            hideAndClearFloorDailog();
            setFloorDailogAction("CREATE");
            setTimeout(() => {
              refetch();
            }, 500);
            setFloor("");
          })
          .catch((e) => {
            console.log(e);
          });
        break;
    }
  }

  function deleteFloorHandler(floor) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: `${location.name} ${floor.name}`,
      description: `Are you sure want to delete ${floor.name} ?`,
      confrimHandler: async function () {
        dispatch(floorDelete({ floor }))
          .unwrap()
          .then((response) => {
            setConfirmationParams({ open: false });
            setTimeout(() => {
              refetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  const hideAndClearFloorDailog = () => {
    showFloorModel(false);
    reset();
    setFloor("");
    setFloorDailogAction("CREATE");
  };

  const editActionHandler = (f) => {
    setFloorDailogAction("UPDATE");
    setCurrentFloor(f);
    setFloor(f.name);
    showFloorModel(true);
  };

  return (
    <>
      {isLoading ? (
        <>
          <h1>Loading...</h1>
        </>
      ) : (
        ""
      )}
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={2} padding={2}>
          <Grid item xs={12} md={12}>
            <Stack flexDirection={"row"} justifyContent={"space-between"}>
              <Typography level="h4">Warehouse - Floor</Typography>
              <Tooltip title={`Add New Floor`} variant="soft">
                <MainButton
                  name={"Add New Floor"}
                  onClick={() => {
                    showFloorModel(true);
                  }}
                />
              </Tooltip>
            </Stack>
          </Grid>
        </Grid>

        <Grid container flexDirection={"column"}>
          <Grid item style={{ marginTop: "10px" }} padding={2}>
            <Grid
              container
              spacing={{ xs: 2, md: 2 }}
              columns={{ xs: 4, sm: 8, md: 8 }}
            >
              {floors && floors?.length > 0 ? (
                <>
                  {floors.map((f, index) => {
                    return (
                      <Grid item xs={4} sm={4} md={2} key={index}>
                        <FloorCard
                          refetch={refetch}
                          location={location}
                          link={`:location_id/floor/:floor_id`
                            .replace(":location_id", location.id)
                            .replace(":floor_id", f.id)}
                          name={f}
                          editActionHandler={editActionHandler}
                          deleteActionHandler={deleteFloorHandler}
                        />
                      </Grid>
                    );
                  })}
                </>
              ) : (
                <>
                  <NoRecordFound />
                </>
              )}
            </Grid>
          </Grid>
        </Grid>
      </Box>

      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => hideAndClearFloorDailog()}
        sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            {location.name} Location Floor
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={12} marginBottom={2}>
              <TextField
                autoFocus
                fullWidth
                margin="dense"
                type={"text"}
                variant={"outlined"}
                id="name"
                name="name"
                {...register("name")}
                label={`${location.name} floor`}
                onChange={(e) => {
                  setFloor(e.target.value);
                }}
                defaultValue={floor}
                error={errors.name ? true : false}
                helperText={errors.name?.message}
                {...setValue("name", floor)}
              />
            </Grid>

            <Grid item xs={12} md={12}>
              <Stack
                direction={"row"}
                justifyContent={"end"}
                alignItems={"center"}
                spacing={2}
              >
                <SaveButton onClick={handleSubmit(saveFloor)} />
                <CancelButton
                  onClick={() => {
                    hideAndClearFloorDailog();
                  }}
                />
              </Stack>
            </Grid>
          </Grid>
        </Sheet>
      </Modal>

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}

export default FloorPage;
