import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";

import { Box, Grid } from "@mui/material";

import {
  Breadcrumbs,
  Link,
  Modal,
  ModalClose,
  Sheet,
  Stack,
  TextField,
  Typography,
} from "@mui/joy";

import { LocationService } from "src/services/api/LocationService";

import { locationBinValidationSchema } from "src/utils/validation/location.validation";

import { QueryKeys } from "src/services/queryKey";
import { useDispatch } from "react-redux";
import {
  binDelete,
  createBin,
  updateBin,
} from "src/store/slices/location/location.slice";
import NoRecordFound from "src/components/Table/NoRecordFound";
import FloorCard from "src/components/cards/FloorCard";
import DeleteModel from "src/components/Model/DeleteModel";
import MainButton from "src/components/Button/MainButton";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

function BinPage() {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(locationBinValidationSchema),
  });

  const { location_id, floor_id, section_id, rack_id, shelf_id } = useParams();
  const dispatch = useDispatch();
  const [location, setLocation] = useState({});
  const [floor, setFloor] = useState({});
  const [section, setSection] = useState({});
  const [rack, setRack] = useState({});
  const [shelf, setShelf] = useState({});

  const [bins, setBins] = useState([]);
  const [bin, setBin] = useState("");
  const [currentBin, setCurrentBin] = useState({});
  const [open, showBinModel] = useState(false);

  const [binDailogAction, setBinDailogAction] = useState("CREATE");
  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const {} = useQuery(
    [QueryKeys.getLocation],
    async () => {
      return LocationService.get(location_id);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setLocation(response.data);
      },
      staleTime: 0,
    }
  );

  const {} = useQuery(
    [QueryKeys.getFloor],
    async () => {
      return LocationService.FloorService.get(floor_id);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setFloor(response.data);
      },
      staleTime: 0,
    }
  );

  const {} = useQuery(
    [QueryKeys.getSection],
    async () => {
      return LocationService.FloorService.SectionService.get(section_id);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setSection(response.data);
      },
      staleTime: 0,
    }
  );

  const {} = useQuery(
    [QueryKeys.getRack],
    async () => {
      return LocationService.FloorService.SectionService.RackService.get(
        rack_id
      );
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setRack(response.data);
      },
      staleTime: 0,
    }
  );

  const {} = useQuery(
    [QueryKeys.getShelf],
    async () => {
      return LocationService.FloorService.SectionService.RackService.ShelfService.get(
        shelf_id
      );
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setShelf(response.data);
      },
      staleTime: 0,
    }
  );

  let { isLoading, error, data, refetch } = useQuery(
    [QueryKeys.getBin],
    async () => {
      return LocationService.FloorService.SectionService.RackService.ShelfService.BinServices.getAll(
        shelf_id
        // location_id, floor_id
      );
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setBins(response.data);
      },
      staleTime: 0,
    }
  );

  function saveBin() {
    // eslint-disable-next-line default-case
    switch (binDailogAction) {
      case "CREATE":
        dispatch(createBin({ bin, floor_id, section_id, rack_id, shelf_id }))
          .unwrap()
          .then((response) => {
            hideAndClearBinDailog();
            setTimeout(() => {
              refetch();
            }, 500);
            setBin("");
          })
          .catch((e) => {
            console.log(e);
          });
        break;
      case "UPDATE":
        dispatch(
          updateBin({
            currentBin,
            bin,
            floor_id,
            section_id,
            rack_id,
            shelf_id,
          })
        )
          .unwrap()
          .then((response) => {
            hideAndClearBinDailog();
            setBinDailogAction("CREATE");
            setTimeout(() => {
              refetch();
            }, 500);
            setBin("");
          })
          .catch((e) => {
            console.log(e);
          });
        break;
    }
  }

  function deleteBinHandler(bin) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: `${location.name} ${shelf.name}`,
      description: `Are you sure want to delete ${bin.name} ?`,
      confrimHandler: async function () {
        dispatch(binDelete({ bin }))
          .unwrap()
          .then((response) => {
            setConfirmationParams({ open: false });
            setTimeout(() => {
              refetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  const hideAndClearBinDailog = () => {
    showBinModel(false);
    reset();
    setBin("");
    setBinDailogAction("CREATE");
  };

  const editActionHandler = (bin) => {
    setBinDailogAction("UPDATE");
    setCurrentBin(bin);
    setBin(bin.name);
    showBinModel(true);
  };

  return (
    <>
      {isLoading ? (
        <>
          <h1>Loading...</h1>
        </>
      ) : (
        ""
      )}
      <Box sx={{ flexGrow: 1 }} style={{ padding: "20px" }}>
        <Grid item>
          <Breadcrumbs aria-label="breadcrumb">
            <Link underline="hover" color="neutral" fontSize="inherit" href="/">
              {" "}
              Top Lift{" "}
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href="/business-location"
            >
              {" "}
              Warehouse
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={`/business-location/:location_id`.replace(
                ":location_id",
                location.id
              )}
              aria-current="page"
            >
              {location.name}
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={
                `/business-location/:location_id`.replace(
                  ":location_id",
                  location.id
                )
                // .replace(":floor_id", floor.id)
              }
            >
              {floor.name}
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={
                `/business-location/:location_id/floor/:floor_id`
                  .replace(":location_id", location.id)
                  .replace(":floor_id", floor_id)
                // .replace(":section_id", section_id)
              }
              aria-current="page"
            >
              {section.name}
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={
                `/business-location/:location_id/floor/:floor_id/section/:section_id`
                  .replace(":location_id", location.id)
                  .replace(":floor_id", floor_id)
                  .replace(":section_id", section_id)
                // .replace(":rack_id", rack_id)
              }
              aria-current="page"
            >
              {rack.name}
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={""}
              aria-current="page"
            >
              {shelf.name}
            </Link>
          </Breadcrumbs>
        </Grid>
        <Grid container flexDirection={"column"}>
          <Grid
            item
            style={{
              display: "flex",
              justifyContent: "flex-end",
              marginTop: "20px",
            }}
          >
            <MainButton
              name={"Add New Bin"}
              onClick={() => {
                showBinModel(true);
              }}
            />
          </Grid>
        </Grid>
        <Grid container flexDirection={"column"}>
          <Grid item style={{ marginTop: "20px" }}>
            <Grid
              container
              spacing={{ xs: 2, md: 2 }}
              columns={{ xs: 4, sm: 8, md: 8 }}
            >
              {bins && bins?.length > 0 ? (
                <>
                  {bins.map((bin, index) => {
                    return (
                      <Grid item xs={4} sm={4} md={2} key={index}>
                        <FloorCard
                          refetch={refetch}
                          location={location}
                          name={bin}
                          link={`#`}
                          editActionHandler={editActionHandler}
                          deleteActionHandler={deleteBinHandler}
                        />
                      </Grid>
                    );
                  })}
                </>
              ) : (
                <>
                  <NoRecordFound />
                </>
              )}
            </Grid>
          </Grid>
        </Grid>
      </Box>

      <>
        <Modal
          aria-labelledby="modal-title"
          aria-describedby="modal-desc"
          open={open}
          onClose={() => hideAndClearBinDailog()}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Sheet
            variant="outlined"
            sx={{
              maxWidth: 500,
              borderRadius: "md",
              p: 3,
              boxShadow: "lg",
            }}
          >
            <ModalClose
              variant="outlined"
              sx={{
                top: "calc(-1/4 * var(--IconButton-size))",
                right: "calc(-1/4 * var(--IconButton-size))",
                boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
                borderRadius: "50%",
                bgcolor: "background.body",
              }}
            />
            <Typography
              component="h2"
              id="modal-title"
              level="h4"
              textColor="inherit"
              fontWeight="lg"
              mb={1}
            >
              {location.name} / {floor.name} / {section.name} / {rack.name} /{" "}
              {shelf.name} / Bins{" "}
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={12} marginBottom={2}>
                <TextField
                  autoFocus
                  fullWidth
                  margin="dense"
                  type={"text"}
                  variant={"outlined"}
                  id="name"
                  name="name"
                  {...register("name")}
                  label={`${location.name} / ${floor.name} / ${section.name} / ${rack.name} / ${shelf.name} / Bin`}
                  onChange={(e) => {
                    setBin(e.target.value);
                  }}
                  defaultValue={bin}
                  error={errors.name ? true : false}
                  helperText={errors.name?.message}
                  {...setValue("name", bin)}
                />
              </Grid>

              <Grid item xs={12} md={12}>
                <Stack
                  direction={"row"}
                  justifyContent={"end"}
                  alignItems={"center"}
                  spacing={2}
                >
                  <SaveButton onClick={handleSubmit(saveBin)} />
                  <CancelButton
                    onClick={() => {
                      hideAndClearBinDailog();
                    }}
                  />
                </Stack>
              </Grid>
            </Grid>
          </Sheet>
        </Modal>
      </>

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}

export default BinPage;
