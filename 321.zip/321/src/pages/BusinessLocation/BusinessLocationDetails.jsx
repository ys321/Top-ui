import React, { useState } from "react";
import { useParams } from "react-router-dom";

import { LocationService } from "src/services/api/LocationService";

import { useQuery } from "@tanstack/react-query";

import FloorPage from "./FloorPage";
import { QueryKeys } from "src/services/queryKey";
import { AspectRatio, Breadcrumbs, Link, Sheet,Grid } from "@mui/joy";
import { Box  } from "@mui/material";
import LocationForm from "./form/BusinessLocationDetailsForm";

function LocationDetailPage() {
  const { location_id } = useParams();
  const [businessLocation, setBusinessLocation] = useState({});

  const { isLoading,  } = useQuery(
    [QueryKeys.getLocation],
    async () => {
      return await LocationService.get(location_id);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setBusinessLocation(response.data);
      },
    }
  );

  if (isLoading) {
    return (
      <>
        <h1>Loading...</h1>
      </>
    );
  }

  return (
    <>
      <Grid>
        <Grid item>
          <Breadcrumbs aria-label="breadcrumb">
            <Link underline="hover" color="neutral" fontSize="inherit" href="/">
              Top Lift
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href="/business-location"
            >
              {" "}
              Warehouse
            </Link>
            <Link
              underline="hover"
              color="neutral"
              fontSize="inherit"
              href={""}
              aria-current="page"
            >
              {businessLocation.name}
            </Link>
          </Breadcrumbs>
        </Grid>

        <Box padding={4}>
          <Sheet
            variant="outlined"
            sx={{
              display: "flex",
              gap: 2,
              p: 2,
              minWidth: 300,
              borderRadius: "sm",
            }}
          >
            <Grid container spacing={4}>
              <Grid item xs={12} md={5}>
                <AspectRatio
                  objectFit="contain"
                  sx={{
                    flexBasis: 300,
                    borderRadius: "sm",
                    overflow: "auto",
                  }}
                >
                  <img
                    src={businessLocation.image}
                    srcSet={businessLocation.image}
                    alt=""
                  />
                </AspectRatio>
              </Grid>
              <Grid item xs={12} md={7}>
                <LocationForm locationID={location_id} />
              </Grid>
            </Grid>
          </Sheet>
        </Box>
        <Box padding={2}>
          <FloorPage location={businessLocation} />
        </Box>
      </Grid>
    </>
  );
}

export default LocationDetailPage;
