import React, { useState } from "react";

import LocationCard from "src/components/cards/LocationCard";

import { LocationService } from "src/services/api/LocationService";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { locationValidationSchema } from "./BusinessLocationData";
import { useQuery } from "@tanstack/react-query";
import { QueryKeys } from "src/services/queryKey";
import { LinearProgress } from "@material-ui/core";
import { useDispatch } from "react-redux";
import {
  createBusinessLocation,
  deleteBusinessLocation,
} from "src/store/slices/location/location.slice";
import {
  Grid,
  Modal,
  ModalClose,
  Sheet,
  styled,
  Tooltip,
  Typography,
} from "@mui/joy";
import DeleteModel from "src/components/Model/DeleteModel";
import BusinessLocationForm from "./form/BusinessLocationForm";
import MainButton from "src/components/Button/MainButton";

const Item = styled(Sheet)(({ theme }) => ({
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.vars.palette.text.tertiary,
}));

function LocationList() {
  const dispatch = useDispatch();
  const [open, showBusinessLocationModel] = useState(false);

  const [business_locations, setBusinessLocations] = useState([]);

  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const handleCloseDialog = () => {
    setConfirmationParams({ open: false });
    LocationRefetch();
  };

  const { isLoading, refetch: LocationRefetch } = useQuery(
    ["getAllLocation", QueryKeys.getAllLocations],
    async () => {
      return LocationService.getAll();
    },
    {
      onSuccess: (response) => {
        setBusinessLocations(response.data);
      },
      staleTime: 0,
    }
  );

  function saveBusinessLocation(values) {
    dispatch(createBusinessLocation({ values }))
      .unwrap()
      .then((res) => {
        hideAndClearLocationDailog();
        setTimeout(() => {
          LocationRefetch();
        }, 500);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  if (isLoading) {
    setTimeout(() => {
      LocationRefetch();
    }, 500);
  }

  const hideAndClearLocationDailog = () => {
    showBusinessLocationModel(false);
    // reset();
  };

  function deleteLocationHandler(location) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Business Location",
      description: `Are you sure want to delete ${location.name} ?`,
      confrimHandler: async function () {
        dispatch(deleteBusinessLocation({ location }))
          .unwrap()
          .then((response) => {
            handleCloseDialog();
            setTimeout(() => {
              LocationRefetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  return (
    <>
      <Grid
        container
        sx={{ flexGrow: 1 }}
        justifyContent="flex-end"
        direction="row"
      >
        <Grid>
          <Item>
            <Tooltip title={`Add New Business Location`} variant="soft">
              <MainButton
                onClick={() => {
                  showBusinessLocationModel(true);
                }}
                name={'Add New Location'}
              />
            </Tooltip>
          </Item>
        </Grid>
      </Grid>

      {business_locations && business_locations?.length > 0 ? (
        <Grid
          container
          spacing={2}
          sx={{ flexGrow: 1 }}
          justifyContent="center"
        >
          {business_locations.map((location, index) => {
            return (
              <Grid key={index}>
                <Item>
                  <LocationCard
                    location={location}
                    deleteHandler={() => deleteLocationHandler(location, index)}
                  />
                </Item>
              </Grid>
            );
          })}
        </Grid>
      ) : (
        <>
          <NoRecordFound />
        </>
      )}

      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => hideAndClearLocationDailog()}
        sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 700,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            Business Location
          </Typography>
          <BusinessLocationForm
            save={saveBusinessLocation}
            locationValidationSchema={locationValidationSchema}
            close={() => hideAndClearLocationDailog()}
          />
        </Sheet>
      </Modal>

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}

export default LocationList;
