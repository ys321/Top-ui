import { Grid } from "@mui/joy";

import product_class from "src/static/images/product-class.png";
import product_weight_unit from "src/static/images/product-unit.png";
import vendor_type from "src/static/images/vendor-type.png";
import city_management from "src/static/images/city-management.png";
import BusinessSettingsCard from "src/components/cards/BusinessSettingsCard";

export default function BusinessSettings() {
  return (
    <>
      <Grid container spacing={4} justifyContent="center" marginTop={1}>
        <Grid item>
          <BusinessSettingsCard
            link={`/business-setting/product-class`}
            name={"Product Class"}
            image={product_class}
            title={"Create Various Product Class"}
          />
        </Grid>
        <Grid item>
          <BusinessSettingsCard
            link={`/business-setting/product-unit`}
            name={"Product Unit"}
            image={product_weight_unit}
            title={"Create Various Product Unit"}
          />
        </Grid>

        <Grid item>
          <BusinessSettingsCard
            link={`/business-setting/vendor-type`}
            name={"Vendor Type"}
            image={vendor_type}
            title={"Create Various Vendor Type"}
          />
        </Grid>
        <Grid item>
          <BusinessSettingsCard
            link={`/business-setting/city-management`}
            name={"City Management"}
            image={city_management}
            title={"Manage Various Cities"}
          />
        </Grid>
      </Grid>
    </>
  );
}
