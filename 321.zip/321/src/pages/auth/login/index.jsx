import { useNavigate } from "react-router-dom";
import { useLogin } from "./useLogin";

const { Grid, Paper, Avatar, TextField, Button } = require("@material-ui/core");

export default function Login() {
  const paperStyle = { padding: 20, width: 280, margin: "20px auto" };
  const avatarStyle = {
    backgroundColor: "#1976d2",
    minWidth: "150px",
    minHeight: "150px",
  };
  const btnstyle = { margin: "10px 0" };

  const navigate = useNavigate();

  const { formik, onLogin } = useLogin({
    onSuccess: () => {
      console.log("login");
      navigate("/");
    },
  });

  const { values, errors, handleChange, setFieldValue } = formik;

  return (
    <>
      <Grid>
        <Paper elevation={10} style={paperStyle}>
          <Grid align="center">
            <Avatar style={avatarStyle}></Avatar>
            <h2>Sign In</h2>
            <h4>Top India Elevator</h4>
          </Grid>
          <TextField
            margin="dense"
            label="Username"
            name="username"
            id="username"
            placeholder="Enter username"
            fullWidth
            value={values.username}
            onChange={handleChange("username")}
            error={errors.username ? true : false}
            helperText={errors.username}
          />
          <TextField
            margin="dense"
            name="password"
            label="Password"
            placeholder="Enter Password"
            type="password"
            fullWidth
            value={values.password}
            onChange={handleChange("password")}
            error={errors.password ? true : false}
            helperText={errors.password}
          />
          <Button
            type="submit"
            color="primary"
            variant="contained"
            style={btnstyle}
            fullWidth
            onClick={onLogin}
          >
            Sign in
          </Button>
        </Paper>
      </Grid>
    </>
  );
}
