import { topApiClient } from '../topApiClient';
import _ from 'lodash';

const ProductClassService = {
    create: async function (data) {
        const headers = {
            'Content-type': 'application/json'
        }
        return await topApiClient.post(`/product-class`, data, headers);
    },
    get: async function (id) {
        return await topApiClient.get(`/product-class/${id}`);        
    },
    update: async function (id, data, _headers = {}) {
        let headers = { 'Content-type': 'multipart/form-data' };
        if (!_.isEmpty(_headers)) {
            headers = _headers;
        }
        return topApiClient.patch(`product-class/${id}`, data, headers)
    },
    remove: async function (id) {
        return topApiClient.delete(`/product-class/${id}`);
    },
    getAll: async function() {
        const url = '/product-class';
        return  await topApiClient.get(url);
    },
}

export { ProductClassService };