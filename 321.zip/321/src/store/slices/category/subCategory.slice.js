import { createAsyncThunk } from "@reduxjs/toolkit";
import { CategoryService } from "src/services/api/CategoryService";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createSubCategory = createAsyncThunk(
  "@subCategory/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const subCategory = new FormData();
      subCategory.append("name", params.values.name);
      subCategory.append("description", params.values.description);
      subCategory.append("category", params.values.category);
      if (params.values.image) {
        subCategory.append("image", params.values.image);
      }
      const res = await CategoryService.SubCategoryService.create(subCategory);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Sub Category",
            message: "Sub Category Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Sub Category Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateSubCategory = createAsyncThunk(
  "@subCategory/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.sub_category_id) {
        const subCategory = new FormData();
        subCategory.append("name", params.values.name);
        subCategory.append("description", params.values.description);
        subCategory.append("identifier", params.values.identifier);
        subCategory.append("category", params.values.category);
        if (params.values?.image.name) {
          subCategory.append(
            "image",
            params.values.image,
            params.values.image.name
          );
        }
        const res = await CategoryService.SubCategoryService.update(
          params.sub_category_id,
          subCategory
        );
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Sub Category",
            message: "Sub Category Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Sub Category Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteSubCategoryData = createAsyncThunk(
  "@subCategory/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await CategoryService.SubCategoryService.remove(params.subCategory.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Sub Category",
            message: "Sub Category Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Sub Category Delete Failed",
            message: "Sub Category Delete Failed",
          })
        );
      });
  }
);

export const createAttribute = createAsyncThunk(
  "@attribute/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res =
        await CategoryService.SubCategoryService.AttributeService.create(
          params.values,
          params.values.sub_category
        );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Sub Category",
            message: "Sub Category Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Sub Category Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);
