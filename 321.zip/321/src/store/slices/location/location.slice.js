import { createAsyncThunk } from "@reduxjs/toolkit";
import { LocationService } from "src/services/api/LocationService";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createBusinessLocation = createAsyncThunk(
  "@businessLocation/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );

    const LocationData = new FormData();
    LocationData.append("name", params.values.name);
    LocationData.append("address", params.values.address);
    LocationData.append("phone", params.values.phone);
    if (params.values.email) {
      LocationData.append("email", params.values.email);
    }
    LocationData.append("state", params.values.state);
    if (params.values.image) {
      LocationData.append("image", params.values.image);
    }

    LocationService.create(LocationData)
      .then((response) => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );

        dispatch(
          successAlert({
            visible: true,
            title: "Location",
            message: "Business Location Create Successfully !",
          })
        );
      })
      .catch((e) => {
        console.log(e);
        dispatch(
          errorAlert({
            visible: true,
            title: "Location Create Failed",
            message:
              `${e.error.response?.data?.phone}` ||
              `${e.error.response?.data?.email}`,
          })
        );
      });
  }
);

export const updateBusinessLocation = createAsyncThunk(
  "@location/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const LocationData = new FormData();
      LocationData.append("name", params.values.name);
      LocationData.append("address", params.values.address);
      LocationData.append("phone", params.values.phone);
      LocationData.append("email", params.values.email);
      LocationData.append("state", params.values.state);
      if (params.values?.image.name) {
        LocationData.append(
          "image",
          params.values.image,
          params.values.image.name
        );
      }

      const res = await LocationService.update(
        params.values.location,
        LocationData
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Location",
            message: "Business Location Update Successfully !",
          })
        );
      })
      .catch((response) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Location Update Failed",
            message: "Invalid Data !",
          })
        );
      });
  }
);
export const deleteBusinessLocation = createAsyncThunk(
  "@location/delte",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await LocationService.remove(params.location.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Location",
            message: "Business Location Delete Successfully !",
          })
        );
      })
      .catch((response) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Location Delete Failed",
            message: "Location Delete Failed !",
          })
        );
      });
  }
);

export const createFloor = createAsyncThunk("@floor/create", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );

  (async () => {
    const res = await LocationService.FloorService.create({
      name: params.floor,
      business_location: params.location.id,
    });
    return res;
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Floor",
          message: "Floor Create Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Floor Create Failed",
          message: "Invalid Data",
        })
      );
    });
});
export const updateFloor = createAsyncThunk("@floor/update", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    if (params.currentFloor?.id) {
      const res = await LocationService.FloorService.update(
        params.currentFloor.id,
        { name: params.floor, business_location: params.location.id }
      );
      return res;
    }
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Floor",
          message: "Floor Update Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Floor Update Failed",
          message: "Invalid Data",
        })
      );
    });
});
export const floorDelete = createAsyncThunk("@floor/delete", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    const res = await LocationService.FloorService.remove(params.floor.id);
    return res;
  })()
    .then((res) => {
      dispatch(
        warningAlert({
          visible: true,
          title: "Floor",
          message: "Floor Delete Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Floor Delete Failed",
          message: "Invalid Data",
        })
      );
    });
});

export const createSection = createAsyncThunk(
  "@section/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );

    (async () => {
      const res = await LocationService.FloorService.SectionService.create({
        name: params.section,
        business_location: params.location_id,
        floor: params.floor_id,
      });
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Section",
            message: "Section Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Section Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateSection = createAsyncThunk(
  "@section/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.currentSection?.id) {
        const res = await LocationService.FloorService.SectionService.update(
          params.currentSection.id,
          {
            name: params.section,
            business_location: params.location_id,
            floor: params.floor_id,
          }
        );
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Section",
            message: "Section Update Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Section Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const sectionDelete = createAsyncThunk(
  "@section/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await LocationService.FloorService.SectionService.remove(
        params.section.id
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Section",
            message: "Section Delete Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Section Delete Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const createRack = createAsyncThunk("@rack/create", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );

  (async () => {
    const res =
      await LocationService.FloorService.SectionService.RackService.create({
        name: params.rack,
        section: params.section_id,
        floor: params.floor_id,
      });
    return res;
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Rack",
          message: "Rack Create Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "FlRackoor Create Failed",
          message: "Invalid Data",
        })
      );
    });
});
export const updateRack = createAsyncThunk("@rack/update", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    if (params.currentRack?.id) {
      const res =
        await LocationService.FloorService.SectionService.RackService.update(
          params.currentRack.id,
          { name: params.rack, business_location_section: params.section_id }
        );
      return res;
    }
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Rack",
          message: "Rack Update Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Rack Update Failed",
          message: "Invalid Data",
        })
      );
    });
});

export const rackDelete = createAsyncThunk("@rack/delete", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    const res =
      await LocationService.FloorService.SectionService.RackService.remove(
        params.rack.id
      );
    return res;
  })()
    .then((res) => {
      dispatch(
        warningAlert({
          visible: true,
          title: "Rack",
          message: "Rack Delete Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Rack Delete Failed",
          message: "Invalid Data",
        })
      );
    });
});

export const createShelf = createAsyncThunk("@shelf/create", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );

  (async () => {
    const res =
      await LocationService.FloorService.SectionService.RackService.ShelfService.create(
        {
          name: params.shelf,
          section: params.section_id,
          floor: params.floor_id,
          rack: params.rack_id,
        }
      );
    return res;
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Shelf",
          message: "Shelf Create Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Shelf Create Failed",
          message: "Invalid Data",
        })
      );
    });
});
export const updateShelf = createAsyncThunk("@shelf/update", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    if (params.currentShelf?.id) {
      const res =
        await LocationService.FloorService.SectionService.RackService.ShelfService.update(
          params.currentShelf.id,
          {
            name: params.shelf,
            floor: params.floor_id,
            section: params.section_id,
            rack: params.rack_id,
          }
        );
      return res;
    }
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Shelf",
          message: "Shelf Update Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Shelf Update Failed",
          message: "Invalid Data",
        })
      );
    });
});

export const shelfDelete = createAsyncThunk("@shelf/delete", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    const res =
      await LocationService.FloorService.SectionService.RackService.ShelfService.remove(
        params.shelf.id
      );
    return res;
  })()
    .then((res) => {
      dispatch(
        warningAlert({
          visible: true,
          title: "Shelf",
          message: "Shelf Delete Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Shelf Delete Failed",
          message: "Invalid Data",
        })
      );
    });
});

export const createBin = createAsyncThunk("@bin/create", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );

  (async () => {
    const res =
      await LocationService.FloorService.SectionService.RackService.ShelfService.BinServices.create(
        {
          name: params.bin,
          section: params.section_id,
          floor: params.floor_id,
          rack: params.rack_id,
          shelf: params.shelf_id,
        }
      );
    return res;
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Bin",
          message: "Bin Create Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Bin Create Failed",
          message: "Invalid Data",
        })
      );
    });
});
export const updateBin = createAsyncThunk("@bin/update", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    if (params.currentBin?.id) {
      const res =
        await LocationService.FloorService.SectionService.RackService.ShelfService.BinServices.update(
          params.currentBin.id,
          {
            name: params.bin,
            floor: params.floor_id,
            section: params.section_id,
            rack: params.rack_id,
            shelf: params.shelf_id,
          }
        );
      return res;
    }
  })()
    .then((res) => {
      dispatch(
        successAlert({
          visible: true,
          title: "Bin",
          message: "Bin Update Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Bin Update Failed",
          message: "Invalid Data",
        })
      );
    });
});

export const binDelete = createAsyncThunk("@bin/delete", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );
  (async () => {
    const res =
      await LocationService.FloorService.SectionService.RackService.ShelfService.BinServices.remove(
        params.bin.id
      );
    return res;
  })()
    .then((res) => {
      dispatch(
        warningAlert({
          visible: true,
          title: "Bin",
          message: "Bin Delete Successfully",
        })
      );
    })
    .catch((error) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "Bin Delete Failed",
          message: "Invalid Data",
        })
      );
    });
});
