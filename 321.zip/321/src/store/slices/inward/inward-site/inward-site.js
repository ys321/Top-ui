import { createAsyncThunk } from "@reduxjs/toolkit";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { errorAlert, successAlert, warningAlert } from "../../alert.slice";
import { toggleProcess } from "../../process.slice";

export const createInwardSite = createAsyncThunk(
  "@inwardSite/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.entries === null) {
        console.log(null);
      } else {
        params.inward.location_site = params.location;
        params.inward.location = params.inward_location;
        params.is_inward = true;
        params.inward.entries = params.entries;

        const res = await InwardOutwardService.InwardSite.create(params.inward);
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Inward Site",
            message: "Inward Site Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Inward Site Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateInwardSite = createAsyncThunk(
  "@inwardSite/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    console.log(params);
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.inward.location_site) {
        params.inward.location_site = params.location;
      }
      params.inward.location = params.inward_location;
      params.is_inward = true;
      if (params.entries) {
        params.inward.entries = params.entries;
      }
      const res = await InwardOutwardService.InwardSite.update(
        params.inward?.id,
        params.inward
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Inward Site",
            message: "Inward Site Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Inward Site Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteInwardSite = createAsyncThunk(
  "@inwardSite/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await InwardOutwardService.InwardSite.remove(params.currentRow.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Inward Site",
            message: "Inward Site Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Inward Site Delete Failed",
            message: "Inward Site Delete Failed",
          })
        );
      });
  }
);
