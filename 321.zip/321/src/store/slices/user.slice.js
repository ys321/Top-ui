import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { toggleProcess } from "./process.slice";
import { errorAlert, successAlert } from "./alert.slice";

import UserService from "src/services/user/userServices";
import { addTokenToStorage } from "src/storage";
import AuthStorage from "src/storage/Helpers/AuthStorage";

export const initUserState = {
  isLoggedIn: false,
  user: {},
  token: "",
};

const userSlice = createSlice({
  name: "user",
  initialState: initUserState,
  reducers: {
    setUser: (state, { payload }) => {
      state.isLoggedIn = true;
      state.user = payload.user || null;
      state.token = payload.token || null;
      return state;
    },

    logout: (state) => {
      state = initUserState;
      return state;
    },
  },
});

export const { setUser, logout } = userSlice.actions;
export const userReducer = userSlice.reducer;

export const loginUser = createAsyncThunk("user/login", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  // console.log(params);

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );

  UserService.auth(params)
    .then((response) => {
      dispatch(
        toggleProcess({
          visible: false,
          open: false,
          loading: false,
        })
      );

      dispatch(
        setUser({
          token: response.data.access,
          isLoggedIn: true,
        })
      );
      AuthStorage.saveData({ token: response.data.access, isLoggedIn: true });
      dispatch(
        successAlert({
          visible: true,
          title: "User Login",
          message: "Login Successfully !",
        })
      );

      addTokenToStorage({ token: response.data.access });
    })
    .catch((response) => {
      dispatch(
        errorAlert({
          visible: true,
          title: "User Login Failed",
          message: "Invalid Credentials",
        })
      );
    });
});
