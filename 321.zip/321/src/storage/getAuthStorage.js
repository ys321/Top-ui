import AuthStorage from "./Helpers/AuthStorage";

let Storage = AuthStorage;

export default function getAuthStorage() {
  return Storage
}
