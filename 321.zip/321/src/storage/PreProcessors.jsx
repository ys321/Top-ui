import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { business_settings_service } from "src/services/api/BussinessSettingsService";
import { LocationService } from "src/services/api/LocationService";
// import { ProductService } from "src/services/api/Product.service";

import { VendorService } from "src/services/api/VendorService";
import { setLocations } from "src/store/slices/location.slice";
// import { setProducts } from "src/store/slices/product.slice";
import { setVendors } from "src/store/slices/vendor.slice";
import { setCities } from "src/store/slices/city.slice";
import { setVendorTypes } from "src/store/slices/vendorType.slice";
import { CategoryService } from "src/services/api/CategoryService";
import { setCategories } from "src/store/slices/categoryReducer";

function PreProcessors() {
  const dispatch = useDispatch();

  useEffect(() => {
    (async () => {
      let response = null;

      response = await VendorService.VendorTypeService.getAll();
      dispatch(setVendorTypes(response.data));

      response = await LocationService.getAll();
      dispatch(setLocations(response.data));

      response = await VendorService.getAll();
      dispatch(setVendors(response.data));

      response = await business_settings_service.city_service.getAll();
      dispatch(setCities(response.data));

      response = await CategoryService.getAll();
      dispatch(setCategories(response.data));

      // response = await ProductService.getAllForDD();
      // dispatch(setProducts(response.data));

    })();
  });

  return <></>;
}

export { PreProcessors };
