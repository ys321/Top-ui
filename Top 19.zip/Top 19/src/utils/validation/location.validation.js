import * as yup from "yup";

const locationValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("location name is required")
    .min(2, "name should be at least 2 character long")
    .max(50, "name should not be more than 50 character"),

  address: yup
    .string()
    .max(255, "address should not be more than 255 characters"),
  phone: yup
    .number()
    .typeError("Phone must be a number")
    .required("phone field is required.")
    .min(10),

  email: yup.string().email(),
});

const locationFloorValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("floor name is required")
    .min(2, "floor name should be at least 2 character long")
    .max(15, "floor name can not exceed 15 character long")
    .matches(/^[a-zA-ZÀ-ÖÙ-öù-ÿĀ-žḀ-ỿ0-9\s\-\/.]+$/, 'Please enter valid name'),
});

const locationSectionValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("section name is required")
    .min(2, "section name should be at least 2 character long")
    .max(15, "section name can not exceed 15 character long")
    .matches(/^[a-zA-ZÀ-ÖÙ-öù-ÿĀ-žḀ-ỿ0-9\s\-\/.]+$/, 'Please enter valid name'),
});
const locationRackValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("rack name is required")
    .min(2, "rack name should be at least 2 character long")
    .max(15, "rack name can not exceed 15 character long")
    .matches(/^[a-zA-ZÀ-ÖÙ-öù-ÿĀ-žḀ-ỿ0-9\s\-\/.]+$/, 'Please enter valid name'),
});
const locationShelfValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("shelf name is required")
    .min(2, "shelf name should be at least 2 character long")
    .max(15, "shelf name can not exceed 15 character long")
    .matches(/^[a-zA-ZÀ-ÖÙ-öù-ÿĀ-žḀ-ỿ0-9\s\-\/.]+$/, 'Please enter valid name'),
});
const locationBinValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("bin name is required")
    .min(2, "bin name should be at least 2 character long")
    .max(15, "bin name can not exceed 15 character long")
    .matches(/^[a-zA-ZÀ-ÖÙ-öù-ÿĀ-žḀ-ỿ0-9\s\-\/.]+$/, 'Please enter valid name'),
});

export {
  locationValidationSchema,
  locationFloorValidationSchema,
  locationSectionValidationSchema,
  locationRackValidationSchema,
  locationShelfValidationSchema,
  locationBinValidationSchema,
};
