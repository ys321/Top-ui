import * as yup from "yup";

const categoryValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("category name is required")
    .min(2, "name should be at least 2 character long")
    .max(50, "name should not be more than 50 character"),

  description: yup
    .string()
    .max(255, "description should not be more than 255 characters"),
});

const subCategoryValidationSchema = yup.object().shape({
  name: yup
    .string()
    .required("Sub Category name is required")
    .min(2, "Sub category name should be at least 2 character long")
    .max(50, "Sub category name can not exceed 50 character long"),

  description: yup
    .string()
    .max(255, "description should not be more than 255 characters")
    .typeError('Description is Required'),
});

const subCategoryAttibuteSchema = yup.object().shape({
  name: yup
    .string()
    .required("Attribute name is required")
    .min(2, "Attribute name should be at least 2 character long")
    .max(50, "Attribute name can not exceed 50 character long")
});

const locationValidationSchema = yup.object().shape({
  location: yup.string().required("location is required"),
  product_qty: yup.string().required("product quantity is required"),
  buffer_qty: yup.string().required("buffer quantity"),
});

export {
  categoryValidationSchema,
  subCategoryValidationSchema,
  subCategoryAttibuteSchema,
  locationValidationSchema,
};
