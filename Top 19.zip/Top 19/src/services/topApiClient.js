import axios from "axios";
import logHttpResponse from 'src/services/logHttpResponse';
import { getTokenFromStorage } from "src/storage";
import AuthStorage from "src/storage/Helpers/AuthStorage";

let BASE_URL = null;

const {host} = window.location;

if (host.includes('localhost')) {
  // BASE_URL = 'http://localhost:8000/tiepltd-api';
  // BASE_URL = 'http://127.0.0.1:8000/tiepltd-api';
  // BASE_URL = 'http://10.10.1.3:8000/tiepltd-api';
  https://api.qa.topindiaelevator.net/
  BASE_URL = 'https://api.qa.topindiaelevator.net/tiepltd-api';
  // BASE_URL = 'http://192.168.1.152:8000/tiepltd-api';
}

if (host === 'qa.topindiaelevator.net') {
  BASE_URL = 'https://api.qa.topindiaelevator.net/tiepltd-api';
}

if (host === 'topindiaelevator.net') {
  BASE_URL = 'https://api.topindiaelevator.net/tiepltd-api';
}

export const topApiClient = axios.create({
    baseURL: `${BASE_URL}`,
    headers: {
        
    }
});

let headers = {
  Authorization : `Bearer ${getTokenFromStorage()}`
};


topApiClient.interceptors.response.use(
    (response) => {
        logHttpResponse({ axiosResponse: response })      
  
      return response
    },
    // Custom error handler to flag any non-500 errors from our server.
    // Components can handle these errors specifically by checking for
    // the presence of 'topError'.
    (error) => {
      const { response } = error
      const topError = response && response.status <= 500

      logHttpResponse({ isError: true, axiosResponse: response })

      // eslint-disable-next-line prefer-promise-reject-errors
      return Promise.reject({
        topError,
        error,
      })
    },
  )
  

export { BASE_URL };