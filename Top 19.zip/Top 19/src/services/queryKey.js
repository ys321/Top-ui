export const QueryKeys = {
  USER: "user",
  // Category
  createCategory: "createCategory",
  updateCategory: "updateCategory",
  destroyCategory: "destroyCategory",
  getCategory: "getCategory",
  getAllCategories: "getAllCategories",

  // SubCategory
  createSubCategory: "createSubCategory",
  updateSubCategory: "updateSubCategory",
  destroySubCategory: "destroySubCategory",
  getSubCategory: "getSubCategory",
  getAllSubCategories: "getAllSubCategories",

  // Attribute
  createAttribute: "createAttribute",
  updateAttribute: "updateAttribute",
  destroyAttribute: "destroyAttribute",
  getAttribute: "getAttribute",
  getAllAttributes: "getAllAttributes",

  // AttributeValue
  createAttributeValue: "createAttributeValue",
  updateAttributeValue: "updateAttributeValue",
  getAllAttributesValues: "getAllAttributesValues",

  // CategoryMedia
  createCategoryMedia: "createCategoryMedia",
  destroyCategoryMedia: "destroyCategoryMedia",
  getCategoryMedia: "getCategoryMedia",
  getAllCategoryMedia: "getAllCategoryMedia",

  // Product
  createProduct: "createProduct",
  updateProduct: "updateProduct",
  destroyProduct: "destroyProduct",
  getProduct: "getProduct",
  getAllProducts: "getAllProducts",

  // ProductUnits
  getAllProductUnits: "getAllProductUnits",

  // ProductVendorLink
  updateProductVendorLink: "updateProductVendorLink",
  destroyProductVendorLink: "destroyProductVendorLink",

  // ProductLocation
  createProductLocation: "createProductLocation",
  updateProductLocation: "updateProductLocation",
  destroyProductLocation: "destroyProductLocation",
  getProductLocation: "getProductLocation",
  getAllProductLocations: "getAllProductLocations",

  // ProductMedia
  createProductMedia: "createProductMedia",
  destroyProductMedia: "destroyProductMedia",
  getProductMedia: "getProductMedia",
  getAllProductMedia: "getAllProductMedia",

  // Vendor
  createVendor: "createVendor",
  updateVendor: "updateVendor",
  destroyVendor: "destroyVendor",
  getVendor: "getVendor",
  getAllVendors: "getAllVendors",
  getVendorByCodeNo: "getVendorByCodeNo",

  // VendorType
  createVendorType: "createVendorType",
  updateVendorType: "updateVendorType",
  getAllVendorTypes: "getAllVendorTypes",

  // ProductUnLink
  removeProductUnlink: "removeProductUnlink",

  // VendorBank
  createVendorBank: "createVendorBank",
  updateVendorBank: "updateVendorBank",
  destroyVendorBank: "destroyVendorBank",
  getVendorBank: "getVendorBank",
  getAllVendorBanks: "getAllVendorBanks",

  // ProductListbyVendor
  getAllProductListbyVendor: "getAllProductListbyVendor",

  // Location
  createLocation: "createLocation",
  updateLocation: "updateLocation",
  destroyLocation: "destroyLocation",
  getLocation: "getLocation",
  getAllLocations: "getAllLocations",

  // Floor
  createFloor: "createFloor",
  updateFloor: "updateFloor",
  destroyFloor: "destroyFloor",
  getFloor: "getFloor",
  getAllFloors: "getAllFloors",

  // Section
  createSection: "createSection",
  updateSection: "updateSection",
  destroySection: "destroySection",
  getSection: "getSection",
  getAllSections: "getAllSections",

  // Rack
  createRack: "createRack",
  updateRack: "updateRack",
  destroyRack: "destroyRack",
  getRack: "getRack",
  getAllRacks: "getAllRacks",

  // Shelf
  createShelf: "createShelf",
  updateShelf: "updateShelf",
  destroyShelf: "destroyShelf",
  getShelf: "getShelf",
  getAllShelfs: "getAllShelfs",

  // Bin
  createBin: "createBin",
  updateBin: "updateBin",
  destroyBin: "destroyBin",
  getBin: "getBin",
  getAllBins: "getAllBins",

  // MaterialRequest
  createMaterialRequest: "createMaterialRequest",
  updateMaterialRequest: "updateMaterialRequest",
  destroyMaterialRequest: "destroyMaterialRequest",
  getMaterialRequest: "getMaterialRequest",
  getAllMaterialRequests: "getAllMaterialRequests",
  getAllItemMaterialRequest: "getAllItemMaterialRequest",

  // MaterialRequestItem
  createMaterialRequestItem: "createMaterialRequestItem",
  updateMaterialRequestItem: "updateMaterialRequestItem",
  destroyMaterialRequestItem: "destroyMaterialRequestItem",

  // ProductClass
  createProductClass: "createProductClass",
  updateProductClass: "updateProductClass",
  destroyProductClass: "destroyProductClass",
  getProductClass: "getProductClass",
  getAllProductClasses: "getAllProductClasses",

  // PurchaseOrder
  createPurchaseOrder: "createPurchaseOrder",
  updatePurchaseOrder: "updatePurchaseOrder",
  destroyPurchaseOrder: "destroyPurchaseOrder",
  getPurchaseOrder: "getPurchaseOrder",
  getAllPurchaseOrders: "getAllPurchaseOrders",
  getPurchaseOrderByPONo: "getPurchaseOrderByPONo",
  getPurchaseOrderByMRNo: "getPurchaseOrderByMRNo",

  // PurchaseOrderItem
  createPurchaseOrderItem: "createPurchaseOrderItem",
  updatePurchaseOrderItem: "updatePurchaseOrderItem",
  destroyPurchaseOrderItem: "destroyPurchaseOrderItem",
  getPurchaseOrderItem: "getPurchaseOrderItem",
  getAllPurchaseOrderItems: "getAllPurchaseOrderItems",

  // Status
  getAllStatus: "getAllStatus",

  // UOM
  createUOM: "createUOM",
  updateUOM: "updateUOM",
  getAllUOM: "getAllUOM",

  // WeightUnit
  createWeightUnit: "createWeightUnit",
  updateWeightUnit: "updateWeightUnit",
  getAllWeightUnit: "getAllWeightUnit",

  // InwardVendor
  createInwardVendor: "createInwardVendor",

  // InwardBranch
  createInwardBranch: "createInwardBranch",

  // InwardSite
  getAllInwardSite: "getAllInwardSite",
  getInwardSite: "getInwardSite",
  createInwardSite: "createInwardSite",

  // OutwardVendor
  createOutwardVendor: "createOutwardVendor",

  // OutwardBranch
  createOutwardBranch: "createOutwardBranch",

  // OutwardSite
  getAllOutwardSite: "getAllInwardSite",
  createOutwardSite: "createOutwardSite",

  // InwardProductLocation
  getInwardProductLocation: "getInwardProductLocation",

  // Inward-Item
  createInwardItem: "createInwardItem",
  updateInwardItem: "updateInwardItem",
  destroyInwardItem: "destroyInwardItem",
  getInwardItem: "getInwardItem",
  getAllInwardItems: "getAllInwardItems",

  // City
  getAllCity: "getAllCity",

  // Transport
  getAllTransport: "getAllTransport",
};
