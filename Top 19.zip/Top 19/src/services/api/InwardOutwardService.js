import { topApiClient } from "../topApiClient";

const InwardOutwardService = {
  InwardSite: {
    getAll: async function () {
      return await topApiClient.get(`/inward-from-site`);
    },
    get: async function (id) {
      return await topApiClient.get(`/inward-from-site/${id}`);
    },
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.post(`/inwrd-from-site`, data, headers);
    },
    update: async function (id, data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.patch(`/inward-from-site/${id}`, data, headers);
    },
    remove: async function (id) {
      return await topApiClient.delete(`/inward-from-site/${id}`);
    },
  },
  OutwardSite: {
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.post(`/outward-from-site`, data, headers);
    },
    update: async function (data, id) {
      const headers = {
        "Content-type": "application/json"
      };
      return await topApiClient.patch(`/outward-from-site/${id}`, data, headers);
    }
  },
  InwardVendor: {
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      // return await topApiClient.post(`/inward-from-vendor`, data, headers);
      return await topApiClient.post(`/inward-from-vendor`, data, headers);
    },
    getAll: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.get(`/inward-from-vendor`, data, headers)
    },
    get: async function (id) {
      return await topApiClient.get(`/inward-from-vendor/${id}`);
    },
    update: async function (id, data) {
      const headers = {
        "Content-type": "application/json",
      };
      return topApiClient.patch(`/inward-from-vendor/${id}`, data, headers)
    },
    delete: async function (id) {
      return await topApiClient.delete(`/inward-from-vendor/${id}`);
    },
  },
  OutwardVendor: {
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      // return await topApiClient.post(`/inward-from-vendor`, data, headers);
      return await topApiClient.post(`/outward-from-vendor`, data, headers);
    },
    getAll: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.get(`/outward-from-vendor`, data, headers)
    },
    get: async function (id) {
      return await topApiClient.get(`/outward-from-vendor/${id}`);
    },
    update: async function (id, data) {
      const headers = {
        "Content-type": "application/json",
      };
      return topApiClient.patch(`/outward-from-vendor/${id}`, data, headers)
    },
    delete: async function (id) {
      return await topApiClient.delete(`/outward-from-vendor/${id}`);
    },
  },
  InwardBranch: {
    getAll: async function (data) {
      const headers = {
        "Content-type": 'application/json'
      };
      return await topApiClient.get(`/inward-from-branch`, data, headers)
    },
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.post(`inward-from-branch`, data, headers);
    },
    update: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.patch(`inward-from-branch`, data, headers);
    },
  },
  OutwardBranch: {
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.post(`inward-from-branch`, data, headers);
    },
    update: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.patch(`outward-from-branch`, data, headers);
    },
  },
  create: async function (data) {
    const headers = {
      "Content-type": "application/json",
    };
    return await topApiClient.post(`/inward-item`, data, headers);
  },
  update: async function (inward, data) {
    const headers = {
      "Content-type": "multipart/form-data",
    };
    return await topApiClient.patch(`/inward-item/${inward.id}`, data, headers);
  },
  remove: async function (id) {
    return await topApiClient.delete(`/inward-item/${id}`);
  },
  get: async function (id) {
    return await topApiClient.get(`/inward-item/${id}`);
  },
  getAll: async function (page) {
    let url = "/inward-items";
    if (page) url += `?page=${page}`;
    return await topApiClient.get(url);
  },

  InwardOutwardItemService: {
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.post(`/inward-item`, data, headers);
    },
    update: async function (inward, data) {
      const headers = {
        "Content-type": "multipart/form-data",
      };
      return await topApiClient.patch(
        `/inward-item/${inward.id}`,
        data,
        headers
      );
    },
    remove: async function (id) {
      return await topApiClient.delete(`/inward-item/${id}`);
    },
    get: async function (id) {
      return await topApiClient.get(`/inward-item/${id}`);
    },
    getAll: async function (page) {
      let url = "/inward-items";
      if (page) url += `?page=${page}`;
      return await topApiClient.get(url);
    },
  },

  InwardCustomer: {
    getAll: async function () {
      return await topApiClient.get(`/inward-from-customer`);
    },
    get: async function (id) {
      return await topApiClient.get(`/inward-from-customer/${id}`);
    },
    create: async function (data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.post(`/inwrd-from-customer`, data, headers);
    },
    update: async function (id, data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.patch(`/inward-from-customer/${id}`, data, headers);
    },
    remove: async function (id) {
      return await topApiClient.delete(`/inward-from-customer/${id}`);
    },
  },
};

export { InwardOutwardService };
