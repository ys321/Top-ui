import { topApiClient } from "../topApiClient";

const headers = {
  "Content-type": "application/json",
};

// const RequestMaterial = {
//   create : async function(data){
//     return await topApiClient.post(`/request-material`,data)
//   }
// }

const PurchaseOrderService = {
  get: async function (id) {
    return await topApiClient.get(`/purchase-order/${id}`);
  },
  getItem: async function (id) {
    return await topApiClient.get(`/purchase-order/${id}`);
  },
  getAll: async function (page) {
    let url = "/purchase-orders";
    if (page) url += `?page=${page}`;
    return await topApiClient.get(url);
  },
  create: async function (data) {
    return await topApiClient.post(`/purchase-order`, data, headers);
  },
  update: async function (id, data) {
    return topApiClient.patch(`/purchase-order/${id}`, data, headers);
  },
  delete: async function (id) {
    return await topApiClient.delete(`/purchase-order/${id}`);
  },
  getByPONo: async function (po_no) {
    return await topApiClient.get(`/purchase-orders?po_number=${po_no}`);
  },
  getByMRNo: async function (po_no) {
    return await topApiClient.get(`/material-requests?po_number=${po_no}`);
  },

  Item: {
    get: async function (id) {
      return await topApiClient.get(`/purchase-order-item/${id}`);
    },
    getAll: async function () {
      return await topApiClient.get(`/products`);
    },
    create: async function (data) {
      return await topApiClient.post(`/request-material`, data);
    },
    update: async function (id, data) {
      return topApiClient.patch(`/request-material/${id}`, data);
    },
    // delete: async function (id) {
    //   return await topApiClient.delete(`/request-material/${id}`);
    // },
    delete  : async function (id) {
      return topApiClient.delete(`/purchase-order-entries/${id}`)
    }
  },

  Status: {
    getAll: async () => {
      return await topApiClient.get("/purchase-order-statuses");
    },
  },
};

export { PurchaseOrderService };
