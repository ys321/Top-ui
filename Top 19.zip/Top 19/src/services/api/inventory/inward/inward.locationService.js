import { topApiClient } from "src/services/topApiClient"

const inward_location_services = {
    getProductLocation: async function (filter) {
        return topApiClient.get(`/product-inward-location/${filter}`)
    }
}

export default inward_location_services;