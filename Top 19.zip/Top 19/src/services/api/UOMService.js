import { topApiClient } from '../topApiClient';

const UOMService = {
    create: async function (data) {
        const headers = {
            'Content-type': 'application/json'
        }
        return await topApiClient.post(`/uom`, data, headers);
    },
    update: async function(id, data) {
        const headers = {
            'Content-type': 'application/json'
        }
        return await topApiClient.patch(`/uom/${id}`, data , headers);
    },
    getAll: async function () {
        return await topApiClient.get('/uom');
    },
    remove: async function (id) {
        return topApiClient.delete(`/uom/${id}`);
    },
}

export { UOMService };