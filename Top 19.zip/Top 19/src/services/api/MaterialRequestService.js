import { topApiClient } from "../topApiClient";

const headers = {
  "Content-type": "application/json",
};

const MaterialRequestService = {
  getAll: async function (page) {
    let url = "/material-requests";
    if (page) url += `?page=${page}`;
    return await topApiClient.get(url);
  },
  getItem: async function (id) {
    return await topApiClient.get(`/material-request/${id}`);
  },
  create: async function (data) {
    return await topApiClient.post(`/material-request`, data, headers);
  },
  update: async function (id, data) {
    return topApiClient.patch(`/material-request/${id}`, data, headers);
  },
  delete: async function (id) {
    return await topApiClient.delete(`/material-request/${id}`);
  },
  get: async function (id) {
    return await topApiClient.get(`/material-request/${id}`);
  },
  getByMRNo: async function (mr_no) {
    return await topApiClient.get(`/material-requests?mr_no=${mr_no}`);
  },

  Item: {
    create: async function (data) {
      return await topApiClient.post(`request-material`, data);
    },
    remove: async function (id) {
      return await topApiClient.delete(`/request-material/${id}`);
    },
    update: async function (id, data) {
      return topApiClient.patch(`/request-material/${id}`, data);
    },
    delete: async function (id) {
      return topApiClient.delete(`/materal-request-entries/${id}`)
    }
  },
};

export { MaterialRequestService };
