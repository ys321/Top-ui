import { createAsyncThunk } from "@reduxjs/toolkit";
import { business_settings_service } from "src/services/api/BussinessSettingsService";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createCityManagement = createAsyncThunk(
  "@cityManagement/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await business_settings_service.city_service.create(params.cityManagement);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "City Management",
            message: "City Management Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "City Management Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateCityManagement = createAsyncThunk(
  "@cityManagement/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.cityManagement.id) {
        const res = await business_settings_service.city_service.update(
          params.cityManagement.id,
          params.cityManagement
        );
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "City Management",
            message: "City Management Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "City Management Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteCityManagement = createAsyncThunk(
  "@cityManagement/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await business_settings_service.city_service.remove(params.ct.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "City Management",
            message: "City Management Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "City Management Delete Failed",
            message: "City Management Delete Failed",
          })
        );
      });
  }
);
