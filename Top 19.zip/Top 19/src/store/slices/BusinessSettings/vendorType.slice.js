import { createAsyncThunk } from "@reduxjs/toolkit";
import { VendorService } from "src/services/api/VendorService";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createVendorType = createAsyncThunk(
  "@vendorType/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await VendorService.VendorTypeService.create(params.vendorType);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Vendor Type",
            message: "Vendor Type Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Type Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateVendorType = createAsyncThunk(
  "@vendorType/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.vendorType.id) {
        const res = await VendorService.VendorTypeService.update(
          params.vendorType.id,
          params.vendorType
        );
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Vendor Type",
            message: "Vendor Type Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Type Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteVendorType = createAsyncThunk(
  "@vendorType/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await VendorService.VendorTypeService.remove(params.vt.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Vendor Type",
            message: "Vendor Type Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Type Delete Failed",
            message: "Vendor Type Delete Failed",
          })
        );
      });
  }
);
