import { createAsyncThunk } from "@reduxjs/toolkit";
import WeightUnitService from "src/services/api/WeightUnitService";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createProductUnit = createAsyncThunk(
  "@productUnit/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await WeightUnitService.create(params.productUnit);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Product Unit",
            message: "Product Unit Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Unit Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateProductUnit = createAsyncThunk(
  "@productUnit/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.productUnit.id) {
        const res = await WeightUnitService.update(
          params.productUnit.id,
          params.productUnit
        );
        return res;
      }
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Product Unit",
            message: "Product Unit Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Unit Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteProductUnit = createAsyncThunk(
  "@productUnit/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await WeightUnitService.remove(params.pu.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Product Unit",
            message: "Product Unit Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Unit Delete Failed",
            message: "Product Unit Delete Failed",
          })
        );
      });
  }
);
