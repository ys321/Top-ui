const { createSlice } = require("@reduxjs/toolkit");

const initialState = {
  city: [],
};

const cities = createSlice({
  name: 'city',
  initialState: initialState,
  reducers: {
    setCities: (state, { payload }) => {
      state.city = payload;
    },
  },
});

export const { setCities } = cities.actions;
export const cityReducer = cities.reducer;
