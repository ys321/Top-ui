import { createAsyncThunk } from "@reduxjs/toolkit";
import { MaterialRequestService } from "src/services/api/MaterialRequestService";
import { errorAlert, successAlert, warningAlert } from "./alert.slice";
import { toggleProcess } from "./process.slice";

export const createMaterialRequest = createAsyncThunk(
  "@materialRequest/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.entries === null) {
        console.log(null);
      } else {
        params.materialRequest.branch = params.branch;
        params.materialRequest.status = 1;
        params.materialRequest.entries = [];
        params.entries.forEach((entry) => {
          params.materialRequest.entries.push({
            product: entry?.product?.id,
            amount: entry?.amount,
            discount: entry?.discount,
            ordered_qty: entry?.ordered_qty,
            extra_details: entry?.extra_details,
            basic_rate: entry.basic_rate,
            // uom: entry?.uom?.id,
          });
        });
      }

      const res = await MaterialRequestService.create(params.materialRequest);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Material Request",
            message: "Material Request Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Material Request Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateMaterialRequest = createAsyncThunk(
  "@materialRequest/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.branch) {
        params.materialRequest.branch = params.branch;
      }
      params.materialRequest.status = 2;
      if (params.entries) {
        params.materialRequest.entries = [];
        params.entries.forEach((entry) => {
          params.materialRequest.entries.push({
            product: entry?.product?.id,
            amount: entry?.amount,
            discount: entry?.discount,
            ordered_qty: entry?.ordered_qty,
            extra_details: entry?.extra_details,
            basic_rate: entry.basic_rate,
            // uom: entry?.uom?.id,
          });
        });
      }
      const res = await MaterialRequestService.update(
        params.productItem.id,
        params.materialRequest
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Material Request",
            message: "Material Request Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Material Request Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteMaterialRequest = createAsyncThunk(
  "@materialRequest/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await MaterialRequestService.delete(params.currentRow.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Material Request",
            message: "Material Request Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Material Request Delete Failed",
            message: "Material Request Delete Failed",
          })
        );
      });
  }
);

export const deleteProductItem = createAsyncThunk(
  "@productItem/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    console.log(params.currentRow);

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.currentRow?.id) {
        await MaterialRequestService.Item.delete(params.currentRow?.id);
      } else return null;
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Material Request Item",
            message: "Material Request Item Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Material Request Item Delete Failed",
            message: "Material Request Item Delete Failed",
          })
        );
      });
  }
);
