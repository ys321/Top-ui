import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { ProductService } from "src/services/api/ProductService";
import { errorAlert, successAlert, warningAlert } from "./alert.slice";
import { toggleProcess } from "./process.slice";

export const createProductVendorLink = createAsyncThunk(
  "@productVendorLink/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await ProductService.ProductVendorLink.update(
        params.product,
        params.vendor
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Product Vendor Link",
            message: "Product Vendor Link Create Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Vendor Link Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteProductVendorLink = createAsyncThunk(
  "@productVendorLink/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await ProductService.ProductVendorLink.remove(params.product, {
        vendor: params.vendor.id,
      });
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Product Vendor Link",
            message: "Product Vendor Link Delete Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Vendor Link Delete Failed",
            message: "Product Vendor Link Delete Failed",
          })
        );
      });
  }
);

export const createProductMedia = createAsyncThunk(
  "@productMedia/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );

    (async () => {
      const ProductMediaData = new FormData();
      ProductMediaData.append("product", params.product);
      ProductMediaData.append("image", params.image);
      const res = await ProductService.ProductMediaService.create(
        ProductMediaData
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Product Media",
            message: "Product Media Create Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Media Create Failed",
            message: "invalid Data",
          })
        );
      });
  }
);

export const deleteProductMedia = createAsyncThunk(
  "@productMedia/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await ProductService.ProductMediaService.remove(
        params.productImage.id
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Product Media",
            message: "Product Media Delete Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Product Media Delete Failed",
            message: "Product Media Delete Failed",
          })
        );
      });
  }
);

/*** the above section can be removed in future */

const initialState = {
  products: []
}

const products = createSlice({
  name: 'products',
  initialState: initialState,
  reducers: {
      setProducts : (state, { payload }) => {
          state.products = payload;
      }
  }
});

export const { setProducts } = products.actions;
export const productReducer = products.reducer; 
