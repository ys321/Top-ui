import axios from "axios";

export default axios.create({
    baseURL : "http://10.10.1.3:8000/tiepltd-api",
    headers : {
        "Content-type" : "application/json"
    }
});