import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {} from "@mui/material";

import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogActions,
  DialogTitle,
  DialogContent,
  DialogContentText,
  Box,
  TextField,
  FormControl,
  MenuItem,
  InputLabel,
  IconButton,
} from "@mui/material";
import { Grid,Button,Select,Menu} from "@mui/joy"

import MoreVertIcon from "@mui/icons-material/MoreVert";
import { locationValidationSchema } from "src/utils/validation/category.validation";

import { LocationService } from "src/services/api/LocationService";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { ProductService } from "src/services/api/ProductService";
import ToastAlert from "src/components/Toast/ToastAlert";
import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";
import TOPButton from "src/components/Button/TopButton";
import { QueryKeys } from "src/services/queryKey";

function LocationList({ product }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(locationValidationSchema),
  });

  const [open, showBusinessLocationModel] = useState(false);

  const [businessLocations, setBusinessLocations] = useState([]);
  const [currentLocation, setCurrentLocation] = useState("");
  const [businessLocationOptions, setBusinessLocationOptions] = useState([]);

  const [currentFloor, setCurrentFloor] = useState("");
  const [floorOptions, setFloorOptions] = useState([]);

  const [currentSection, setCurrentSection] = useState("");
  const [sectionOptions, setSectionOptions] = useState([]);

  const [currentRack, setCurrentRack] = useState("");
  const [rackOptions, setRackOptions] = useState([]);

  const [currentshelf, setCurrentShelf] = useState("");
  const [shelfOptions, setShelfOptions] = useState([]);

  const [currentBin, setCurrentBin] = useState("");
  const [binOptions, setBinOptions] = useState([]);

  // const [tabContext, setTabContext] = useState('1');
  const [productLocationDailogAction, setProductLocationDailogAction] =
    useState("CREATE");
  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const [productLocation, setProductLocation] = useState({});
  const [productLocationAll, setProductLocationAll] = useState([]);

  const [toastData, setToastData] = useState({
    visible: false,
    variant: "",
    title: "",
    sinceTime: "",
    body: "",
    image: "",
  });

  const {
    isLoading: locationLoading,
  
    refetch,
  } = useQuery(
    [QueryKeys.getAllLocations],
    async () => {
      return await LocationService.getAll();
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setBusinessLocations(response);
        setBusinessLocationOptions(renderOptions(response.data, "name"));
        (async () => {
          const product_data =
            await ProductService.ProductLocationSerivce.getAll();
          setProductLocationAll(product_data);
        })();
      },
      staleTime: 0,
    }
  );

  const { mutate: saveProductLocation } = useMutation(
    async () => {
      let response = null;

      switch (productLocationDailogAction) {
        case "CREATE":
          productLocation.product = product;
          response = await ProductService.ProductLocationSerivce.create(
            productLocation
          );
          businessLocations.push(response.data);
          return response.data;

        //     case 'UPDATE':
        //         response = await ProductService.ProductLocationSerivce.update(businessLocation.id, businessLocation)
        //         businessLocations[businessLocations.findIndex(
        //             (f) => f.id === businessLocation.id)].name = businessLocation.name;
        //         return response.data;
      }
    },
    {
      onSuccess: (response) => {
        hideAndClearBusinessLocationDailog();
        setProductLocation({});
        refetch();
        setToastData({
          visible: true,
          variant: "success",
          title: "Product Location",
          sinceTime: "",
          body: `Product Location is Addedd !`,
          image: "",
        });

        setTimeout(() => setToastData({ visible: false }), 3000);
      },
    }
  );

  if (locationLoading) {
    return <h1>Loading...</h1>;
  }

  function inputHandler(e, dropDown) {
    const { name, value } = e.target;

    if (value === "" || value === null) {
      return;
    }

    if (dropDown) {
      delete productLocation[name];
    }

    if (dropDown) {
      setProductLocation({
        ...productLocation,
        ...dropDown,
      });

      return;
    }

    setProductLocation({
      ...productLocation,
      [name]: value,
    });
  }

  async function locationInputHandler(e, type) {
    let response = null;
    switch (type) {
      case "LOCATION":
        setCurrentLocation(e.target.value);
        setProductLocation({
          ...productLocation,
          location: e.target.value,
        });

        setCurrentFloor("");
        setCurrentSection("");
        setCurrentRack("");
        setCurrentShelf("");
        setCurrentBin("");

        response = await LocationService.FloorService.getAll(e.target.value);
        setFloorOptions(renderOptions(response.data, "name"));

        break;
      case "FLOOR":
        setCurrentFloor(e.target.value);
        setProductLocation({
          ...productLocation,
          floor: e.target.value,
        });
        setCurrentSection("");
        setCurrentRack("");
        setCurrentShelf("");
        setCurrentBin("");
        response = await LocationService.FloorService.SectionService.getAll(
          currentLocation,
          e.target.value
        );
        setSectionOptions(renderOptions(response.data, "name"));
        break;
      case "SECTION":
        setCurrentSection(e.target.value);
        setProductLocation({
          ...productLocation,
          section: e.target.value,
        });
        setCurrentRack("");
        setCurrentShelf("");
        setCurrentBin("");
        response =
          await LocationService.FloorService.SectionService.RackService.getAll(
            currentLocation,
            currentFloor,
            e.target.value
          );
        setRackOptions(renderOptions(response.data, "name"));
        break;
      case "RACK":
        setCurrentRack(e.target.value);
        setProductLocation({
          ...productLocation,
          rack: e.target.value,
        });
        setCurrentShelf("");
        setCurrentBin("");
        response =
          await LocationService.FloorService.SectionService.RackService.ShelfService.getAll(
            currentLocation,
            currentFloor,
            currentSection,
            e.target.value
          );
        setShelfOptions(renderOptions(response.data, "name"));
        break;
      case "SHELF":
        setCurrentShelf(e.target.value);
        setProductLocation({
          ...productLocation,
          shelf: e.target.value,
        });
        setCurrentBin("");
        response =
          await LocationService.FloorService.SectionService.RackService.ShelfService.BinServices.getAll(
            currentLocation,
            currentFloor,
            currentSection,
            currentRack,
            e.target.value
          );
        setBinOptions(renderOptions(response.data, "name"));
        break;
      case "BIN":
        setProductLocation({
          ...productLocation,
          bin: e.target.value,
        });
        setCurrentBin(e.target.value);
        break;
    }
  }

  function renderOptions(data, lookup) {
    const _ea = [];
    data.map((el, index) => {
      _ea.push(
        <MenuItem key={index} value={el.id}>
          {el.name || el[lookup]}
        </MenuItem>
      );
    });
    return _ea;
  }

  const hideAndClearBusinessLocationDailog = () => {
    showBusinessLocationModel(false);
    reset();
    setProductLocation("");
    setProductLocationDailogAction("CREATE");
  };

  // DELETE Product Location
  async function deleteProductLocationHandler(p, index) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Product Location",
      description: `Are you sure want to delete ?`,
      confrimHandler: async function () {
        await ProductService.ProductLocationSerivce.remove(p.id).then(
          (response) => {
            if (response.status === 204) {
              businessLocations.pop(index);
              setConfirmationParams({ open: false });
              reset();
              refetch();

              setToastData({
                visible: true,
                variant: "danger",
                title: "Product Location",
                sinceTime: "",
                body: `Product Location is Deleted !`,
                image: "",
              });

              setTimeout(() => setToastData({ visible: false }), 3000);
            }
          }
        );
      },
    });
  }

  return (
    <>
      {locationLoading ? <h1>Loading...</h1> : <></>}
      <div></div>

      <div>
        <Dialog
          open={conformationParams.open}
          onClose={() => {
            setConfirmationParams({ open: false });
          }}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            {conformationParams.title}
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {conformationParams.description}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                setConfirmationParams({ open: false });
              }}
            >
              {conformationParams.cencelTitle}
            </Button>
            <Button onClick={conformationParams.confrimHandler} autoFocus>
              {conformationParams.confrimTitle}
            </Button>
          </DialogActions>
        </Dialog>
      </div>

      <Box style={{ padding: "10px" }}>
        <Grid container spacing={3} justifyContent={"flex-end"}>
          <TOPButton
            text={"Link Location"}
            variant={"success"}
            onClick={() => showBusinessLocationModel(true)}
          />
          <TableContainer component={Paper} style={{ marginTop: "15px" }}>
            <Table sx={{ minWidth: 700 }} aria-label="customized table">
              <TableHead>
                <TableRow>
                  <StyledTableCell>Branch Name</StyledTableCell>
                  <StyledTableCell>Floor</StyledTableCell>
                  <StyledTableCell>Section</StyledTableCell>
                  <StyledTableCell>Rack</StyledTableCell>
                  <StyledTableCell>Shelf</StyledTableCell>
                  <StyledTableCell>Bin</StyledTableCell>
                  <StyledTableCell>Product Quantity</StyledTableCell>
                  <StyledTableCell>Buffer Quantity</StyledTableCell>
                  <StyledTableCell>Action</StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {productLocationAll.map((p, index) => (
                  <StyledTableRow key={index}>
                    <StyledTableCell>{p.location.name}</StyledTableCell>
                    <StyledTableCell>{p.floor?.name}</StyledTableCell>
                    <StyledTableCell>{p.section?.name}</StyledTableCell>
                    <StyledTableCell>{p.rack?.name}</StyledTableCell>
                    <StyledTableCell>{p.shelf?.name}</StyledTableCell>
                    <StyledTableCell>{p.bin?.name}</StyledTableCell>
                    <StyledTableCell>{p.qty}</StyledTableCell>
                    <StyledTableCell>{p.buffer_qty}</StyledTableCell>
                    <StyledTableCell>
                      <ProductLocationDelete
                        p={p}
                        deleteActionHandler={deleteProductLocationHandler}
                      />
                    </StyledTableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Box>

      <Dialog
        fullWidth={true}
        maxWidth={"lg"}
        open={open}
        onClose={() => {
          hideAndClearBusinessLocationDailog();
          reset();
        }}
      >
        <DialogTitle>Product Location</DialogTitle>
        <DialogContent>
          <Grid container spacing={1}>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth margin="dense">
                <InputLabel id={"location"} size="small">
                  {"Location"}
                </InputLabel>
                <Select
                  size="small"
                  {...register("location")}
                  error={errors.location ? true : false}
                  helpertext={errors.location?.message}
                  labelId={"location"}
                  id={"location"}
                  value={currentLocation}
                  label={"Location"}
                  onChange={(e) => {
                    locationInputHandler(e, "LOCATION");
                  }}
                >
                  {businessLocationOptions}
                </Select>
              </FormControl>
            </Grid>

            {currentLocation && floorOptions.length > 0 ? (
              <>
                <Grid item xs={12} md={2}>
                  <FormControl fullWidth margin="dense">
                    <InputLabel id={"floor"} size="small">
                      Floor
                    </InputLabel>
                    <Select
                      size="small"
                      labelId={"floor"}
                      id={"floor"}
                      value={currentFloor}
                      label={"Floor"}
                      margin="dense"
                      onChange={(e) => {
                        locationInputHandler(e, "FLOOR");
                      }}
                    >
                      {floorOptions}
                    </Select>
                  </FormControl>
                </Grid>
              </>
            ) : (
              <></>
            )}

            {currentFloor && sectionOptions.length > 0 ? (
              <>
                <Grid item xs={12} md={2} marginTop={1}>
                  <FormControl fullWidth>
                    <InputLabel id={"section"} size="small">
                      Section
                    </InputLabel>
                    <Select
                      size="small"
                      labelId={"section"}
                      id={"section"}
                      value={currentSection}
                      label={"Section"}
                      margin="dense"
                      onChange={(e) => {
                        locationInputHandler(e, "SECTION");
                      }}
                    >
                      {sectionOptions}
                    </Select>
                  </FormControl>
                </Grid>
              </>
            ) : (
              <></>
            )}

            {currentSection && rackOptions.length > 0 ? (
              <>
                <Grid item xs={12} md={2} marginTop={1}>
                  <FormControl fullWidth>
                    <InputLabel id={"rack"} size="small">
                      Rack
                    </InputLabel>
                    <Select
                      size="small"
                      labelId={"rack"}
                      id={"rack"}
                      value={currentRack}
                      label={"Rack"}
                      margin="dense"
                      onChange={(e) => {
                        locationInputHandler(e, "RACK");
                      }}
                    >
                      {rackOptions}
                    </Select>
                  </FormControl>
                </Grid>
              </>
            ) : (
              <></>
            )}

            {currentRack && shelfOptions.length > 0 ? (
              <>
                <Grid item xs={12} md={2} marginTop={1}>
                  <FormControl fullWidth>
                    <InputLabel id="shelf" size="small">
                      Shelf
                    </InputLabel>
                    <Select
                      size="small"
                      labelId="shelf"
                      id="shelf"
                      value={currentshelf}
                      label="Shelf"
                      margin="dense"
                      onChange={(e) => {
                        locationInputHandler(e, "SHELF");
                      }}
                    >
                      {shelfOptions}
                    </Select>
                  </FormControl>
                </Grid>
              </>
            ) : (
              <></>
            )}

            {currentshelf && binOptions.length > 0 ? (
              <>
                <Grid item xs={12} md={2} marginTop={1}>
                  <FormControl fullWidth>
                    <InputLabel id="bin" size="small">
                      Bin
                    </InputLabel>
                    <Select
                      size="small"
                      labelId="bin"
                      id="bin"
                      value={currentBin}
                      label="Bin"
                      margin="dense"
                      onChange={(e) => {
                        locationInputHandler(e, "BIN");
                      }}
                    >
                      {binOptions}
                    </Select>
                  </FormControl>
                </Grid>
              </>
            ) : (
              <></>
            )}

            <Grid item xs={12} md={4}>
              <TextField
                size="small"
                id="product_qty"
                label="Product Quantity"
                type="product_qty"
                name="qty"
                variant="outlined"
                margin="dense"
                fullWidth
                onChange={(e) => {
                  if (e.target.value) {
                    inputHandler(e);
                  }
                }}
                defaultValue={productLocation.product_qty}
                {...register("product_qty")}
                error={errors.product_qty ? true : false}
                helperText={errors.product_qty?.message}
              />
            </Grid>
            <Grid item xs={12} md={4} marginTop={1}>
              <TextField
                size="small"
                id="buffer_qty"
                label="Buffer Quantity"
                type="text"
                name="buffer_qty"
                variant="outlined"
                fullWidth
                onChange={(e) => {
                  if (e.target.value) {
                    inputHandler(e);
                  }
                }}
                defaultValue={productLocation.buffer_qty}
                {...register("buffer_qty")}
                error={errors.buffer_qty ? true : false}
                helperText={errors.buffer_qty?.message}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <TOPButton
            text={"Save"}
            variant={"success"}
            onClick={handleSubmit(saveProductLocation)}
          />
          <TOPButton
            text={"Cancel"}
            variant={"danger"}
            onClick={() => {
              hideAndClearBusinessLocationDailog();
              reset();
            }}
          />
        </DialogActions>
      </Dialog>
      <ToastAlert {...toastData}></ToastAlert>
    </>
  );
}

function ProductLocationDelete({ p, deleteActionHandler }) {
  const [anchorEl, setAnchorEl] = useState(null);
  const openDropdown = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleCloseDropdown = () => {
    setAnchorEl(null);
  };
  return (
    <>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={openDropdown ? "long-menu" : undefined}
        aria-expanded={openDropdown ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={openDropdown}
        onClose={handleCloseDropdown}
        PaperProps={{
          style: {
            maxHeight: 48 * 4.5,
            width: "20ch",
          },
        }}
      >
        <MenuItem onClick={() => deleteActionHandler(p)}>Delete</MenuItem>
      </Menu>
    </>
  );
}

export default LocationList;
