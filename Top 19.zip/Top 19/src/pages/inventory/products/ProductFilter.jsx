import { Box, Button, Grid, Stack, TextField } from "@mui/joy";
import { useQuery } from "@tanstack/react-query";
import { Form, Formik } from "formik";
import { useRef, useState } from "react";
import TopDropdown from "src/components/TopDropdown/TopDropdown";
import { CategoryService } from "src/services/api/CategoryService";
import { ProductService } from "src/services/api/ProductService";
import { ProductClassService } from "src/services/api/ProductClass.service";
import { QueryKeys } from "src/services/queryKey";
import * as yup from "yup";
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import { EditText } from "src/components/EditText";

export default function ProductFilter({ dialogHandle }) {
  const product_validation_schema = yup.object().shape({
    name: yup
      .string()
      .required("Product name is required")
      .min(2, "Product name should be minimum 2 characters long")
      .max(50, "Product name should be maximum 50 characters long"),

    purchase_unit: yup
      .number()
      .typeError("Please select valid Inventory UOM.")
      .required("Inventory UOM is required"),

    inventory_unit: yup
      .number()
      .typeError("Please select valid Purchase UOM.")
      .required("Purchase UOM is required"),

    product_class: yup
      .number()
      .typeError("Please select valid Product Class.")
      .required("Product Class is required"),
  });

  const formRef = useRef();
  const [product, setProduct] = useState({});

  const [uoms, setUoms] = useState([]);
  const [categories, setCategories] = useState([]);
  const [sub_categories, setSubCategories] = useState([]);
  const [productClasees, setProductClasses] = useState([]);
  const [filterParam, setFilterParams] = useState("");
  const [productData, setProductData] = useState();
  console.log(filterParam);

  const { isLoading: ProductFilterLoading, refetch: refetchProductFilter } =
    useQuery(
      [QueryKeys.getAllProducts],
      async () => {
        return await ProductService.getAll({
          filter: filterParam,
        });
      },
      {
        enabled: true,
        onSuccess: (response) => {
          setProductData(response.data);
        },
        staleTime: 500,
      }
    );

  function productFilter(values) {
    let params = [];

    if (formRef.current.values.code) {
      params.push(`code=${formRef.current.values.code}`);
    }
    if (formRef.current.values.name) {
      params.push(`name=${formRef.current.values.name}`);
    }
    if (product?.category) {
      params.push(`category=${product?.category}`);
    }
    if (formRef.current.values.sub_category) {
      params.push(`sub_category=${formRef.current.values.sub_category}`);
    }
    if (formRef.current.values.purchase_unit) {
      params.push(`purchase_unit=${formRef.current.values.purchase_unit}`);
    }
    if (formRef.current.values.inventory_unit) {
      params.push(`inventory_unit=${formRef.current.values.inventory_unit}`);
    }
    if (formRef.current.values.inventory_unit_value) {
      params.push(
        `inventory_unit_value=${formRef.current.values.inventory_unit_value}`
      );
    }

    setFilterParams(params.join("&"));
  }

  const { isLoading: categoryLoading, refetch: categoryRefetch } = useQuery(
    [QueryKeys.getAllCategories],
    async () => {
      return await CategoryService.getAll();
    },
    {
      onSuccess: (response) => {
        setCategories(response.data);
      },
      staleTime: 0,
    }
  );

  const { isLoading: subCategoryLoading, refetch: subCategoryRefetch } =
    useQuery(
      [[QueryKeys.getAllSubCategories], product?.category],
      async () => {
        if (product?.category) {
          const response = await CategoryService.SubCategoryService.getAll(
            product?.category
          );
          return response;
        }
        return null;
      },
      {
        onSuccess: (response) => {
          if (response) setSubCategories(response.data.sub_category);
        },
        staleTime: 0,
      }
    );

  const { isLoading: uomLoading, refetch: uomRefetch } = useQuery(
    [QueryKeys.getAllUOM],
    async () => {
      return ProductService.ProductUnits.getAll();
    },
    {
      onSuccess: (response) => {
        setUoms(response.data);
      },
      staleTime: 0,
    }
  );

  const { isLoading: productClassLoading, refetch: productClassRefech } =
    useQuery(
      [QueryKeys.getAllProductClasses],
      async () => {
        return await ProductClassService.getAll();
      },
      {
        onSuccess: (response) => {
          setProductClasses(response.data);
        },
        staleTime: 0,
      }
    );

  if (
    categoryLoading ||
    subCategoryLoading ||
    productClassLoading ||
    uomLoading ||
    ProductFilterLoading
  ) {
    // return <></>;
  }

  return (
    <>
      <Box margin={1}>
        <Formik
          initialValues={{
            code: "",
            name: "",
            sub_category: "",
            purchase_unit: "",
            purchase_unit_value: "",
            inventory_unit: "",
            inventory_unit_value: "",
          }}
          onSubmit={async (values) => {
            productFilter(values);
            console.log(values);
            dialogHandle(false);
          }}
          innerRef={formRef}
          validationSchema={product_validation_schema}
        >
          {({
            values,
            errors,
            handleChange,
            setValues,
            touched,
            setFieldValue,
          }) => (
            <Form>
              <Grid container spacing={2} padding={2}>
                <Grid item xs={12} md={3}>
                  {/* <TextField
                    autoFocus
                    size="md"
                    margin="dense"
                    fullWidth
                    name="code"
                    label="Code"
                    variant="outlined"
                    value={values.code}
                    onChange={handleChange}
                    error={errors.code ? true : false}
                    helperText={errors.code}
                  /> */}
                  <EditText
                    name="code"
                    placeholder="Code"
                    onChange={handleChange}
                    value={values.code}
                    error={errors.code}
                    helpertext={errors.code}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="name"
                    label="Name"
                    variant="outlined"
                    value={values.name}
                    onChange={handleChange}
                    error={errors.name ? true : false}
                    helperText={errors.name}
                  /> */}
                  <EditText
                    name="name"
                    placeholder="Name"
                    onChange={handleChange}
                    value={values.name}
                    error={errors.name}
                    helpertext={errors.name}
                  />
                </Grid>

                <Grid item xs={12} md={3} marginTop={2}>
                  <TopDropdown
                    props={{
                      id: "categroy",
                      name: "category",
                      label: "Category",
                      size: "small",
                      onChange: (e) => {
                        const { name, value } = e.target;

                        setProduct({
                          ...product,
                          [name]: value,
                          sub_category: null,
                        });
                      },
                      value: product?.category,
                    }}
                    options={categories}
                    lookup="name"
                  />
                </Grid>
                {product?.category ? (
                  <>
                    <Grid item xs={12} md={3} marginTop={2}>
                      <TopDropdown
                        props={{
                          id: "sub_category",
                          name: "sub_category",
                          label: "Sub Category",
                          size: "small",
                          onChange: handleChange,
                          value: values?.sub_category,
                          error: errors.sub_category ? true : false,
                        }}
                        options={sub_categories}
                        lookup="name"
                        errorText={errors.sub_category?.message}
                      />
                    </Grid>
                  </>
                ) : (
                  <></>
                )}

                <Grid item md={3} xs={12} marginTop={2}>
                  <TopDropdown
                    props={{
                      id: "purchase_unit",
                      name: "purchase_unit",
                      label: "Purchase UOM",
                      size: "small",
                      onChange: handleChange,
                      value: values?.purchase_unit,
                      error: errors.purchase_unit ? true : false,
                    }}
                    options={uoms}
                    lookup="name"
                    errorText={errors.purchase_unit?.message}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  {/* <TextField
                    margin="dense"
                    id="purchase_unit_value"
                    name="purchase_unit_value"
                    label="Purchase Unit Value"
                    type="text"
                    fullWidth
                    variant="outlined"
                    onChange={handleChange}
                    value={values.purchase_unit_value || ""}
                    error={errors.purchase_unit_value ? true : false}
                    helperText={errors.purchase_unit_value?.message}
                  /> */}
                  <EditText
                    name="purchase_unit_value"
                    placeholder="Purchase Unit Value"
                    onChange={handleChange}
                    value={values.purchase_unit_value}
                    error={errors.purchase_unit_value}
                    helpertext={errors.purchase_unit_value}
                  />
                </Grid>

                <Grid item md={3} xs={12} marginTop={2}>
                  <TopDropdown
                    props={{
                      id: "inventory_unit",
                      name: "inventory_unit",
                      label: "Inventory UOM",
                      size: "small",
                      onChange: handleChange,
                      value: values?.inventory_unit,
                      error: errors.inventory_unit ? true : false,
                    }}
                    options={uoms}
                    lookup="name"
                    errorText={errors.inventory_unit?.message}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  {/* <TextField
                    margin="dense"
                    id="inventory_unit_value"
                    name="inventory_unit_value"
                    label="Inventory Unit Value"
                    type="text"
                    fullWidth
                    variant="outlined"
                    onChange={handleChange}
                    value={values.inventory_unit_value || ""}
                    error={errors.inventory_unit_value ? true : false}
                    helperText={errors.inventory_unit_value?.message}
                  /> */}
                  <EditText
                    name="inventory_unit_value"
                    placeholder="Inventory Unit Value"
                    onChange={handleChange}
                    value={values.inventory_unit_value}
                    error={errors.inventory_unit_value}
                    helpertext={errors.inventory_unit_value}
                  />
                </Grid>

                <Grid item xs={12} md={3} marginTop={2}>
                  <TopDropdown
                    props={{
                      id: "product_class",
                      name: "product_class",
                      label: "Product Class",
                      size: "small",
                      onChange: handleChange,
                      value: values?.product_class,

                      error: errors.product_class ? true : false,
                    }}
                    options={productClasees}
                    lookup="name"
                    errorText={errors.product_class?.message}
                  />
                </Grid>

                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"end"}
                    alignItems={"center"}
                    spacing={2}
                  >
                    <Button startDecorator={<SaveIcon />} variant="solid" type="submit" onLoad={() => { }}>
                      Save
                    </Button>
                    <Button
                      startDecorator={<CancelIcon />}
                      variant="solid"
                      color="danger"
                      onClick={() => dialogHandle(false)}
                    >
                      Cancel
                    </Button>
                  </Stack>
                </Grid>
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>
    </>
  );
}
