import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import * as yup from "yup";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import { Alert, Grid,  Stack } from "@mui/joy";
import {  TextField ,Snackbar} from "@mui/material";
import TopDropdown from "src/components/TopDropdown/TopDropdown";
import ProductAttributes from "src/components/ProductAttributes/ProductAttributes";

import { ProductService } from "src/services/api/ProductService";
import { CategoryService } from "src/services/api/CategoryService";
import { ProductClassService } from "src/services/api/ProductClass.service";
import { useEffect } from "react";

import { QueryKeys } from "src/services/queryKey";
import { successAlert } from "src/store/slices/alert.slice";
import { useDispatch } from "react-redux";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

function ProductForm({ dailogHandler, successCallback, data, action, onSave }) {
  const [product, setProduct] = useState({});

  const [, setWeightUnits] = useState([]);
  const [categories, setCategories] = useState([]);
  const [sub_categories, setSubCategories] = useState([]);
  const [uoms, setUoms] = useState([]);
  const [productClasees, setProductClasses] = useState([]);

  const [attributes, setAttributes] = useState([]);
  const [variant, setVariant] = useState([]);

  const [openToast, setOpenToast] = useState(false);
  const [toastType, setToastType] = useState("success");
  const [toastText, setToastText] = useState("");

  const product_validation_schema = yup.object().shape({
    name: yup
      .string()
      .required("Product name is required")
      .min(2, "Product name should be minimum 2 characters long")
      .max(50, "Product name should be maximum 50 characters long"),
    // unit: yup.string().required("Product Weight is required"),
    // unit_value: yup.string().required("Weigh value is required"),
    category: yup
      .number()
      .typeError("Please select valid category")
      .required("Category is required"),
    sub_category: yup
      .number()
      .typeError("Please select valid sub category")
      .required("Sub category is required"),
    purchase_unit: yup
      .number()
      .typeError("Please select valid Inventory UOM.")
      .required("Inventory UOM is required"),
    inventory_unit: yup
      .number()
      .typeError("Please select valid Purchase UOM.")
      .required("Purchase UOM is required"),
    product_class: yup
      .number()
      .typeError("Please select valid Product Class.")
      .required("Product Class is required"),

    conversation_factor: yup.string().optional(),
  });

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(product_validation_schema),
  });

  const { isLoading: weightUnitLoading } = useQuery(
    [QueryKeys.getAllWeightUnit],
    async () => {
      return ProductService.ProductUnits.getAll();
    },
    {
      onSuccess: (response) => {
        setWeightUnits(response.data);
      },
      staleTime: 0,
    }
  );

  const { isLoading: categoryLoading } = useQuery(
    [QueryKeys.getAllCategories],
    async () => {
      return await CategoryService.getAll();
    },
    {
      onSuccess: (response) => {
        setCategories(response.data);
      },
      staleTime: 0,
    }
  );

  const { isLoading: subCategoryLoading } =
    useQuery(
      [[QueryKeys.getAllSubCategories], product?.category],
      async () => {
        if (product?.category) {
          const response = await CategoryService.SubCategoryService.getAll(
            product?.category
          );
          return response;
        }
        return null;
      },
      {
        onSuccess: (response) => {
          if (response) setSubCategories(response.data.sub_category);
        },
        staleTime: 0,
      }
    );

  const { isLoading: isAttributeLoading, refetch: refetchAttributes } =
    useQuery(
      [[QueryKeys.getAllAttributes], product?.sub_category],
      async () => {
        if (product?.sub_category) {
          return await CategoryService.SubCategoryService.AttributeService.getAll(
            product?.sub_category
          );
        } else return null;
      },
      {
        onSuccess: (response) => {
          setAttributes(response?.data.attributes || []);
        },
        staleTime: 0,
      }
    );

  const { isLoading: uomLoading } = useQuery(
    [QueryKeys.getAllUOM],
    async () => {
      return ProductService.ProductUnits.getAll();
    },
    {
      onSuccess: (response) => {
        setUoms(response.data);
      },
      staleTime: 0,
    }
  );

  const { isLoading: productClassLoading } =
    useQuery(
      [QueryKeys.getAllProductClasses],
      async () => {
        return await ProductClassService.getAll();
      },
      {
        onSuccess: (response) => {
          setProductClasses(response.data);
        },
        staleTime: 0,
      }
    );

  const dispatch = useDispatch();

  const queryClient = useQueryClient();
  const { mutate: SaveProduct } = useMutation(
    async () => {
      if (variant.length > 0) {
        product.variant = variant;
      }

      if (action === "update") {
        return await ProductService.update({ product: data, data: product });
      }
      return await ProductService.create(product);
    },
    {
      onSuccess: (response) => {
        if (successCallback) successCallback();
        if (onSave) onSave();
        setToastText(
          `Product ${product.name} - ${response.data.code} is saved !`
        );
        if (dailogHandler) dailogHandler(false); // close current open dailog
        queryClient.invalidateQueries([QueryKeys.getAllProducts]);

        dispatch(
          successAlert({
            visible: true,
            title: "Product",
            message: `Product ${product.name} - ${response.data.code} is saved !`,
          })
        );
      },
      onError: (response) => {
        setToastType("error");
        setToastText(JSON.stringify(response?.error));
        setOpenToast(true);
      },
    }
  );

  useEffect(() => {
    if (data) {
      setProduct({
        ...product,
        name: data?.name,
        category: data?.category.id,
        sub_category: data?.sub_category.id,
        inventory_unit: data?.inventory_unit?.id,
        inventory_unit_value: data?.inventory_unit_value,
        purchase_unit: data?.purchase_unit?.id,
        purchase_unit_value: data?.purchase_unit_value,
        product_class: data?.product_class?.id,
      });

      let _variant = [];

      if (data?.variant) {
        for (const variant of data?.variant) {
          _variant.push({
            attribute: variant.attribute.id,
            value: variant.value.value.id,
          });
        }
      }

      setVariant(_variant);
    }
  }, []);

  if (
    weightUnitLoading ||
    categoryLoading ||
    subCategoryLoading ||
    isAttributeLoading ||
    productClassLoading ||
    uomLoading
  ) {
    return <>Loading....</>;
  }

  function inputHandler(e) {
    const { name, value } = e.target;
    setProduct({
      ...product,
      [name]: value,
    });
  }

  const handleToastClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenToast(false);
  };

  function attributeHandler(obj) {
    const index = variant.findIndex((e) => e?.attribute === obj?.attribute);

    if (obj?.value === "") {
      if (index > -1) variant.pop(index);
      console.log(variant);
      return;
    }

    if (index === -1) {
      variant.push(obj);
    }

    if (index > -1) {
      variant[index] = obj;
    }
  }

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <TextField
            autoFocus
            size="small"
            margin="dense"
            id="name"
            name="name"
            label="Name of Product"
            type="text"
            fullWidth
            variant="outlined"
            {...register("name")}
            onChange={(e) => inputHandler(e)}
            value={product.name || ""}
            error={errors.name ? true : false}
            helperText={errors.name?.message}
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TopDropdown
            props={{
              id: "categroy",
              name: "category",
              label: "Category",
              size: "small",
              onChange: (e) => {
                const { name, value } = e.target;

                setValue("category", value, { shouldValidate: true });

                setProduct({
                  ...product,
                  [name]: value,
                  sub_category: null,
                });
              },
              value: product?.category,
              defaultValue: { ...setValue("category", product.category) },
              register: { ...register("category") },
              error: errors.category ? true : false,
            }}
            options={categories}
            lookup="name"
            errorText={errors.category?.message}
          />
        </Grid>

        {product?.category ? (
          <>
            <Grid item xs={12} md={4}>
              <TopDropdown
                props={{
                  id: "sub_category",
                  name: "sub_category",
                  label: "Sub Category",
                  size: "small",
                  onChange: (e) => {
                    const { name, value } = e.target;

                    setValue("sub_category", value, { shouldValidate: true });

                    setProduct({
                      ...product,
                      [name]: value,
                    });

                    setVariant([]);
                  },
                  value: product?.sub_category,
                  defaultValue: {
                    ...setValue("sub_category", product.sub_category),
                  },
                  register: { ...register("sub_category") },
                  error: errors.sub_category ? true : false,
                }}
                options={sub_categories}
                lookup="name"
                errorText={errors.sub_category?.message}
              />
            </Grid>
          </>
        ) : (
          <></>
        )}

        {isAttributeLoading ? (
          <>Loading attributes...</>
        ) : (
          attributes?.map((attribute, index) => {
            return (
              <Grid item md={4} xs={12} key={index}>
                <ProductAttributes
                  name={attribute.name}
                  props={{
                    name: attribute?.name,
                    id: attribute?.name,
                    onChange: attributeHandler,
                    label: attribute?.name,
                    size: "small",
                  }}
                  defaultValue={
                    variant.find((e) => e.attribute === attribute?.id)?.value ||
                    ""
                  }
                  options={attribute?.values}
                  objRef={attribute?.id}
                  onSaveSuccess={refetchAttributes}
                  saveDataFn={
                    CategoryService.SubCategoryService.AttributeService.addValue
                  }
                />
              </Grid>
            );
          })
        )}

        <Grid item md={4} xs={12}>
          <TopDropdown
            props={{
              id: "purchase_unit",
              name: "purchase_unit",
              label: "Purchase UOM",
              size: "small",
              onChange: (e) => {
                const { name, value } = e.target;

                setValue("purchase_unit", value, { shouldValidate: true });

                setProduct({
                  ...product,
                  [name]: value,
                });
              },
              value: product?.purchase_unit,
              defaultValue: {
                ...setValue("purchase_unit", product.purchase_unit),
              },
              register: { ...register("purchase_unit") },
              error: errors.purchase_unit ? true : false,
            }}
            options={uoms}
            lookup="name"
            errorText={errors.purchase_unit?.message}
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            autoFocus
            size="small"
            margin="dense"
            id="purchase_unit_value"
            name="purchase_unit_value"
            label="Purchase Unit Value"
            type="text"
            fullWidth
            variant="outlined"
            {...register("purchase_unit_value")}
            onChange={(e) => inputHandler(e)}
            value={product.purchase_unit_value || ""}
            error={errors.purchase_unit_value ? true : false}
            helperText={errors.purchase_unit_value?.message}
          />
        </Grid>

        <Grid item md={4} xs={12}>
          <TopDropdown
            props={{
              id: "inventory_unit",
              name: "inventory_unit",
              label: "Inventory UOM",
              size: "small",
              onChange: (e) => {
                const { name, value } = e.target;

                setValue("inventory_unit", value, { shouldValidate: true });

                setProduct({
                  ...product,
                  [name]: value,
                });
              },
              value: product?.inventory_unit,
              defaultValue: {
                ...setValue("inventory_unit", product.inventory_unit),
              },
              register: { ...register("inventory_unit") },
              error: errors.inventory_unit ? true : false,
            }}
            options={uoms}
            lookup="name"
            errorText={errors.inventory_unit?.message}
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <TextField
            autoFocus
            size="small"
            margin="dense"
            id="inventory_unit_value"
            name="inventory_unit_value"
            label="Inventory Unit Value"
            type="text"
            fullWidth
            variant="outlined"
            {...register("inventory_unit_value")}
            onChange={(e) => inputHandler(e)}
            value={product.inventory_unit_value || ""}
            error={errors.inventory_unit_value ? true : false}
            helperText={errors.inventory_unit_value?.message}
          />
        </Grid>

        {product.inventory_unit &&
        product.purchase_unit &&
        product.inventory_unit !== product.purchase_unit ? (
          <Grid item xs={12} md={4}>
            <TextField
              autoFocus
              margin="dense"
              id="conversation_factor"
              name="conversation_factor"
              label="Conversation Factor"
              type="text"
              size="small"
              fullWidth
              variant="outlined"
              {...register("cf")}
              onChange={(e) => inputHandler(e)}
              defaultValue={product?.conversation_factor?.value}
              error={errors.conversation_factor ? true : false}
              helperText={errors.conversation_factor?.message}
            />
            <span>
              {typeof product?.cf === "object" ? product?.cf?.title : ""}
            </span>
          </Grid>
        ) : (
          <></>
        )}

        <Grid item xs={12} md={4}>
          <TopDropdown
            props={{
              id: "product_class",
              name: "product_class",
              label: "Product Class",
              size: "small",
              onChange: (e) => {
                const { name, value } = e.target;

                setValue("product_class", value, { shouldValidate: true });

                setProduct({
                  ...product,
                  [name]: value,
                });
              },
              value: product?.product_class,
              defaultValue: {
                ...setValue("product_class", product.product_class),
              },
              register: { ...register("product_class") },
              error: errors.product_class ? true : false,
            }}
            options={productClasees}
            lookup="name"
            errorText={errors.product_class?.message}
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <Stack direction={"row"} justifyContent={"flex-end"} spacing={2}>
            <SaveButton
              startDecorator={<SaveIcon />}
              onClick={handleSubmit(SaveProduct)}
            />

            <CancelButton
              startDecorator={<CancelIcon />}
              onClick={() => {
                if (dailogHandler) {
                  dailogHandler(false);
                }
                reset();
              }}
            />
          </Stack>
        </Grid>
      </Grid>

      <Snackbar
        open={openToast}
        autoHideDuration={3000}
        onClose={handleToastClose}
      >
        <Alert severity={toastType} sx={{ width: "100%" }}>
          {toastText}
        </Alert>
      </Snackbar>
    </>
  );
}

export default ProductForm;
