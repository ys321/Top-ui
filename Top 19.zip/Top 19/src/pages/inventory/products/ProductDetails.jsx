import {  useState } from "react";
import { ProductService } from "src/services/api/ProductService";

import { useParams } from "react-router-dom";


import { Box, Grid } from "@mui/material";

import {
  Breadcrumbs,
  Link,
  Tab,
  TabList,
  TabPanel,
  Tabs,
} from "@mui/joy";


import { useQuery } from "@tanstack/react-query";

import VendorList from "./VendorList";
import LocationList from "./LocationList";
import InwardList from "./InwardListTable";

import _ from "lodash";

import ProductMedia from "src/pages/inventory/products/ProductMedia";

import ProductForm from "src/pages/inventory/products/ProductForm";
import { QueryKeys } from "src/services/queryKey";

function ProductDetails() {
  const { product_id } = useParams();
  const [product, setProduct] = useState({});

  const [tabContext, setTabContext] = useState("1");

  const { isLoading: productLoading, refetch: refetchProduct } = useQuery(
    [QueryKeys.getProduct],
    async () => {
      return await ProductService.get(product_id);
    },
    {
      onSuccess: (response) => {
        setProduct(response.data);
      },
      staleTime: 0,
    }
  );

  if (productLoading) {
    return (
      <>
        <h1>Loading...</h1>
      </>
    );
  }

  const handleTabContext = (event, newValue) => {
    setTabContext(newValue);
  };

  return (
    <>
      <Grid style={{ padding: "20px" }}>
        <Grid item>
          <Breadcrumbs aria-label="breadcrumb">
            <Link underline="hover" color="neutral" fontSize="inherit" href="/">
              Top Lift
            </Link>
            <Link underline="hover" color="neutral" fontSize="inherit" href="/inventory/product">
              Product
            </Link>
            <Link
              underline="hover"
              color="neutral" fontSize="inherit"
              href={`/inventory/product/:product_id`.replace(
                ":product_id",
                product.id
              )}
              aria-current="page"
            >
              {product.name}
            </Link>
          </Breadcrumbs>
        </Grid>
        <Grid item style={{ marginTop: "10px" }}>
          <Box xs={{ width: "100%", typography: "body1" }}>
            <Tabs defaultValue={0} sx={{ borderRadius: "lg" }}>
              <Box xs={{ borderBottom: 1, borderColor: "divider" }}>
                <TabList>
                  <Tab>Info</Tab>
                  <Tab>Images</Tab>
                  <Tab>Vendors</Tab>
                  {/* <Tab label="Location" value="4" />
                                    <Tab label="Inward" value="5" />
                                    <Tab label="Outward" value="6" /> */}
                </TabList>
              </Box>
              <TabPanel value={0} sx={{ p: 2 }}>
                <ProductForm
                  data={product}
                  action="update"
                  onSave={refetchProduct}
                />
              </TabPanel>
              <TabPanel value={1} sx={{ p: 2 }}>
                <ProductMedia product={product_id} />
              </TabPanel>
              <TabPanel value={2} sx={{ p: 2 }}>
                <VendorList product={product_id} />
              </TabPanel>
              {/* <TabPanel value="4">
                                <LocationList product={product_id} />
                            </TabPanel>
                            <TabPanel value="5">
                                <InwardList />
                            </TabPanel>
                            <TabPanel value="6">
                                <InwardList />
                            </TabPanel> */}
            </Tabs>
          </Box>
        </Grid>
      </Grid>
    </>
  );
}

export default ProductDetails;
