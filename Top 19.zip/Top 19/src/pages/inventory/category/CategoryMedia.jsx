import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Grid,
  Slide,
  Card,
  CardActionArea,
  CardMedia,
  Paper,
} from "@mui/material";

import { CategoryService } from "src/services/api/CategoryService";
import { productMediaValidationSchema } from "src/utils/validation/productMedia.validation";
import TopToast from "src/components/Toast/TopToast";

import { QueryKeys } from "src/services/queryKey";

import CategoryPngIcon from "src/static/images/category.png";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function CategoryMedia({ category }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(productMediaValidationSchema),
  });

  const [open, setOpen] = useState(false);

  const [image, setImage] = useState(null);
  const [images, setImages] = useState({});
  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const [topToast, setTopToast] = useState({
    alert_props: {
      severity: "success",
    },
    message: "",
    show: false,
  });

  const {
    isLoading: locationLoading,
    data,
    error,
    refetch,
  } = useQuery(
    [QueryKeys.getAllCategoryMedia],
    async () => {
      return await CategoryService.get(category);
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setImages(response.data);
      },
      staleTime: 0,
    }
  );
  const queryClient = useQueryClient();
  const { mutate: saveProductMedia } = useMutation(
    async (data) => {
      if (!image) {
        alert("please select image");
        return;
      }
      if (!image.name.match(/\.(jpg|jpeg|png)$/)) {
        alert(
          "This file does not support. You must use .png or .jpg or .jpeg image"
        );
        return false;
      }
      if (image.size > 1e6) {
        alert("Please upload a image smaller than 1 MB");
        return false;
      }
      const formData = new FormData();
      formData.append("category", category);
      formData.append("image", image);

      const reponse = await CategoryService.CategoryMediaService.create(
        formData,
        data
      );
      return reponse;
    },
    {
      onSuccess: (response) => {
        refetch();
        setImage(null);
        setOpen(false);
        reset();
        setTopToast({
          ...topToast,
          message: `Image ${response?.image?.name} is saved !`,
          show: true,
          alert_props: {
            severity: "success",
          },
        });
        queryClient.invalidateQueries([QueryKeys.getAllProducts]);
      },
      onError: (response) => {
        setTopToast({
          ...topToast,
          message: JSON.stringify(response?.error),
          show: true,
          alert_props: {
            severity: "error",
          },
        });
      },
    }
  );

  function imageUploadHandler(e) {
    setImage(e.target.files[0]);
  }

  // DELETE Product Media
  async function deleteProductMediaHandler(p, index) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Product Media",
      description: `Are you sure want to delete ?`,
      confrimHandler: async function () {
        await CategoryService.CategoryMediaService.remove(p.id).then(
          (response) => {
            if (response.status === 204) {
              images.pop(index);
              refetch();
              setConfirmationParams({ open: false });
              setTopToast({
                ...topToast,
                show: true,
                message: `Image ${image} is Deleted`,
                alert_props: {
                  severity: "warning",
                },
              });
            }
          }
        );
      },
    });
  }

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={12} md={2}>
          <Paper style={{ borderRadius: 15 }} elevation={10}>
            <Card sx={{ maxWidth: 345, width: 300 }}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  height="150"
                  image={images.image ? images.image : CategoryPngIcon}
                  alt="top india elevator pvt ltd"
                  style={{ height: "fit-content" }}
                  // onClick={redirectToDetails}
                />
              </CardActionArea>
            </Card>
          </Paper>
        </Grid>
      </Grid>

{/* Image Upload Button */}

      {/* <Grid
        container
        spacing={2}
        justifyContent={"left"}
        // alignItems={"center"}
      >
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Add New"}
            variant={"success"}
            onClick={() => setOpen(true)}
            fullWidth
          />
        </Grid>
      </Grid> */}


{/* IMAGE MAPPING */}

      {/* <Grid
        container
        marginTop="20px"
        spacing={2}
        sx={{ justifyContent: "center" }}
      >
        {images.map((i, idx) => (
          <Grid item key={idx} xs={12} md={4}>
            <Grid
              item
              style={{
                backgroundImage: `url(${i.image})`,
                backgroundSize: "cover",
                minHeight: "300px",
                maxHeight: "300px",
                display: "flex",
                justifyContent: "flex-end",
                padding: "10px",
                borderRadius: "15px",
                boxShadow: "0px 0px 10px 0.2px black",
              }}
            >
              <div>
                <IconButton
                  color="error"
                  style={{ backgroundColor: "white" }}
                  onClick={() => {
                    deleteProductMediaHandler(i);
                  }}
                >
                  <RemoveCircleIcon />
                </IconButton>
              </div>
            </Grid>
          </Grid>
        ))}
      </Grid> */}

      {/* IMAGE UPLOAD MODEL */}

      {/* <Dialog
        // fullWidth={true}
        maxWidth={"sm"}
        open={open}
        onClose={() => {
          setConfirmationParams({ open: false });
        }}
      >
        <DialogTitle>Category</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} padding={1}>
            <Grid item xs={12} md={12}>
              <Button
                component="label"
                variant="outlined"
                fullWidth
                startIcon={<UploadFileIcon />}
                sx={{ marginRight: "1rem" }}
              >
                Upload Image
                <input
                  type={`file`}
                  accept={`image/*`}
                  hidden
                  // {...register("image")}
                  onChange={(e) => imageUploadHandler(e)}
                  // error={errors.image ? true : false}
                  // helperText={errors.image?.message}
                />
              </Button>
              <Box>{image?.name}</Box>
            </Grid>
          </Grid>
        </DialogContent>

        <DialogActions>
          <TOPButton
            variant={"success"}
            text={"Upload"}
            onClick={saveProductMedia}
          />

          <TOPButton
            onClick={() => setOpen(false)}
            fullWidth
            variant={"danger"}
            text="Cancel"
          />
        </DialogActions>
      </Dialog> */}


      {/* DELETE DIALOG */}

      {/* <Dialog
        open={conformationParams.open}
        onClose={() => {
          setConfirmationParams({ open: false });
        }}
        TransitionComponent={Transition}
        keepMounted
        aria-describedby="category-delete-confirm-dailog"
      >
        <DialogTitle>{"Delete Media"}</DialogTitle>
        <DialogContent>Are you sure want to delete media</DialogContent>
        <DialogActions>
          <TOPButton
            onClick={conformationParams.confrimHandler}
            variant="danger"
            text={"Yes"}
          />
          <TOPButton
            onClick={() => {
              setConfirmationParams({ open: false });
            }}
            variant="info"
            text={"No"}
          />
        </DialogActions>
      </Dialog> */}

      <TopToast
        message={topToast.message}
        alert_props={{
          severity: topToast.alert_props.severity,
        }}
        show={topToast.show}
      />
    </>
  );
}

export default CategoryMedia;
