import { useFormik } from "formik";
import { useState } from "react";
import showToastNotification from "src/components/ToastNotifications/showToastNotification";
import { useAsyncSubmit } from "src/Hooks/useAsyncSubmit";
import { LocationService } from "src/services/api/LocationService";
import * as yup from "yup";



const message = {
    name: "Please Enter Location name",
    phone: "Please Enter Phone number.",

};

const buildValidationSchema = () => {
    return yup.object().shape({
        name: yup
            .string()
            .required(message.name)
            .typeError(message.name)
            .min(5, "Business Location should be at least 5 character long")
            .max(50, "Business Location should not be more than 50 character"),
        //phone: yup.number().required(message.phone).typeError(message.phone)
    });
};

let initialValues = {
    name: "",
    location: "",
    action: "create"
};

export const useCategoryProductListPage = (props) => {
    const { dialogHandler } = props;

    const [formResult, setFormResult] = useState(null);

    const { submit: triggerSubmit, isSubmitting } = useAsyncSubmit({
        queryFn: LocationService.FloorService.create,
    });
    const { submit: triggerSubmitUpdate, isSubmittingUpdate } = useAsyncSubmit({
        queryFn: LocationService.FloorService.update,
    });

    const formik = useFormik({
        initialValues: initialValues,
        validationSchema: buildValidationSchema(),
        validateOnChange: false,
        validateOnBlur: true,
        onSubmit: async (values, { resetForm }) => {
            console.warn(values);
            let result;
            switch (values.action) {
                case "create":
                    result = await triggerSubmit({
                        name: values.name,
                        business_location: values.location,
                      });
                    break;
                case "update":
                    result = await triggerSubmitUpdate(values.id,
                        { name: values.name, business_location: values.location });
                    break;
                default:
                    throw new Error();
            }
            setFormResult(result);

            let message = "";
            let variant = "error";

            if (result.apiData?.status === 201 || result.apiData?.status === 200) {
                variant = "success";
                message = `Congratulations !! ${values.name} your innquiry submited successfully. \n We will contact you soon !`;
                resetForm();
            } else {
                message = `Unexpect error occured ! Please Try again after some time. \n Sorry for inconvenience !`;
            }
            showToastNotification(message, { variant: variant });
            dialogHandler();
            resetForm();
        },
    });

    return {
        formik,
        formResult,
        isSubmitting,
        isSubmittingUpdate,
        errors: formik.errors,
        values: formik.values,
        setValues: formik.setValues,
        setFieldValue: formik.setFieldValue,
        handleChange: formik.handleChange,
        handleSubmit: formik.handleSubmit,
        isValid: formik.isValid,
    };
};
