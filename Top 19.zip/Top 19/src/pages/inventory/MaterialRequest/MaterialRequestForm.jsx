import { Alert, Button, Card, Chip, Typography } from "@mui/joy";
import { EditText } from "src/components/EditText";
import { Box, Grid, Stack } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { useRef } from "react";
import { useParams } from "react-router-dom";
import { Model } from "src/components";
import { LocationDropdown } from "src/components/Dropdown/LocationDropdown";
import { ProductDropdown } from "src/components/Dropdown/ProductDropdown";
import { PageLoader } from "src/components/PageLoader/PageLoader";
import { useProductData } from "src/Hooks/useProductData";
import { MaterialRequestService } from "src/services/api/MaterialRequestService";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import {
  useMaterialRequest,
  useMaterialRequestEntries,
} from "./useMaterialRequest";
import SaveButton from "src/components/Button/SaveButton";
import MainButton from "src/components/Button/MainButton";
import CancelButton from "src/components/Button/CancelButton";

export default function MaterialRequestForm() {
  let dataObj = null;

  let materialEntiresDialogRef = useRef(null);

  const products = useProductData();

  /* load and process data from database on the same page if it's load with purchase order id */
  const { material_request_id } = useParams();

  const { isLoading, refetch } = useQuery(
    ["getMaterialRequest"],
    async () => {
      if (material_request_id) {
        return await MaterialRequestService.get(material_request_id);
      }
      return null;
    },
    {
      staleTime: 0,
      onSuccess: (response) => {
        if (response) {
          dataObj = {
            ...response.data,
            branch: response.data.branch.id,
            entries: [],
          };
          for (const entry of response.data.entries) {
            dataObj.entries.push({
              ...entry,
              product: entry.product.id,
            });
          }
          setValues({
            ...dataObj,
            action: "update",
          });
        }
      },
    }
  );

  const onSuccessSave = (id) => {
    refetch();
  };

  const { formik, onSave } = useMaterialRequest({
    onSuccess: onSuccessSave,
    dataObj: dataObj,
  });
  const { values, errors, setValues } = formik;

  const { formikForEntires, onEntrySave } = useMaterialRequestEntries({
    onSuccess: () => {
      // pushing entry values to main form after success
      // note: does not require any api call for the same

      // find the object if it's already exists in main array then just update values
      // rather then pusing it
      const findIndex = values.entries.findIndex(
        (entry) => entry.product === formikForEntires.values.product
      );

      if (findIndex !== -1) {
        // if index -1 means entry available then just update it
        values.entries[findIndex] = formikForEntires.values;
      } else {
        // otherwise push the new object
        values.entries.push(formikForEntires.values);
      }
      // once entry added just reset the form, so user can put new values on the same
      formikForEntires.resetForm();
      materialEntiresDialogRef.current?.close();
    },
    dataObj: null,
  });

  const inputHandler = (e) => {
    const { name, value } = e.target;

    setValues({
      ...values,
      [name]: value,
    });
  };

  //handling material Entries values
  const inputHandlerEntries = (e) => {
    const { name, value } = e.target;
    formikForEntires.setValues({
      ...formikForEntires.values,
      [name]: value,
    });
  };

  const removeEntry = (index) => {
    values.entries.splice(index, 1);
    setValues({ ...values });
  };

  const getProductName = (product) => {
    const found = products.find((p) => p.id === product);
    if (found) {
      return found["name"];
    }
    return "";
  };

  if (isLoading) {
    return <PageLoader pageMessage={"Loading Material Request Data..."} />;
  }

  return (
    <>
      <Box margin={2}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={12}>
            <Stack
              direction={"row"}
              justifyContent={"space-between"}
              alignItems={"center"}
            >
              <Typography level={"h4"}>
                Material Request {values?.mr_number && values?.mr_number}
              </Typography>
              <SaveButton onClick={onSave} />
            </Stack>
          </Grid>
          <Grid item xs={12} md={3}>
            <LocationDropdown
              props={{
                name: "branch",
                placeholder: "Select Branch",
                size: "md",
                value: values.branch,
                onChange: (e) => inputHandler(e),
                error: errors.branch,
              }}
              label={"Send Material Request To"}
              helperText={errors.branch}
            />
          </Grid>
          <Grid item xs={12} md={3}>
            <EditText
              name="contact_person"
              placeholder="Contact Person"
              onChange={(e) => inputHandler(e)}
              value={values.contact_person}
              error={errors.contact_person ? true : false}
              helpertext={errors.contact_person}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              name="contact_person"
              label="Contact Person"
              variant="outlined"
              value={values.contact_person}
              onChange={(e) => inputHandler(e)}
              error={errors.contact_person ? true : false}
              helperText={errors.contact_person}
            /> */}
          </Grid>
          <Grid item xs={12} md={3}>
            <EditText
              name="mobile_no"
              placeholder="Mobile No."
              onChange={(e) => inputHandler(e)}
              value={values.mobile_no}
              error={errors.mobile_no ? true : false}
              helpertext={errors.mobile_no}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              name="mobile_no"
              label="Mobile No."
              type={"number"}
              variant="outlined"
              value={values.mobile_no}
              onChange={(e) => inputHandler(e)}
              error={errors.mobile_no ? true : false}
              helperText={errors.mobile_no}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="email"
              placeholder="Email"
              onChange={(e) => inputHandler(e)}
              value={values.email}
              error={errors.email ? true : false}
              helpertext={errors.email}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Email"
              name="email"
              type={"email"}
              variant="outlined"
              value={values.email}
              onChange={(e) => inputHandler(e)}
              error={errors.email ? true : false}
              helperText={errors.email}
            /> */}
          </Grid>
          <Grid item md={12} xs={12}>
            <Stack
              spacing={2}
              alignItems={"center"}
              direction={"row"}
              justifyContent={"space-between"}
            >
              {errors.entries && (
                <Alert
                  variant="outlined"
                  color={"danger"}
                  style={{ width: "80%" }}
                >
                  {errors.entries}
                </Alert>
              )}
              <MainButton
                name={"Add Products"}
                onClick={() => {
                  materialEntiresDialogRef.current?.open();
                }}
              />
            </Stack>
          </Grid>
          {values.entries.map((entry, index) => {
            return (
              <Grid item md={3} xs={12} key={index}>
                <Card
                  variant="outlined"
                  row
                  sx={{
                    "&:hover": {
                      boxShadow: "md",
                      borderColor: "neutral.outlinedHoverBorder",
                      cursor: "pointer",
                    },
                  }}
                >
                  <Stack sx={{ witdh: "100%" }}>
                    <Stack
                      direction={"row"}
                      alignItems={"center"}
                      justifyContent={"space-between"}
                      mb={2}
                    >
                      <Typography level="h2" fontSize="lg" mb={0.5}>
                        {getProductName(entry?.product)}
                      </Typography>
                      <Stack direction={"row"} spacing={1}>
                        <Button
                          aria-label="remove"
                          variant="soft"
                          color="info"
                          size="sm"
                          onClick={() => {
                            materialEntiresDialogRef.current?.open();
                            formikForEntires.setValues({ ...entry });
                          }}
                        >
                          <EditIcon />
                        </Button>
                        <Button
                          aria-label="remove"
                          variant="soft"
                          color="danger"
                          size="sm"
                          onClick={() => {
                            removeEntry(index);
                          }}
                        >
                          <DeleteIcon />
                        </Button>
                      </Stack>
                    </Stack>
                    <div
                      style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}
                    >
                      <Chip
                        variant="outlined"
                        color="primary"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Ordered Quantity {entry?.ordered_qty}
                      </Chip>
                      <Chip
                        variant="outlined"
                        color="info"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Basic Rate {entry?.basic_rate}
                      </Chip>
                      <Chip
                        variant="outlined"
                        color="info"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Discount {entry?.discount}
                      </Chip>
                      <Chip
                        variant="outlined"
                        color="success"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Amount {entry?.amount}
                      </Chip>
                      {entry?.extra_details && (
                        <Chip
                          variant="outlined"
                          color="warning"
                          size="sm"
                          sx={{ pointerEvents: "none" }}
                        >
                          Remarks: {entry?.extra_details}
                        </Chip>
                      )}
                    </div>
                  </Stack>
                </Card>
              </Grid>
            );
          })}
        </Grid>
        <Model
          fullWidth
          maxWidth={"lg"}
          ref={materialEntiresDialogRef}
          onClose={() => {
            materialEntiresDialogRef.current?.close();
            formikForEntires.resetForm();
          }}
          title={"Material Request Product Record"}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <ProductDropdown
                props={{
                  name: "product",
                  placeholder: "Select Product",
                  value: formikForEntires.values.product,
                  onChange: (e) => {
                    inputHandlerEntries(e);
                  },
                  error: formikForEntires.errors.product,
                }}
                label={"Select Product Item To Add Material Request"}
                helperText={formikForEntires.errors.product}
              />
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="ordered_qty"
                placeholder="Order Quantiry"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.ordered_qty}
                error={formikForEntires.errors.ordered_qty ? true : false}
                helperText={formikForEntires.errors.ordered_qty}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="ordered_qty"
                label="Order Quantiry"
                variant="outlined"
                value={formikForEntires.values.ordered_qty}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.ordered_qty ? true : false}
                helperText={formikForEntires.errors.ordered_qty}
              /> */}
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="basic_rate"
                placeholder="Basic Rate"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.basic_rate}
                error={formikForEntires.errors.basic_rate ? true : false}
                helperText={formikForEntires.errors.basic_rate}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="basic_rate"
                label="Basic Rate"
                variant="outlined"
                value={formikForEntires.values.basic_rate}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.basic_rate ? true : false}
                helperText={formikForEntires.errors.basic_rate}
              /> */}
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="discount"
                placeholder="Discount"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.discount}
                error={formikForEntires.errors.discount ? true : false}
                helperText={formikForEntires.errors.discount}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="discount"
                label="Discount"
                variant="outlined"
                value={formikForEntires.values.discount}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.discount ? true : false}
                helperText={formikForEntires.errors.discount}
              /> */}
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="amount"
                placeholder="Amount"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.amount}
                error={formikForEntires.errors.amount ? true : false}
                helperText={formikForEntires.errors.amount}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="amount"
                label="Amount"
                variant="outlined"
                value={formikForEntires.values.amount}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.amount ? true : false}
                helperText={formikForEntires.errors.amount}
              /> */}
            </Grid>
            <Grid item xs={12} md={12}>
              <EditText
                name="extra_details"
                placeholder="Remarks"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.extra_details}
                error={formikForEntires.errors.extra_details ? true : false}
                helperText={formikForEntires.errors.extra_details}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="extra_details"
                label="Remarks"
                variant="outlined"
                value={formikForEntires.values.extra_details}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.extra_details ? true : false}
                helperText={formikForEntires.errors.extra_details}
              /> */}
            </Grid>
            <Grid item xs={12} md={12}>
              <Stack spacing={2} direction={"row"} justifyContent={"flex-end"}>
                <CancelButton
                  onClick={() => {
                    materialEntiresDialogRef.current?.close();
                    formikForEntires.resetForm();
                  }}
                />
                <SaveButton
                  onClick={onEntrySave}
                  disabled={formikForEntires.values.ordered_qty < 1}
                />
              </Stack>
            </Grid>
          </Grid>
        </Model>
      </Box>
    </>
  );
}
