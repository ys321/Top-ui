import { createAsyncThunk } from "@reduxjs/toolkit";
import { useFormik } from "formik";
import moment from "moment";
import { useDispatch } from "react-redux";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { errorAlert, successAlert, warningAlert } from "src/store/slices/alert.slice";
import { toggleProcess } from "src/store/slices/process.slice";
import * as yup from "yup";


const errorMessage = {
    branch: 'Please Select Valid Location',
    vendor: 'Please Select Valid Vendor',
    reason: 'Please Provide Valid Reason',
    remarks: 'Please Provide Valid Remarks',

    entry_error: 'One or more products are required for sending Outward to Vendor',

    // entries Message
    product: 'Product Not Added',
    send_qty: 'Please provide valid ordered quantity',
    uom: 'Please select UOM.'
}

const outwardFromVendorEntriesValidationSchema = yup.object().shape({
    product: yup.number().required(errorMessage.product).typeError(errorMessage.product),
    send_qty: yup.number().integer().required(errorMessage.send_qty).typeError(errorMessage.send_qty),
    uom: yup.number().required(errorMessage.uom).min(0).typeError(errorMessage.uom),
})

export const outwardFromVendorValidationSchema = yup.object().shape({
    branch: yup.number().required(errorMessage.branch).min(0).typeError(errorMessage.branch),
    vendor: yup.number().required(errorMessage.vendor).min(0).typeError(errorMessage.vendor),
    entries: yup.array(yup.object({
        send_qty: yup.number().integer().required(errorMessage.send_qty).typeError(errorMessage.send_qty).min(1, 'You Have to set More Then 0 Quantity'),
        remarks: yup.string().required(errorMessage.remarks).typeError(errorMessage.remarks),
    })),
})

const entriesInitalValues = {
    product: '',
    ordered_qty: '',
    uom: '',
    reason: '',
    remarks: '',
}

const outwardInitValues = {
    outward_date: moment().tz(moment.tz.guess()).format("YYYY-MM-DD"),
    vendor: '',
    reason: '',
    entries: [],
    action: 'save'
}


export const createOutwardFromVendor = createAsyncThunk(
    "@outwardFromVendor/create",
    (info, thunk) => {
        const { dispatch } = thunk;
        const { callback, ...params } = info;

        dispatch(
            toggleProcess({
                visible: true,
                open: true,
                loading: true,
            })
        );
        (async () => {
            const res = await InwardOutwardService.OutwardVendor.create(params.values);
            return res;
        })()
            .then((res) => {
                dispatch(
                    successAlert({
                        visible: true,
                        title: "Outward From Vendor",
                        message: "Outward From Vendor Create Successfully",
                    })
                )
            })
            .catch((e) => {
                dispatch(
                    warningAlert({
                        visible: true,
                        title: "Outward From Vendor Create Failed",
                        message: e.error.response.data.details,
                    })
                )
            })
    }
)

export const updateOutwardFromVendor = createAsyncThunk(
    "@updateOutwardFromVendor/update",
    (info, thunk) => {
        const { dispatch } = thunk;
        const { callback, ...params } = info;

        dispatch(
            toggleProcess({
                visible: true,
                open: true,
                loading: true,
            })
        );
        (async () => {
            const res = await InwardOutwardService.OutwardVendor.update(params.outward_vendor_id, params.values);
            return res;
        })()
            .then((res) => {
                dispatch(
                    successAlert({
                        visible: true,
                        title: "Outward From Vendor",
                        message: "Outward From Vendor Update Successfully",
                    })
                )
            })
            .catch((e) => {
                dispatch(
                    warningAlert({
                        visible: true,
                        title: "Outward From Vendor Update Failed",
                        message: e.error.response.data.details,
                    })
                )
            })
    }
)


export const deleteOutwardFromVendor = createAsyncThunk(
    "@outwardFromVendor/delete",
    (info, thunk) => {
        const { dispatch } = thunk;
        const { callback, ...params } = info;

        dispatch(
            toggleProcess({
                visible: true,
                open: true,
                loading: true,
            })
        );
        (async () => {
            await InwardOutwardService.OutwardVendor.delete(params.currentRow.id);
        })().then((res) => {
            dispatch(
                warningAlert({
                    visible: true,
                    title: "Outward From Vendor",
                    message: "Outward From Vendor Delete Successfully !",
                })
            );
        }).catch((e) => {
            dispatch(
                errorAlert({
                    visible: true,
                    title: "Outward From Vendor Delete Failed",
                    message: "Outward From Vendor Delete Failed",
                })
            );
        })
    }
)


const saveOutwardVendor = createAsyncThunk(
    "outwardFromVendor/save",
    (info, thunk) => {
        const { dispatch } = thunk;
        const { callback, ...params } = info;

        dispatch(
            toggleProcess({
                visible: true,
                open: true,
                loading: true
            })
        );
        const { action } = params;
        delete params['action'];
        if (action === 'save') {
            InwardOutwardService.OutwardSite.create(params)
                .then((res) => {
                    dispatch(
                        toggleProcess({
                            visible: false,
                            open: false,
                            loading: false
                        })
                    );
                    dispatch(
                        successAlert({
                            visible: true,
                            title: "Outward from Vendor",
                            message: "Outward from Vendor has been Saved !",
                        })
                    );

                    callback?.();
                })
                .catch(() => {
                    dispatch(
                        errorAlert({
                            visible: true,
                            title: "New Outward from Vendor",
                            message: "Failed to save Outward from Vendor :(",
                        })
                    );
                })

                .finally(() => {
                    dispatch(
                        toggleProcess({
                            visible: false,
                            open: false,
                            loading: false,
                        })
                    );
                });
        }
    }
)

export const useOutwardVendor = (props) => {
    const { onSuccess, dataObj } = props;
    const dispatch = useDispatch();

    let finalInitValues = outwardInitValues;
    if (dataObj) {
        finalInitValues = dataObj;
    }
    const formik = useFormik({
        initialValues: finalInitValues,
        enableReinitialize: true,
        validationSchema: outwardFromVendorValidationSchema,
        validateOnChange: true,
        onSubmit: (values, { resetForm }) => {
            const callback = () => {
                onSuccess?.();
            };
            const params = { ...values, callback };
            dispatch(saveOutwardVendor(params));
            console.log(params);
        },
    });
    return {
        formik,
        onSave: formik.handleSubmit
    }
};

export const useOutwardVendorEntries = (props) => {
    const { onSuccess, dataObj } = props;

    let finalInitValues = entriesInitalValues;

    if (dataObj) {
        finalInitValues = dataObj;
    }
    const formikForEntires = useFormik({
        initialValues: finalInitValues,
        enableReinitialize: true,
        validationSchema: outwardFromVendorEntriesValidationSchema,
        validateOnChange: true,
        onSubmit: (values, { resetForm }) => {
            const callback = () => {
                onSuccess?.();
            };
            callback();
            console.log(values);
        },
    });
    return {
        formikForEntires,
        onEntrySave: formikForEntires.handleSubmit
    }
}