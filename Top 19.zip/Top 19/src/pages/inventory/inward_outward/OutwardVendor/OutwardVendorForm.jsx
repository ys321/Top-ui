import { Box, Grid, Stack } from "@mui/material";
import {
  Typography,
  TextField,
  Chip,
  ChipDelete,
} from "@mui/joy";
import { EditText } from "src/components/EditText";
import { ErrorMessage, FieldArray, Form, Formik, getIn } from "formik";
import moment from "moment";
import { createOutwardFromVendor, outwardFromVendorValidationSchema, updateOutwardFromVendor } from "./useOutwardVendor";
import { VendorDropdown } from "src/components/Dropdown/VendorDropdown";
import { useRef, useState } from "react";
import { AddButton, BaseCard, Dialog } from "src/components";
import { ProductDropdown } from "src/components/Dropdown/ProductDropdown";
import { LocationDropdown } from "src/components/Dropdown/LocationDropdown";
import OutwardVendorLocation from "./OutwardVendorLocation";
import { useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import SaveButton from "src/components/Button/SaveButton";
import MainButton from "src/components/Button/MainButton";

function OutwardVendorForm() {
  let productLocationDialogRef = useRef(null);

  const formRef = useRef();

  const [currentEntry, setCurrentEntry] = useState();
  const [outwardVendorAction, setOutwardVendorAction] = useState("CREATE");
  const dispatch = useDispatch();

  // load and proccess data from database on the basis of inward_vendor_id
  const { outward_vendor_id } = useParams();

  const { isLoading: outwardFromVendorLoading, refetch: outwardFromVendorRefetch } = useQuery(['getOutwardFromVendor'], async () => {
    if (outward_vendor_id) {
      return await InwardOutwardService.OutwardVendor.get(outward_vendor_id);
    } else return null;
  }, {
    staleTime: 0,
    onSuccess: (response) => {
      if (response) {
        console.log(response.data);
        formRef.current.values.entries.length = 0;
        formRef.current.values.branch = '';

        // assign data to formik
        formRef?.current?.setValues({
          ...formRef?.current?.values
        });

        // assing Data based on request
        formRef.current.values.date = response.data.date;
        if (response.data.branch) {
          formRef.current.values.branch = response.data.branch.id;
        }
        if (response.data.vendor) {
          formRef.current.values.vendor = response.data.vendor.id;
        }
        formRef.current.values.remarks = response.data.remarks;

        for (const entry of response.data?.entries) {
          let temp = [];
          entry?.inventory_location.forEach(loc => {
            temp.push({
              alias: loc?.alias,
              branch: loc?.branch?.id,
              floor: loc?.floor.id,
              section: loc?.section?.id,
              rack: loc?.rack?.id,
              shelf: loc?.shelf?.id,
              bin: loc?.bin?.id,
              qty: loc?.qty,
            })
          })
          formRef?.current?.values?.entries?.push({
            product: entry?.product?.id,
            branch: response.data?.branch?.id,
            send_qty: entry?.send_qty,
            reason: entry?.reason,
            remarks: entry?.remarks,
            inventory_location: temp
          })
        }

        formRef?.current?.setValues({
          ...formRef?.current?.values
        })
        setOutwardVendorAction("UPDATE")
      }
    }
  })

  const addProductLocation = ({ index, entry }) => {
    productLocationDialogRef.current?.open();
    setCurrentEntry({
      index: index,
      entry: entry,
    });
  };

  function saveLocation(obj) {
    const indexOf = formRef.current.values.entries[
      currentEntry.index
    ]?.inventory_location?.findIndex((l) => l?.alias === obj?.alias);

    if (indexOf === -1) {
      formRef.current.values.entries[
        currentEntry.index
      ].inventory_location.push(obj);
    } else {
      formRef.current.values.entries[currentEntry.index].inventory_location[
        indexOf
      ] = obj;
    }

    console.log(formRef.current.values.entries);
    productLocationDialogRef.current?.close();

    formRef.current.setValues({ ...formRef.current.values });
  }

  const calculateAvailableProductToDistribute = () => {
    const send_qty =
      formRef.current.values.entries[currentEntry.index].send_qty;
    let remaningQuantity = send_qty;
    for (const location of formRef.current.values.entries[currentEntry.index]
      .inventory_location) {
      // todo : diduct values for each qty
      remaningQuantity -= location.qty;
    }
    return remaningQuantity;
  };

  function saveOutwardFromVendor(values) {
    switch (outwardVendorAction) {
      case "CREATE":
        dispatch(createOutwardFromVendor({ values }))
          .unwrap()
          .then((res) => {
            console.log("data Submitted");
          }).catch((e) => {
            console.log(e);
          })
        break;
      case "UPDATE":
        dispatch(updateOutwardFromVendor({ values, outward_vendor_id }))
          .unwrap()
          .then((res) => {
            console.log("data Updated");
          })
          .catch((e) => {
            console.log(e);
          })
        break
      default:
        break;
    }
  }

  return (
    <>
      <Box margin={2}>
        <Formik
          initialValues={{
            date: moment().utc().tz(moment.tz.guess()).format("YYYY-MM-DD"),
            branch: "",
            vendor: "",
            reason: "",
            entries: [],
          }}
          innerRef={formRef}
          onSubmit={async (values) => {
            saveOutwardFromVendor(values);
            console.log(values);
          }}
          validationSchema={outwardFromVendorValidationSchema}
        >
          {({ values, errors, handleChange, setValues, touched }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Typography level={"h4"}>Outward form Vendor</Typography>
                    <SaveButton />
                  </Stack>
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="date"
                    placeholder="Outward Date"
                    onChange={handleChange}
                    value={values.date}
                  />
                  {/* <TextField
                    type="date"
                    margin="dense"
                    fullWidth
                    name="date"
                    label="Outward Date"
                    variant="outlined"
                    value={values.date}
                    onChange={handleChange}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <LocationDropdown
                    props={{
                      name: "branch",
                      placeholder: "Select Branch",
                      size: "md",
                      onChange: (e) => handleChange(e),
                      value: values.branch,
                      error: errors.branch,
                    }}
                    label={"Select Branch"}
                    helperText={errors.branch}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <VendorDropdown
                    props={{
                      name: "vendor",
                      placeholder: "Select Vendor",
                      size: "md",
                      onChange: (e) => handleChange(e),
                      value: values.vendor,
                      error: errors.vendor,
                    }}
                    label={"Select Vendor"}
                    helperText={errors.vendor}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="reason"
                    placeholder="Reason"
                    onChange={handleChange}
                    value={values.reason}
                  />
                  {/* <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="reason"
                    label="Reason"
                    variant="outlined"
                    value={values.reason}
                    onChange={handleChange}
                  /> */}
                </Grid>
              </Grid>
              <Grid container spacing={1} padding={1}>
                <Grid item md={12} xs={12}>
                  <Stack
                    spacing={2}
                    alignItems={"center"}
                    direction={"row"}
                    justifyContent={"space-between"}
                  >
                    {/* {errors.entries && ( */}
                    {/* <Alert
                      variant="outlined"
                      color={"danger"}
                      style={{ width: "80%" }}
                    >
                      {errors.entry_error}
                    </Alert> */}
                    {/* )} */}
                  </Stack>
                </Grid>
                <FieldArray name="entries">
                  {({ insert, remove, push }) => (
                    <>
                      <>
                        <Grid item xs={12} md={12} marginTop={1}>
                          <Stack
                            spacing={2}
                            direction={"row"}
                            justifyContent={"end"}
                          >
                            <MainButton
                              name={"Add Products"}
                              onClick={() => {
                                push({
                                  id: Math.random(),
                                  product: "",
                                  send_qty: "",
                                  specification: true,
                                  amount: null,
                                  order_qty: null,
                                  rate_per_qty: null,
                                  received_qty: null,
                                  branch: values?.branch,
                                  reason: "",
                                  remarks: "",
                                  inventory_location: [],
                                })
                              }
                              }
                              disabled={!values.branch}
                            />

                          </Stack>
                        </Grid>
                      </>
                      {values.entries.length > 0 &&
                        values.entries.map((entry, index) => {
                          const product = `entries[${index}].product`;
                          const send_qty = `entries[${index}].send_qty`;
                          const reason = `entries[${index}].reason`;
                          const remarks = `entries[${index}].remarks`;
                          return (
                            <Grid item md={3} xs={12} key={index}>
                              <BaseCard variant="outlined" row>
                                <Stack
                                  sx={{ width: "100%" }}
                                  direction={"column"}
                                >
                                  <Stack
                                    direction={"row"}
                                    alignItems={"center"}
                                    justifyContent={"space-between"}
                                    flexWrap={"wrap"}
                                    mb={2}
                                  >
                                    <Stack direction={"row"} spacing={1}>
                                      <AddButton
                                        variant="soft"
                                        size="sm"
                                        onClick={() => {
                                          addProductLocation({
                                            index: index,
                                            entry: entry,
                                          });
                                        }}
                                        disabled={
                                          // ordered_qty < 1 means we can not disribute
                                          values.entries[index]?.send_qty < 1
                                        }
                                      >
                                        distribute
                                      </AddButton>
                                    </Stack>
                                    <Stack direction={"row"} spacing={1}>
                                      <ChipDelete
                                        sx={{
                                          textAlign: "end",
                                        }}
                                        color="danger"
                                        variant="solid"
                                        onClick={() => {
                                          remove(index);
                                        }}
                                      />
                                    </Stack>
                                  </Stack>

                                  <ProductDropdown
                                    props={{
                                      name: product,
                                      placeholder: "Select Product",
                                      onChange: (e) => handleChange(e),
                                      value: entry.product || '',
                                      variant: "soft",
                                      size: "sm",
                                    }}
                                    label={
                                      "Select Product Item To Add Outward from Vendor"
                                    }
                                  />
                                  {/* <TextField
                                    margin="dense"
                                    fullWidth
                                    name={send_qty}
                                    label="Send Quantity"
                                    variant="soft"
                                    size="sm"
                                    value={entry.send_qty || ''}
                                    onChange={(e) => handleChange(e)}
                                    error={
                                      getIn(
                                        errors,
                                        `entries[${index}].send_qty`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries[${index}].send_qty`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries[${index}].send_qty`}
                                      />
                                    }
                                  /> */}

                                  <EditText
                                    name={send_qty}
                                    placeholder="Send Quantity"
                                    value={entry.send_qty || ''}
                                    onChange={(e) => handleChange(e)}
                                    error={
                                      getIn(
                                        errors,
                                        `entries[${index}].send_qty`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries[${index}].send_qty`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries[${index}].send_qty`}
                                      />
                                    }
                                  />


                                  {/* <TextField
                                    margin="dense"
                                    fullWidth
                                    name={reason}
                                    label="Reason"
                                    variant="soft"
                                    size="sm"
                                    value={entry.reason || ''}
                                    onChange={(e) => handleChange(e)}
                                  /> */}
                                  <EditText
                                    name={reason}
                                    placeholder="Reason"
                                    value={entry.reason || ''}
                                    onChange={(e) => handleChange(e)}
                                  />
                                  {/* <TextField
                                    margin="dense"
                                    fullWidth
                                    name={remarks}
                                    label="Remarks"
                                    variant="soft"
                                    size="sm"
                                    value={entry.remarks || ''}
                                    onChange={(e) => handleChange(e)}
                                    error={
                                      getIn(
                                        errors,
                                        `entries[${index}].remarks`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries[${index}].remarks`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries[${index}].remarks`}
                                      />
                                    }
                                  /> */}

                                  <EditText
                                    name={remarks}
                                    placeholder="Remarks"
                                    value={entry.remarks || ''}
                                    onChange={(e) => handleChange(e)}
                                    error={
                                      getIn(
                                        errors,
                                        `entries[${index}].remarks`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries[${index}].remarks`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries[${index}].remarks`}
                                      />
                                    }
                                  />
                                  <Stack
                                    spacing={1}
                                    direction={"column"}
                                    flexWrap
                                  >
                                    <>
                                      {entry?.inventory_location?.map(
                                        (location, idx) => {
                                          return (
                                            <Chip
                                              variant="outlined"
                                              color="success"
                                              key={idx}
                                              onClick={() => {
                                                console.log(
                                                  entry?.inventory_location
                                                );
                                              }}
                                              endDecorator={
                                                <ChipDelete
                                                  color="danger"
                                                  variant="solid"
                                                  onClick={() => {
                                                    values.entries[
                                                      index
                                                    ].inventory_location.splice(
                                                      idx,
                                                      1
                                                    );
                                                    setValues({ ...values });
                                                  }}
                                                />
                                              }
                                            >
                                              {location?.alias}
                                              <Typography
                                                variant="plain"
                                                color="primary"
                                                fontWeight={800}
                                                sx={{
                                                  marginLeft: 1,
                                                  padding: 0,
                                                }}
                                              >
                                                Qty : {location?.qty}
                                              </Typography>
                                            </Chip>
                                          );
                                        }
                                      )}
                                    </>
                                  </Stack>
                                </Stack>
                              </BaseCard>
                            </Grid>
                          );
                        })}
                    </>
                  )}
                </FieldArray>
                <>
                  <Dialog
                    ref={productLocationDialogRef}
                    title={"Distribute Your Product"}
                  >
                    <OutwardVendorLocation
                      defaultValue={formRef.current?.values.branch}
                      onSave={saveLocation}
                      handleChange={handleChange}
                      availableProductToDistribute={
                        calculateAvailableProductToDistribute
                      }
                    />
                  </Dialog>
                </>
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>
    </>
  );
}
export default OutwardVendorForm;
