import {
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Link,
  Paper,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

import {
  StyledTableCell,
  StyledTableRow,
  Transition,
} from "src/components/Table/TableStyle";

import NoRecordFound from "src/components/Table/NoRecordFound";
import { useQuery } from "@tanstack/react-query";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import DeleteIcon from "@mui/icons-material/Delete";
import TOPButton from "src/components/Button/TopButton";
import { useDispatch } from "react-redux";
import { deleteInwardFromVendor } from "./useInwardVendor";
import { useEffect } from "react";
import MainButton from "src/components/Button/MainButton";

export default function InwardListVendorPage() {
  const navigate = useNavigate();
  const [inwardVendor, setInwardVendor] = useState([]);
  const [currentRow, setCurrentRow] = useState();
  const [open, setOpen] = useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  console.log(inwardVendor);

  const { isLoading: InwardVendorLoading, refetch: inwardVendorRefetch } =
    useQuery(
      ["getAllInwardVendor"],
      async () => {
        return await InwardOutwardService.InwardVendor.getAll();
      },
      {
        onSuccess: (response) => {
          console.table(response.data);
          setInwardVendor(response.data);
        },
        staleTime: 0,
      }
    );

  useEffect(() => {}, [inwardVendor]);

  const dispatch = useDispatch();
  function deleteRow() {
    dispatch(deleteInwardFromVendor({ currentRow }))
      .unwrap()
      .then((res) => {
        handleClose();
        setTimeout(() => {
          inwardVendorRefetch();
        }, 500);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  if (InwardVendorLoading) {
    return <>Loading...</>;
  }

  function addInwardFromVendor() {
    navigate(`/inventory/inward-vendor/form`);
  }

  return (
    <>
      <Grid container spacing={1} padding={2}>
        <Grid item xs={12} md={12}>
          <MainButton name={"ADD NEW"} onClick={addInwardFromVendor} />
        </Grid>

        <Grid item xs={12} md={12}>
          {inwardVendor && inwardVendor?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align="center">ID</StyledTableCell>
                      <StyledTableCell align="center">Branch</StyledTableCell>
                      <StyledTableCell align="center">Vendor</StyledTableCell>
                      <StyledTableCell align="center">
                        Purchase Order
                      </StyledTableCell>
                      <StyledTableCell align="center">LR No</StyledTableCell>
                      <StyledTableCell align="center">
                        Supplier Bill No
                      </StyledTableCell>
                      <StyledTableCell align="center">
                        Transport
                      </StyledTableCell>
                      <StyledTableCell align="center">Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {inwardVendor?.map((inward, index) => {
                      return (
                        <StyledTableRow key={index}>
                          <StyledTableCell align="center">
                            <Link
                              href={`/inventory/inward-vendor/:inward_vendor_id`.replace(
                                ":inward_vendor_id",
                                inward.id
                              )}
                            >
                              {inward.id}
                            </Link>
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {inward?.branch?.name}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {inward?.vendor?.name}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {inward?.purchase_order}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {inward?.lr_number}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {inward?.supplier_bill_no}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {inward?.transport}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            <IconButton
                              aria-label="delete"
                              size="large"
                              color="error"
                              onClick={() => {
                                handleClickOpen();
                                setCurrentRow(inward);
                              }}
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        aria-describedby="inward-vendor-delete-confirm-dailog"
      >
        <DialogTitle>{"Delete Inward From Vendor"}</DialogTitle>
        <DialogContent>
          Are you sure want to delete Inward From Vendor <br />{" "}
          <Chip label={currentRow?.id} />
        </DialogContent>
        <DialogActions>
          <TOPButton onClick={deleteRow} variant="danger" text={"Yes"} />
          <TOPButton onClick={handleClose} variant="info" text={"no"} />
        </DialogActions>
      </Dialog>
    </>
  );
}
