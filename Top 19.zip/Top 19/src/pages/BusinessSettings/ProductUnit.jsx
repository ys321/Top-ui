import {
  Divider, 
  Grid,
  Breadcrumbs,
  Link,
  Stack,
  Tooltip,
  Box,
  Typography,
} from "@mui/joy";
import React, { useState } from "react";

import { useQuery } from "@tanstack/react-query";
import WeightUnitService from "src/services/api/WeightUnitService";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import LinearProgress from "@mui/material/LinearProgress";
import { QueryKeys } from "src/services/queryKey";
import { Slide } from "@material-ui/core";
import { useDispatch } from "react-redux";
import {
  createProductUnit,
  deleteProductUnit,
  updateProductUnit,
} from "src/store/slices/BusinessSettings/productUnit.slice";
import DeleteModel from "src/components/Model/DeleteModel";
import BusinessSettingsModel from "./model/BusinessSettingModel";
import GlobalCard from "./card/BaseCard";
import NoRecordFound from "src/components/Table/NoRecordFound";
import MainButton from "src/components/Button/MainButton";

const productUnitValidationSchema = yup.object().shape({
  name: yup.string().required("Product Unit is Required"),
});

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function ProductUnit() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(productUnitValidationSchema),
  });

  const dispatch = useDispatch();

  const [productUnitDialog, setProductUnitDialog] = useState(false);
  const [productUnits, setProductUnits] = useState([]);
  const [productUnit, setProductUnit] = useState({});
  const [productUnitAction, setProductUnitAction] = useState("CREATE");

  const [conformationParams, setConfirmationParams] = useState({ open: false });
  const [open, setOpen] = useState(false);

  const { isLoading: productUnitLoading, refetch: productUnitRefetch } =
    useQuery(
      [QueryKeys.getAllProductUnits],
      async () => {
        return await WeightUnitService.getAll();
      },
      {
        onSuccess: (response) => {
          setProductUnits(response.data);
        },
        staleTime: 0,
      }
    );

  function saveProductUnit() {
    // eslint-disable-next-line default-case
    switch (productUnitAction) {
      case "CREATE":
        dispatch(createProductUnit({ productUnit }))
          .unwrap()
          .then((response) => {
            hideAndClearProductUnitDialog();
            setTimeout(() => {
              productUnitRefetch();
            }, 500);
          })
          .catch((error) => {
            console.log(error);
          });
        break;
      case "UPDATE":
        dispatch(updateProductUnit({ productUnit }))
          .unwrap()
          .then((response) => {
            hideAndClearProductUnitDialog();
            setTimeout(() => {
              productUnitRefetch();
            }, 500);
          })
          .catch((error) => {
            console.log(error);
          });
        break;
    }
  }

  function ProductUnitInputHandler(e) {
    const { name, value } = e.target;

    setProductUnit({
      ...productUnit,
      [name]: value,
    });
  }

  if (productUnitLoading) {
    return (
      <>
        <LinearProgress />
      </>
    );
  }

  function prepareForUpdate(pu) {
    setProductUnit(pu);
    setProductUnitDialog(true);
    setProductUnitAction("UPDATE");
  }
  function hideAndClearProductUnitDialog() {
    setProductUnitDialog(false);
    setProductUnit({});
    reset();
    setProductUnitAction("CREATE");
  }

  function prepareForDelete(pu) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Product Unit",
      description: `Are you sure want to delete ${pu.name} ?`,
      confrimHandler: async function () {
        dispatch(deleteProductUnit({ pu }))
          .unwrap()
          .then((response) => {
            setConfirmationParams({ open: false });
            setTimeout(() => {
              productUnitRefetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  return (
    <>
      <Grid container spacing={2} padding={2}>
        <Grid>
          <Grid item>
            <Breadcrumbs area-aria-label="breadcrumbs">
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/"
              >
                Top Lift
              </Link>
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/business-setting"
              >
                Business Settings
              </Link>
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/business-setting/product-unit"
              >
                Product Unit
              </Link>
            </Breadcrumbs>
          </Grid>
        </Grid>
        <Grid item xs={12} md={11.8}>
          <Stack flexDirection={"row"} justifyContent={"space-between"}>
            <Typography level="h4" fontWeight="lg">
              Product Unit
            </Typography>
              <MainButton
                name={"Add New"}
                onClick={() => {
                  setProductUnitDialog(true);
                }}
              />
          </Stack>
        </Grid>

        <Grid container spacing={2} padding={2}>
          <Grid item xs={12} md={12}>
            <Divider style={{ width: "100%", marginTop: "1px" }} />
          </Grid>
        </Grid>

        <Box sx={{ flexGrow: 1 }}>
          <Grid container flexDirection={"column"} padding={2}>
            <Grid item style={{ marginTop: "10px" }}>
              <Grid
                container
                spacing={{ xs: 2, md: 2 }}
                columns={{ xs: 4, sm: 8, md: 11 }}
              >
                {productUnits && productUnits?.length > 0 ? (
                  <>
                    {productUnits.map((f, index) => {
                      return (
                        <Grid item xs={4} sm={4} md={2} key={index}>
                          <GlobalCard
                            name={f}
                            prepareForDelete={prepareForDelete}
                            prepareForUpdate={prepareForUpdate}
                          />
                        </Grid>
                      );
                    })}
                  </>
                ) : (
                  <>
                    <NoRecordFound />
                  </>
                )}
              </Grid>
            </Grid>
          </Grid>
        </Box>

        {/* End Grid */}
      </Grid>

      <BusinessSettingsModel
        open={productUnitDialog}
        close={() => {
          hideAndClearProductUnitDialog();
        }}
        name={"Product Unit"}
        textFieldName={"name"}
        label={`Product Unit Name`}
        defaultValue={productUnit.name}
        inputHandler={ProductUnitInputHandler}
        save={saveProductUnit}
        handleSubmit={handleSubmit}
        register={register}
        errors={errors}
      />

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}
