import {
  Divider, 
  Grid,
  Typography,
  Breadcrumbs,
  Link,
  Stack,
  Tooltip,
  Box,
} from "@mui/joy";
import React, { useState } from "react";

import { useQuery } from "@tanstack/react-query";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { VendorService } from "src/services/api/VendorService";
import LinearProgress from "@mui/material/LinearProgress";
import { QueryKeys } from "src/services/queryKey";
import { Slide } from "@material-ui/core";
import { useDispatch } from "react-redux";
import {
  createVendorType,
  deleteVendorType,
  updateVendorType,
} from "src/store/slices/BusinessSettings/vendorType.slice";
import DeleteModel from "src/components/Model/DeleteModel";
import BusinessSettingsModel from "./model/BusinessSettingModel";
import GlobalCard from "./card/BaseCard";
import NoRecordFound from "src/components/Table/NoRecordFound";
import MainButton from "src/components/Button/MainButton";

const vendorTypeValidationSchema = yup.object().shape({
  name: yup.string().required("Vendor Type is Required"),
});

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function VendorType() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(vendorTypeValidationSchema),
  });

  const dispatch = useDispatch();

  const [vendorTypeDialog, setVendorTypeDialog] = useState(false);
  const [vendorTypes, setVendorTypes] = useState([]);
  const [vendorType, setVendorType] = useState({});
  const [vendorTypeAction, setVendorTypeAction] = useState("CREATE");

  const [conformationParams, setConfirmationParams] = useState({ open: false });
  const [open, setOpen] = useState(false);

  const { isLoading: vendorTypeLoading, refetch: vendorTypeRefetch } = useQuery(
    [QueryKeys.getAllVendorTypes],
    async () => {
      return await VendorService.VendorTypeService.getAll();
    },
    {
      onSuccess: (response) => {
        setVendorTypes(response.data);
      },
      staleTime: 0,
    }
  );

  function saveVendorType() {
    // eslint-disable-next-line default-case
    switch (vendorTypeAction) {
      case "CREATE":
        dispatch(createVendorType({ vendorType }))
          .unwrap()
          .then((response) => {
            hideAndClearVendorTypeDialog();
            setTimeout(() => {
              vendorTypeRefetch();
            }, 500);
          })
          .catch((error) => {
            console.log(error);
          });
        break;
      case "UPDATE":
        dispatch(updateVendorType({ vendorType }))
          .unwrap()
          .then((response) => {
            hideAndClearVendorTypeDialog();
            setTimeout(() => {
              vendorTypeRefetch();
            }, 500);
          })
          .catch((error) => {
            console.log(error);
          });
        break;
    }
  }

  function VendorTypeInputHandler(e) {
    const { name, value } = e.target;

    setVendorType({
      ...vendorType,
      [name]: value,
    });
  }

  if (vendorTypeLoading) {
    return (
      <>
        <LinearProgress />
      </>
    );
  }

  function prepareForUpdate(vt) {
    setVendorType(vt);
    setVendorTypeDialog(true);
    setVendorTypeAction("UPDATE");
  }
  function hideAndClearVendorTypeDialog() {
    setVendorTypeDialog(false);
    setVendorType({});
    reset();
    setVendorTypeAction("CREATE");
  }

  function prepareForDelete(vt) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Vendor Type",
      description: `Are you sure want to delete ${vt.name} ?`,
      confrimHandler: async function () {
        dispatch(deleteVendorType({ vt }))
          .unwrap()
          .then((response) => {
            setConfirmationParams({ open: false });
            setTimeout(() => {
              vendorTypeRefetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  return (
    <>
      <Grid container spacing={2} padding={2}>
        <Grid>
          <Grid item>
            <Breadcrumbs area-aria-label="breadcrumbs">
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/"
              >
                Top Lift
              </Link>
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/business-setting"
              >
                Business Settings
              </Link>
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/business-setting/vendor-type"
              >
                Vendor Type
              </Link>
            </Breadcrumbs>
          </Grid>
        </Grid>
        <Grid item xs={12} md={11.8}>
          <Stack flexDirection={"row"} justifyContent={"space-between"}>
            <Typography level="h4" fontWeight="lg">
              Vendor Type
            </Typography>
              <MainButton
                name={"Add New"}
                onClick={() => {
                  setVendorTypeDialog(true);
                }}
              />
          </Stack>
        </Grid>

        <Grid container spacing={2} padding={2}>
          <Grid item xs={12} md={12}>
            <Divider style={{ width: "100%", marginTop: "1px" }} />
          </Grid>
        </Grid>

        <Box sx={{ flexGrow: 1 }}>
          <Grid container flexDirection={"column"} padding={2}>
            <Grid item style={{ marginTop: "10px" }}>
              <Grid
                container
                spacing={{ xs: 2, md: 2 }}
                columns={{ xs: 4, sm: 8, md: 11 }}
              >
                {vendorTypes && vendorTypes?.length > 0 ? (
                  <>
                    {vendorTypes.map((f, index) => {
                      return (
                        <Grid item xs={4} sm={4} md={2} key={index}>
                          <GlobalCard
                            name={f}
                            prepareForDelete={prepareForDelete}
                            prepareForUpdate={prepareForUpdate}
                          />
                        </Grid>
                      );
                    })}
                  </>
                ) : (
                  <>
                    <NoRecordFound />
                  </>
                )}
              </Grid>
            </Grid>
          </Grid>
        </Box>

        {/* End Grid */}
      </Grid>

      <BusinessSettingsModel
        open={vendorTypeDialog}
        close={() => {
          hideAndClearVendorTypeDialog();
        }}
        name={"Vendor Type"}
        textFieldName={"name"}
        label={`Vendor Type Name`}
        defaultValue={vendorType.name}
        inputHandler={VendorTypeInputHandler}
        save={saveVendorType}
        handleSubmit={handleSubmit}
        register={register}
        errors={errors}
      />

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}
