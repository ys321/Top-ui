import { useNavigate } from "react-router-dom";
import { useLogin } from "./useLogin";

import { Grid, Button , TextField, Avatar } from "@mui/joy";
import {   Paper } from '@mui/material';

export default function Login() {
  const paperStyle = { padding: 20, width: 280, margin: "20px auto",justifyContent : 'center' };
  const avatarStyle = {
    backgroundColor: "#1976d2",
    minWidth: "150px",
    minHeight: "150px",
    justifyContent : 'center'
  };
  const btnstyle = { margin: "10px 0" };

  const navigate = useNavigate();

  const { formik, onLogin } = useLogin({
    onSuccess: () => {
      console.log("login");
      navigate("/");
    },
  });

  const { values, errors, handleChange, setFieldValue } = formik;

  return (
    <>
      <Grid container justifyContent={'center'}>
        <Paper elevation={10} style={paperStyle}>
          <Grid item xs={12} md={12} align="center">
            <Avatar variant="soft" color="info" style={avatarStyle}></Avatar>
            <h2 align="center">Sign In</h2>
            <h4 align="center">Top India Elevator</h4>
          </Grid> 
            <Grid item xs={12} md={12}>
            <TextField
            margin="dense"
            label="Username"
            name="username"
            id="username"
            placeholder="Enter username"
            fullWidth
            value={values.username}
            onChange={handleChange("username")}
            error={errors.username ? true : false}
            helperText={errors.username}
          />
            </Grid>

            <Grid item xs={12} md={12}>
            <TextField
            margin="dense"
            name="password"
            label="Password"
            placeholder="Enter Password"
            type="password"
            fullWidth
            value={values.password}
            onChange={handleChange("password")}
            error={errors.password ? true : false}
            helperText={errors.password}
          />
            </Grid>
       
       
          <Button
            type="submit"
            color="primary"
            variant="contained"
            style={btnstyle}
            fullWidth
            onClick={onLogin}
          >
            Sign in
          </Button>
        </Paper>
      </Grid>
    </>
  );
}
