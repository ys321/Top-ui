import { Breadcrumbs, Button, Chip ,Box, Grid, Stack } from "@mui/joy";
import { Form, Formik } from "formik";
import * as yup from 'yup';
import PropTypes from 'prop-types';
import { BaseDropdown } from "src/components/Dropdown/BaseDropdown";
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';

const validationSchema = yup.object({
    machineType: yup
        .string()
        .required('Machine Type is required')
        .max(20),
});

const machineTypeData = [
    {
        'id': 1,
        'name': 'Geared'
    },
    {
        'id': 2,
        'name': 'Regular'
    },
]

const options = [
    {
        'id': 1,
        'name': 'Test 1'
    },
    {
        'id': 2,
        'name': 'Test 2'
    },
    {
        'id': 3,
        'name': 'Test 3'
    },
]

export const MachineRoom = ({ formData, setFormData, nextStep, prevStep, jumpStep }) => {
    return (
        <>
            <Box margin={2}>
                <Formik
                    initialValues={formData}
                    onSubmit={values => {
                        setFormData(values);
                        nextStep();
                    }}
                    validationSchema={validationSchema}
                >
                    {({ errors, touched, handleChange }) => (
                        <Form >
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={12}>
                                    <Breadcrumbs area-label="breadcrumb">
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(1)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Site Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(2)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                            endDecorator={<RadioButtonCheckedIcon fontSize="md" />}
                                        >Machine Room</Chip>
                                    </Breadcrumbs>
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "machineType",
                                            onChange: handleChange,
                                            defaultValue: formData.machineType ?? '',
                                            error: errors.machineType,
                                        }}
                                        options={machineTypeData}
                                        label='Machine Type'
                                        helperText={errors.machineType}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "machineMake",
                                            onChange: handleChange,
                                            defaultValue: formData.machineMake ?? '',
                                        }}
                                        options={options}
                                        label='Machine Make'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "machineRoom",
                                            onChange: handleChange,
                                            defaultValue: formData.machineRoom ?? '',
                                        }}
                                        options={options}
                                        label='Machine Room'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "counterWtPosition",
                                            onChange: handleChange,
                                            defaultValue: formData.counterWtPosition ?? '',
                                        }}
                                        options={options}
                                        label='Counter Wt Position'
                                    />
                                </Grid>
                                <Grid item xs={12} md={6}>
                                    <BaseDropdown
                                        props={{
                                            name: "machinePlacement",
                                            onChange: handleChange,
                                            defaultValue: formData.machinePlacement ?? '',
                                        }}
                                        options={options}
                                        label='Machine Placement'
                                    />
                                </Grid>

                                <Grid item xs={12} md={12}>
                                    <Stack
                                        direction={"row"}
                                        justifyContent={"space-between"}
                                        alignItems={"center"}
                                    >
                                        <Button
                                            variant='outlined'
                                            color="info"
                                            onClick={() => prevStep()}
                                        >
                                            Back To Site Info
                                        </Button>
                                        <Button
                                            type='submit'
                                            variant='outlined'
                                            color='primary'
                                        >
                                            Continue To Door Info
                                        </Button>
                                    </Stack>
                                </Grid>

                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Box>
        </>
    );
}

MachineRoom.propTypes = {
    formData: PropTypes.object.isRequired,
    setFormData: PropTypes.func.isRequired,
    nextStep: PropTypes.func.isRequired
};

export default MachineRoom;