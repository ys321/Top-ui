import { useFormik } from "formik";
import { useState } from "react";
import showToastNotification from "src/components/ToastNotifications/showToastNotification";
import { useAsyncSubmit } from "src/Hooks/useAsyncSubmit";
import { LocationService } from "src/services/api/LocationService";
import * as yup from "yup";



const message = {
    name: "Please Enter Location name",
    phone: "Please Enter Phone number.",

};

const buildValidationSchema = () => {
    return yup.object().shape({
        name: yup
            .string()
            .required(message.name)
            .typeError(message.name)
            .min(5, "Business Location should be at least 5 character long")
            .max(50, "Business Location should not be more than 50 character"),
        phone: yup.number().required(message.phone).typeError(message.phone)
    });
};

let initialValues = {
    name: "",
    address: "",
    phone: "",
    email: "",
    state: "",
    image: "",
    action: "create"
};

export const useBusinessLocation = (props) => {
    const { dialogHandler } = props;

    const [formResult, setFormResult] = useState(null);

    const { submit: triggerSubmit, isSubmitting } = useAsyncSubmit({
        queryFn: LocationService.create,
    });
    const { submit: triggerSubmitUpdate, isSubmittingUpdate } = useAsyncSubmit({
        queryFn: LocationService.update,
    });

    const formik = useFormik({
        initialValues: initialValues,
        validationSchema: buildValidationSchema(),
        validateOnChange: false,
        validateOnBlur: true,
        onSubmit: async (values, { resetForm }) => {
            let result;
            switch (values.action) {
                case "create":
                    const LocationData = new FormData();
                    LocationData.append("name", values.name);
                    LocationData.append("address", values.address);
                    LocationData.append("phone", values.phone);
                    if (values.email) {
                        LocationData.append("email", values.email);
                    }
                    LocationData.append("state", values.state);
                    console.warn(values.image);
                    if (values.image) {
                        LocationData.append("image", values.image);
                    }
                    result = await triggerSubmit(LocationData);
                    break;
                // case "update":
                //     result = await triggerSubmitUpdate(values?.id, values);
                //     break;
                default:
                    throw new Error();
            }
            setFormResult(result);

            let message = "";
            let variant = "error";

            if (result.apiData?.status === 201 || result.apiData?.status === 200) {
                variant = "success";
                message = `Congratulations !! ${values.name} your innquiry submited successfully. \n We will contact you soon !`;
                resetForm();
            } else {
                message = `Unexpect error occured ! Please Try again after some time. \n Sorry for inconvenience !`;
            }
            showToastNotification(message, { variant: variant });
            dialogHandler();
            resetForm();
        },
    });

    return {
        formik,
        formResult,
        isSubmitting,
        isSubmittingUpdate,
        errors: formik.errors,
        values: formik.values,
        setValues: formik.setValues,
        setFieldValue: formik.setFieldValue,
        handleChange: formik.handleChange,
        handleSubmit: formik.handleSubmit,
        isValid: formik.isValid,
    };
};
