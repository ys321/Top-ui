import { Box, Button, Grid, Stack } from "@mui/joy";
import { EditText } from "src/components/EditText";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import CancelIcon from "@mui/icons-material/Cancel";
import { FormControl, FormLabel } from "@mui/material";
import CancelButton from "src/components/Button/CancelButton";
import { useBusinessLocation } from "../BusinessLocation/useBusinessLocation";
import SubmitButton from "src/components/Button/SubmitButton";

export default function BusinessLocationForm({
  save,
  locationValidationSchema,
  close,
  LocationRefetch,
}) {

  function handleClose() {
    close();
    LocationRefetch();
  }
  const {
    formik,
    errors,
    values,
    handleChange,
    handleSubmit,
    setFieldValue,
    isSubmitting,
    isSubmittingUpdate,
    setValues,
  } = useBusinessLocation({
    dialogHandler: handleClose,
  });


  console.warn(values);


  return (
    <>
      <Box margin={1} component={'form'} onSubmit={handleSubmit}>
        {/* <Formik
          initialValues={{
            name: "",
            address: "",
            phone: "",
            email: "",
            state: "",
            image: "",
          }}
          onSubmit={async (values) => {
            save(values);
          }}
          validationSchema={locationValidationSchema}
        >
          {({ values, errors, handleChange, setFieldValue }) => (
            <Form> */}

        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <EditText
              name="name"
              placeholder="Name"
              label={'Business Location Name'}
              //   startDecorator={<Phone />}
              onChange={handleChange}
              value={values.name}
              error={errors.name}
              helpertext={errors.name}
            />

          </Grid>
          <Grid item xs={12} md={6}>
            <EditText

              name="address"
              placeholder="Address"
              onChange={handleChange}
              value={values.address}
              error={errors.address}
              helpertext={errors.address}
            />
            {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="address"
                    label="Address"
                    variant="outlined"
                    value={values.address}
                    onChange={handleChange}
                    error={errors.address ? true : false}
                    helperText={errors.address}
                  /> */}
          </Grid>
          <Grid item xs={12} md={6}>
            <EditText

              name="phone"
              placeholder="Phone"
              onChange={handleChange}
              value={values.phone}
              error={errors.phone}
              helpertext={errors.phone}
            />
            {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="phone"
                    label="Phone"
                    variant="outlined"
                    value={values.phone}
                    onChange={handleChange}
                    error={errors.phone ? true : false}
                    helperText={errors.phone}
                  /> */}
          </Grid>
          <Grid item xs={12} md={6}>
            <EditText

              name="email"
              placeholder="Email"
              onChange={handleChange}
              value={values.email}
              error={errors.email}
              helpertext={errors.email}
            />
            {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="email"
                    label="Email"
                    variant="outlined"
                    value={values.email}
                    onChange={handleChange}
                    error={errors.email ? true : false}
                    helperText={errors.email}
                  /> */}
          </Grid>
          <Grid item xs={12} md={6}>
            <EditText

              name="state"
              placeholder="State"
              onChange={handleChange}
              value={values.state}
              error={errors.state}
              helpertext={errors.state}
            />
            {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="state"
                    label="State"
                    variant="outlined"
                    value={values.state}
                    onChange={handleChange}
                    error={errors.state ? true : false}
                    helperText={errors.state}
                  /> */}
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl>
              <FormLabel>Image</FormLabel>
              <Button
                component="label"
                variant="outlined"
                starticon={<UploadFileIcon />}
                size={"sm"}
              >
                Upload Image
                <input
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={(e) =>
                    setFieldValue("image", e.currentTarget.files[0])
                  }
                />
              </Button>
            </FormControl>
            <Box>{values?.image?.name}</Box>
          </Grid>

          <Grid item xs={12} md={12}>
            <Stack
              direction={"row"}
              justifyContent={"end"}
              alignItems={"center"}
              spacing={2}
            >
              <SubmitButton
                loading={
                  isSubmitting

                }
              >
                Submit
              </SubmitButton>
              {/* <SaveButton startDecorator={<AddLocationAltIcon />} /> */}
              <CancelButton
                startDecorator={<CancelIcon />}
                onClick={close}
              />
            </Stack>
          </Grid>
        </Grid>
        {/* </Form>
          )}
        </Formik> */}
      </Box>
    </>
  );
}
