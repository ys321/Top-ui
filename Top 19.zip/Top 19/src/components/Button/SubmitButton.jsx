import { Button } from "@mui/joy";
import { BaseButton } from "./BaseButton";


export default function SubmitButton (props) {
    
    return (
        <BaseButton 
            {...props}
            type={'submit'}
            loadingPosition={'start'}           
        >{props.children}</BaseButton>
    )
}