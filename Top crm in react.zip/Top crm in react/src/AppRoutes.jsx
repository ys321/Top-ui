import React, { lazy, Suspense, useEffect } from "react";
import { useRoutes } from "react-router-dom";
import { getTokenFromStorage } from "./storage";
import { routes } from "./utils/routes";
import { setUser } from "src/store/slices/user.slice";
import { useDispatch } from "react-redux";
import { useUserInfo } from "./Hooks/useUserInfo";
import Login from "./pages/auth/login";
import { TOPAppBar } from "./components/Appbar/TOPAppBar";

import LoadingScreen from "./pages/LoadingScreen";
// const LoadingScreen = lazy(() => import("./pages/LoadingScreen"));

function AppRoutes() {
  const appRoutes = useRoutes(routes);
  const userData = useUserInfo();
  const dispatch = useDispatch();

  useEffect(() => {
    const token = getTokenFromStorage();
    // console.log(token);
    if (token) {
      dispatch(
        setUser({
          token: token,
          isLoggedIn: true,
        })
      );
    }
  }, []);

  return (
    <>
      {!userData.isLoggedIn ? (
        <>
          <Login />
        </>
      ) : (
        <>
          <TOPAppBar />
          <Suspense fallback={<LoadingScreen />}>{appRoutes}</Suspense>
        </>
      )}
    </>
  );
}

export default AppRoutes;
