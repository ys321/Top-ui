import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { VendorService } from "src/services/api/VendorService";
import { errorAlert, successAlert, warningAlert } from "./alert.slice";
import { toggleProcess } from "./process.slice";

export const createVendor = createAsyncThunk(
  "@vendor/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await VendorService.create(params.values);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Vendor",
            message: "Vendor Create Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Create Failed",
            message: "invalid Data",
          })
        );
      });
  }
);

export const updateVendor = createAsyncThunk(
  "@vendor/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await VendorService.update(params.vendor_id, params.values);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Vendor",
            message: "Vendor Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Update Failed",
            message: "Invalid Data !",
          })
        );
      });
  }
);

export const deleteVendor = createAsyncThunk(
  "@vendor/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await VendorService.remove(params.vendor.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Vendor",
            message: "Vendor Delete Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Delete Failed",
            message: "Vendor Delete Failed !",
          })
        );
      });
  }
);

export const createVendorCategoryLink = createAsyncThunk(
  "@vendorCategory/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await VendorService.VendorCategoryLink.update(
        params.values.category,
        { vendor: params.values.vendor }
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Vendor Category Link",
            message: "Vendor Category Link Create Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Category Link Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deleteVendorCategoryLink = createAsyncThunk(
  "@vendorCategoryLink/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await VendorService.VendorCategoryLink.remove(params.category.id, {
        vendor: params.vendor,
      });
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Vendor Category Link",
            message: "Vendor Category  Link Delete Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Vendor Category  Link Delete Failed",
            message: "Vendor Category  Link Delete Failed",
          })
        );
      });
  }
);

/*** the above section can be removed in future */

const initialState = {
  vendors: []
}

const vendors = createSlice({
  name: 'vendors',
  initialState: initialState,
  reducers: {
      setVendors : (state, { payload }) => {
          state.vendors = payload;
      }
  }
});

export const { setVendors } = vendors.actions;
export const vendorReducers = vendors.reducer; 