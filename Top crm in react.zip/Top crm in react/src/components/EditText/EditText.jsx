import { FormHelperText, Input } from "@mui/joy";
import FormControl from "@mui/joy/FormControl";
import FormLabel from "@mui/joy/FormLabel";

export function EditText(props) {

    const { helpertext, error } = props;

    if (error) {
        props = {
            ...props,
            error : true
        }
    }

    return (
        <FormControl error={error ? true : false}>
        <Input
            variant="soft"
            {...props}
            sx={{
                // backgroundColor: 'white',
                // borderRadius: 50,
                padding: 1.5,

                '& span': {
                    marginLeft: 2,
                    '& > svg' : {
                        height: 'auto',
                        width: 20
                    }
                },

                '& input' : {
                    '&::placeholder': {
                        fontSize: 14,
                        letterSpacing: 1
                    }
                },

                '& p': {
                    color: 'red'
                }
            }}
            fullWidth
        />
        {helpertext &&  <FormHelperText sx={{ marginLeft: 1, fontSize: 11, letterSpacing: 0.5 }}>{helpertext}</FormHelperText>}
        </FormControl>

    )
}