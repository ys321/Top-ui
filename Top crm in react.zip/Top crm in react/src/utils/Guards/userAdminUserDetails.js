import { useUserInfo } from "src/Hooks/useUserInfo";
import { QueryKeys } from "src/services/queryKey";
import UserService from "src/services/user/userServices";
import useHttpQuery from "./useHttpQuery";
import { UserRoles } from "./UserRoles";

export default function useAdminUserDetails({ isEnabled = true } = {}) {
  const userData = useUserInfo()?.token;

  const userId = userData;

  const query = useHttpQuery({
    key: QueryKeys.USER,
    apiFn: UserService.getUser,
    apiFnArgs: [userId],
    config: {
      enabled: !!userId && isEnabled,
      cacheTime: Infinity,
      staleTime: Infinity,
      refetchOnMount: false,
      refetchOnWindowFocus: "always",
    },
  });

  const userDetails = query.data;
  const userHasRole = (role) => {
    return !!userDetails?.roles.find((r) => r.role === role);
  };

  const isTopEmployee = userHasRole(UserRoles.TOP_EMPLOYEE);
  const isTopAdmin = userHasRole(UserRoles.TOP_ADMIN);

  return {
    userDetailsQuery: query,
    userDetails,
    userHasRole,
    isTopEmployee,
    isTopAdmin,
  };
}
