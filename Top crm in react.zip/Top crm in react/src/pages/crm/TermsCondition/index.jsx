import { Breadcrumbs, Button, Chip, ChipDelete, Divider, List, ListItem, TextField,Box, Grid, Link, Stack, Typography } from "@mui/joy";

import { FieldArray, Form, Formik, getIn } from "formik";
import PropTypes from 'prop-types';
import { useEffect, useRef } from "react";
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';

const debug = true;

export const TermsCondition = ({ formData, setFormData, nextStep, prevStep, jumpStep,saveTerms }) => {
  const formRef = useRef();
  
  return (
    <>
      <Box margin={2}>
        <Formik
          initialValues={{
            entries: [
              {
                id: Math.random(),
                srNo: '',
                termsAndCondition: ''
              }
            ]
          }}
          onSubmit={async (values) => {
            
            // setFormData(values);
            // saveTerms(values)
            nextStep();
          }}
          innerRef={formRef}
        // validationSchema={validationSchema}
        >
          {({ values, touched, errors, handleChange, setValues }) => (
            <Form>
              <Grid container spacing={1}>
                <Grid item xs={12} md={12}>
                  <Breadcrumbs area-label="breadcrumb">
                    <Chip
                      color="primary"
                      onClick={() => {
                        jumpStep(1)
                      }}
                      variant="outlined"
                      size="lg"
                    >Site Info</Chip>
                    <Chip
                      color="primary"
                      onClick={() => {
                        jumpStep(2)
                      }}
                      variant="outlined"
                      size="lg"
                    >Machine Room</Chip>
                    <Chip
                      color="primary"
                      onClick={() => {
                        jumpStep(3)
                      }}
                      variant="outlined"
                      size="lg"
                    >Door Info</Chip>
                    <Chip
                      color="primary"
                      onClick={() => {
                        jumpStep(4)
                      }}
                      variant="outlined"
                      size="lg"
                    >Cabin Info</Chip>
                    <Chip
                      color="primary"
                      onClick={() => {
                        jumpStep(5)
                      }}
                      variant="outlined"
                      size="lg"
                    >Controller Info</Chip>
                    <Chip
                      color="primary"
                      onClick={() => {
                        jumpStep(6)
                      }}
                      variant="outlined"
                      size="lg"
                    >Lift Specification</Chip>
                    <Chip
                      color="primary"
                      onClick={() => {
                        jumpStep(7)
                      }}
                      variant="outlined"
                      size="lg"
                      endDecorator={<RadioButtonCheckedIcon fontSize="md" />}
                    >Terms & Condition</Chip>
                  </Breadcrumbs>
                </Grid>
                {/* <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Typography variant={'h4'}>Terms & Condition</Typography>
                  </Stack>
                </Grid> */}
                <FieldArray name="entries">
                  {({ push, remove }) => (
                    <>
                      <>
                        <Grid item xs={12} md={12}>
                          <Stack
                            direction={"row"}
                            justifyContent={"end"}
                          >
                            <Button
                              variant="solid"
                              onClick={() => {
                                push({ id: Math.random(), srNo: "", termsAndCondition: "" })
                              }
                              }
                            >
                              Add
                            </Button>
                          </Stack>
                        </Grid>
                      </>
                      {values.entries.length > 0 &&
                        values.entries.map((p, idx) => {
                          const srNo = `entries[${idx}].srNo`;
                          const termsAndCondition = `entries[${idx}].termsAndCondition`;

                          return (
                            <>
                              <Grid item xs={12} md={0.7} key={idx}>
                                <TextField
                                  margin="dense"
                                  fullWidth
                                  name={srNo}
                                  label="SR No."
                                  value={p.srNo}
                                  variant="outlined"
                                  onChange={handleChange}
                                />
                              </Grid>
                              <Grid item xs={12} md={10.7}>
                                <TextField
                                  margin="dense"
                                  fullWidth
                                  name={termsAndCondition}
                                  label="Terms And Condtion"
                                  value={p.termsAndCondition}
                                  variant="outlined"
                                  onChange={handleChange}
                                />
                              </Grid>
                              <Grid item xs={12} md={0.2} marginTop={3.5}>
                                <ChipDelete
                                  // sx={{
                                  //   textAlign: "end",
                                  // }}
                                  color="danger"
                                  variant="solid"
                                  onClick={() => {
                                    remove(idx);

                                  }}
                                />

                              </Grid>
                            </>
                          );
                        })}
                    </>
                  )}
                </FieldArray>

                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Button
                      variant='outlined'
                      color="info"
                      onClick={() => prevStep()}
                    >
                      Back To List Specification
                    </Button>
                    <Button
                      type='submit'
                      variant='outlined'
                      color='primary'
                    >
                      Continue
                    </Button>
                  </Stack>
                </Grid>

                {debug && (
                  <>
                    <pre style={{ textAlign: "left" }}>
                      <strong>Values</strong>
                      <br />
                      {JSON.stringify(values, null, 2)}
                    </pre>


                    <pre style={{ textAlign: "left" }}>
                      <strong>Errors</strong>
                      <br />
                      {JSON.stringify(errors, null, 2)}
                    </pre>
                  </>
                )}
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>
    </>
  );
}
TermsCondition.propTypes = {
  formData: PropTypes.object.isRequired,
  setFormData: PropTypes.func.isRequired,
  nextStep: PropTypes.func.isRequired
}

export default TermsCondition;