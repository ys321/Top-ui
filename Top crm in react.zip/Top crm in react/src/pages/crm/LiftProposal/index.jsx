import SiteInfo from "../SiteInfo";
import MachineRoom from "../MachineRoom";
import { useState } from "react";
import { Confirm } from "../Confirm";
import DoorInfo from "../DoorInfo";
import CabinInfo from "../CabinInfo";
import ControllerInfo from "../ControllerInfo";
import LiftSpecification from "../LiftSpecification";
import TermsCondition from "../TermsCondition";

export const ListPropsal = () => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        // Site Form Data
        liftType: '',
        noOfBasement: '',
        groundFloor: '',
        noOfFloor: '',
        liftQuantity: '',
        floor: '',
        openingSide: '',
        floor_height: '',
        noOfStops: '',
        noOfOpening: '',
        hoistWayAvailable: '',
        hoistWayStructure: '',
        machineRoomAvailable: '',

        // Machine Room
        machineType: '',
        machineMake: '',
        machineRoom: '',
        counterWtPosition: '',
        machinePlacement: '',

        // Door Info
        doorType: '',
        landingDoorSelection: '',
        glassDoor: '',
        visiblePanel: '',
        doorBrand: '',
        doorOpration: '',

        //Cabin Info
        carInsideWide: '',
        carInsideDeep: '',
        carEnclosure: '',
        carCarpetArea: '',

        //Controller Info
        driveType: '',
        controllerOperation: '',
        ard: '',
        olns: '',
        // controlOperation: '',

        //Lift Specifaction
        noOfPassenger: '',
        loadCapacity: '',
        speed: '',
        powerSupply: '',
        col_lop: '',
        cop_lop_displayType: '',
        security: '',
        rate: '',
        amount: '',
        gst: '',
        // total : '',
        signal: '',
        srNo: '',
        note: '',
        entries: []
    });
    // function saveTerms(values) {
    //     formData.entries.push(values)
    // }
    console.log(formData);

    const nextStep = () => setStep(prev => prev + 1);
    const prevStep = () => setStep(prev => prev - 1);
    const jumpStep = (step) => setStep(step);
    switch (step) {
        case 1:
            return (
                <SiteInfo
                    formData={formData}
                    setFormData={setFormData}
                    nextStep={nextStep}
                    jumpStep={jumpStep}
                />
            );
        case 2:
            return (
                <MachineRoom
                    formData={formData}
                    setFormData={setFormData}
                    nextStep={nextStep}
                    prevStep={prevStep}
                    jumpStep={jumpStep}
                />
            );
        case 3:
            return (
                <DoorInfo
                    formData={formData}
                    setFormData={setFormData}
                    nextStep={nextStep}
                    prevStep={prevStep}
                    jumpStep={jumpStep}
                />
            );
        case 4:
            return (
                <CabinInfo
                    formData={formData}
                    setFormData={setFormData}
                    nextStep={nextStep}
                    prevStep={prevStep}
                    jumpStep={jumpStep}
                />
            );
        case 5:
            return (
                <ControllerInfo
                    formData={formData}
                    setFormData={setFormData}
                    nextStep={nextStep}
                    prevStep={prevStep}
                    jumpStep={jumpStep}
                />
            );
        case 6:
            return (
                <LiftSpecification
                    formData={formData}
                    setFormData={setFormData}
                    nextStep={nextStep}
                    prevStep={prevStep}
                    jumpStep={jumpStep}
                />
            );
        case 7:
            return (
                <TermsCondition
                    formData={formData}
                    // saveTerms={saveTerms}
                    setFormData={setFormData}
                    nextStep={nextStep}
                    prevStep={prevStep}
                    jumpStep={jumpStep}
                />
            )
        case 8:
            return (
                <Confirm formData={formData} nextStep={nextStep} prevStep={prevStep} />
            );
        // default:
        //     return <Success />;
    }
};

export default ListPropsal;