import React, {  useState } from "react";
import { useQuery } from "@tanstack/react-query";

import _ from "lodash";
import { ProductService } from "src/services/api/ProductService";

import {
  Dialog,
  DialogContent,
  DialogTitle,
  Grid,
  Popover,
} from "@mui/material";

import ProductForm from "src/pages/inventory/products/ProductForm";
import ProductTable from "src/pages/inventory/products/ProductTable";
import { QueryKeys } from "src/services/queryKey";
import { LinearProgress } from "@material-ui/core";
import {
  Button,
  Tooltip,
} from "@mui/joy";
import ProductFilter from "./ProductFilter";
import InventoryIcon from "@mui/icons-material/Inventory";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import MainButton from "src/components/Button/MainButton";

function ProductPage() {
  const [page, setPage] = useState(1);
  const [products, setProducts] = useState([]);

  const [productDailog, setProductDailog] = useState(false);
  const [productFilter, setProductFilter] = useState(false);

  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;

  const { isLoading: productLoading, refetch: productRefech } = useQuery(
    [QueryKeys.getAllProducts, page],
    async () => {
      return await ProductService.getAll({ page: page });
    },
    {
      onSuccess: (response) => {
        setProducts(response.data);
      },
      keepPreviousData: true,
      staleTime: 0,
      enabled: true,
    }
  );

  if (productLoading) {
    return (
      <>
        <LinearProgress />
      </>
    );
  }

  return (
    <>
      <Grid container justifyContent={"flex-end"} spacing={3} paddingRight={3}>
        <Grid item>
          <Tooltip title={`Filter`} variant="soft">
            <Button
              startDecorator={<FilterAltIcon />}
              variant="solid"
              onClick={handleClick}
            >
              Filter
            </Button>
          </Tooltip>
        </Grid>
        <Grid item>
            <MainButton
              name={"Add New Product"}
              startDecorator={<InventoryIcon />}
              onClick={() => {
                setProductDailog(true);
              }}
            />
        </Grid>
      </Grid>
      <Grid container spacing={3} padding={2}>
        <Grid item xs={12} md={12}>
          <>
            <Dialog
              maxWidth="lg"
              fullWidth
              open={productDailog}
              onClose={() => {
                setProductDailog(false);
              }}
            >
              <DialogTitle>Product</DialogTitle>
              <DialogContent>
                <ProductForm
                  dailogHandler={setProductDailog}
                  successCallback={productRefech}
                />
              </DialogContent>
            </Dialog>
          </>
        </Grid>
        <Grid item xs={12} md={12}>
          <ProductTable
            rows={products}
            paginationHelper={setPage}
            successCallback={productRefech}
          />
        </Grid>
      </Grid>

      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleCloseMenu}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        <ProductFilter dialogHandle={handleCloseMenu} />
      </Popover>

      <Dialog
        maxWidth="lg"
        fullWidth
        open={productFilter}
        onClose={() => {
          setProductFilter(false);
        }}
      >
        <DialogTitle>Product Filter</DialogTitle>
        <DialogContent>
          <ProductFilter dialogHandle={setProductFilter} />
        </DialogContent>
      </Dialog>
    </>
  );
}

export default ProductPage;
