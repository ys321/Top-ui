import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import {Table,TableBody,TableContainer,TableHead,TableRow,Paper} from "@mui/material";
import { Button, Grid, Box } from "@mui/joy";

import AddIcon from "@mui/icons-material/Add";

import { useState } from "react";
import { LocationService } from "src/services/api/LocationService";
import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";
import { QueryKeys } from "src/services/queryKey";

function InwardList() {
  const [inwardDailog, setInwardDailog] = useState(false);

  const [inwards, setInwards] = useState([]);

  const { isLoading, } = useQuery(
    [QueryKeys.getAllLocations],
    async () => {
      const reponse = await LocationService.getAll();
      return reponse;
    },
    {
      onSuccess: (response) => {
        setInwards(response);
      },
    }
  );

  const handleOpen = () => {
    setInwardDailog(!inwardDailog);
  };

  return (
    <>
      {isLoading ? <h1>Loading...</h1> : <></>}
      <div></div>
      <Box style={{ padding: "10px" }}>
        <Grid container spacing={3} justifyContent={"flex-end"}>
          {/* <ProductLocationForm
              isDialogOpened={inwardDailog}
              handleCloseDialog={() => setInwardDailog(false)}
              inwards={inwards}
            /> */}
          <Button
            style={{ marginRight: "10px" }}
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpen()}
          >
            Link Inward
          </Button>
          <TableContainer component={Paper} style={{ marginTop: "15px" }}>
            <Table sx={{ minWidth: 700 }} aria-label="customized table">
              <TableHead>
                <TableRow>
                  <StyledTableCell>Branch Name</StyledTableCell>

                  <StyledTableCell>Product Quantity</StyledTableCell>
                  <StyledTableCell>Buffer Quantity</StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {inwards.map((businessLocation, index) => (
                  <StyledTableRow key={index}>
                    <StyledTableCell>{businessLocation.name}</StyledTableCell>
                    <StyledTableCell>{}</StyledTableCell>
                    <StyledTableCell>{}</StyledTableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Box>
    </>
  );
}

export default InwardList;
