import { createAsyncThunk } from "@reduxjs/toolkit";
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import { MaterialRequestService } from "src/services/api/MaterialRequestService";
import { errorAlert, successAlert } from "src/store/slices/alert.slice";
import { toggleProcess } from "src/store/slices/process.slice";
import * as yup from "yup";

const errorMessage = {
    branch: 'Please Select Valid Branch',
    contact_person: 'Please Provide Contact Person for communication',
    mobile_no: 'Please Provide Contact Number for communication',
    email: 'Please Provide valid Email Address for communication',

    // entires message
    product: 'Please select valid Product',
    ordered_qty: 'Please provide valid ordered quantity',
    basic_rate: 'Basic Rate can be valid decimal point numbers only',
    amount: 'Amount can be valid decimal point numbers only',
    extra_details: 'Remarks / Additional Information should be maximum 255 character long',
    request_no: 'Request Number is automatic generated & can not be modified for any reasons'
}

const materialRequestEntriesValidaitionSchema = yup.object().shape({
    date: yup.date().optional(),
    product: yup.number().required(errorMessage.product).typeError(errorMessage.product),
    ordered_qty: yup.number().integer().required(errorMessage.ordered_qty).typeError(errorMessage.ordered_qty),
    basic_rate: yup.number().required(errorMessage.basic_rate).typeError(errorMessage.basic_rate),
    discount: yup.number().optional().typeError(errorMessage.discount),
    amount: yup.number().required(errorMessage.amount).typeError(errorMessage.amount),
    extra_details: yup.string(errorMessage.extra_details).optional().nullable().max(255)
})

let entriesInitialValues = {
    product: '',
    ordered_qty: 0,
    basic_rate: 0,
    discount: 0,
    amount: 0,
    extra_details: ''
}

const materialRequestValidationSchema = yup.object().shape({
    branch: yup.number().required(errorMessage.branch).min(0).typeError(errorMessage.branch),
    contact_person: yup.string().required(errorMessage.contact_person),
    mobile_no: yup
        .number()
        .typeError(errorMessage.mobile_no)
        .required(errorMessage.mobile_no),
    email: yup.string().required(errorMessage.email),
    entries: yup.array().of(materialRequestEntriesValidaitionSchema).min(1, 'One or more products are required for sending Material Request to Location')
});

let initialValues = {
    branch: '',
    contact_person: '',
    mobile_no: '',
    email: '',
    entries: [],
    status: 1,
    action: 'save'
};

const saveMaterialRequest = createAsyncThunk(
    "materialRequest/save",
    (info, thunk) => {
        const { dispatch } = thunk;
        const { callback, ...params } = info;

        dispatch(
            toggleProcess({
                visible: true,
                open: true,
                loading: true,
            })
        );
        const { action } = params;
        delete params['action'];
        if (action === 'save') {
            MaterialRequestService.create(params)
                .then((response) => {
                    dispatch(
                        toggleProcess({
                            visible: false,
                            open: false,
                            loading: false
                        })
                    );

                    dispatch(
                        successAlert({
                            visible: true,
                            title: 'Material Request',
                            message: 'Material Request has been Saved !',
                        })
                    )
                    callback?.();
                })
                .catch(() => {
                    dispatch(
                        errorAlert({
                            visible: true,
                            title: 'New Material Request',
                            message: 'Failed to save Material Request :(',
                        })
                    )
                })
                .finally(() => {
                    dispatch(
                        toggleProcess({
                            visible: false,
                            open: false,
                            loading: false
                        })
                    );
                });
        }
        if (action === 'update') {
            MaterialRequestService.update(params?.id, params)
                .then(() => {
                    dispatch(
                        toggleProcess({
                            visible: false,
                            open: false,
                            loading: false
                        })
                    );
                    dispatch(
                        successAlert({
                            visible: true,
                            title: "Update Material Request",
                            message: 'Material Request has been Saved !'
                        })
                    );
                    callback?.();
                })
                .catch((error) => {
                    console.log(error);
                    dispatch(
                        errorAlert({
                            visible: true,
                            title: 'Update Material Request',
                            message: 'Failed to save Material Request',
                        })
                    );
                })
                .finally(() => {
                    dispatch(
                        toggleProcess({
                            visible: false,
                            open: false,
                            loading: false,
                        })
                    )
                })
        }
    }
)


export const useMaterialRequest = (props) => {
    const { onSuccess, dataObj } = props;
    const dispatch = useDispatch();

    let finalInitValues = initialValues;
    if (dataObj) {
        finalInitValues = dataObj;
    }
    const formik = useFormik({
        initialValues: finalInitValues,
        enableReinitialize: true,
        validationSchema: materialRequestValidationSchema,
        validateOnChange: true,
        onSubmit: (values, { resetForm }) => {
            const callback = () => {
                onSuccess?.();
            };
            const params = { ...values, callback };

            dispatch(saveMaterialRequest(params));
        },
    });
    return {
        formik,
        onSave: formik.handleSubmit
    };
};

export const useMaterialRequestEntries = (props) => {
    const { onSuccess, dataObj } = props;

    let finalInitValues = entriesInitialValues;
    if (dataObj) {
        finalInitValues = dataObj;
    }
    const formikForEntires = useFormik({
        initialValues: finalInitValues,
        enableReinitialize: true,
        validationSchema: materialRequestEntriesValidaitionSchema,
        validateOnChange: true,
        onSubmit: (values, { resetForm }) => {
            const callback = () => {
                onSuccess?.();
            };
            callback();
        },
    });
    return {
        formikForEntires,
        onEntrySave: formikForEntires.handleSubmit
    }
}

