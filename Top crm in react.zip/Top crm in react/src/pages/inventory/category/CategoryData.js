import * as yup from "yup";

const errorMessage = {
  name: "Sub Category Name is Required",
  description: "Description is Required",
};

export const categoryValidationSchema = yup.object().shape({
  name: yup.string().required(errorMessage.name).typeError(errorMessage.name),
  description: yup
    .string()
    .required(errorMessage.description)
    .typeError(errorMessage.description),
});
