import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import { subCategoryValidationSchema } from "src/utils/validation/category.validation";

import { useDispatch } from "react-redux";
import UploadFileIcon from "@mui/icons-material/UploadFile";

import {
  createSubCategory,
  deleteSubCategoryData,
  updateSubCategory,
} from "src/store/slices/category/subCategory.slice";
import {
  Grid,
  Button,
  Typography,
  Stack,
  Box,
  Modal,
  Sheet,
  ModalClose,
  TextField,
  Tooltip,
} from "@mui/joy";
import { EditText } from "src/components/EditText";
import NoRecordFound from "src/components/Table/NoRecordFound";
import CategoryCard from "src/components/cards/CategoyCard";

import { Form, Formik } from "formik";
import { subCategorySchema } from "./useSubCategory";
import DeleteModel from "src/components/Model/DeleteModel";
import FormControl from "@mui/joy/FormControl";
import FormLabel from "@mui/joy/FormLabel";
import MainButton from "src/components/Button/MainButton";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

function SubCategoryListPage({
  subCategories,
  category_id,
  refetch,
  isLoading,
}) {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(subCategoryValidationSchema),
  });

  const dispatch = useDispatch();
  const [subCategory, setSubCategory] = useState({});
  const [openSubCategoryModel, showSubCategoryModel] = useState(false);

  const [subCategoryDailogAction, setSubCategoryDailogAction] =
    useState("CREATE");
  const [conformationParams, setConfirmationParams] = useState({ open: false });

  function saveSubCategory(values) {
    let response = null;
    values.category = category_id;
    values.attributes = [];
    // eslint-disable-next-line default-case
    switch (subCategoryDailogAction) {
      case "CREATE":
        dispatch(createSubCategory({ values }))
          .unwrap()
          .then((response) => {
            showSubCategoryModel(false);
            setTimeout(() => {
              refetch();
            }, 500);
            setSubCategory({});
          })
          .catch((error) => {
            console.log(error);
          });
        break;
      case "UPDATE":
        dispatch(updateSubCategory({ subCategory }))
          .unwrap()
          .then((response) => {
            showSubCategoryModel(false);
            setSubCategoryDailogAction("CREATE");
            setTimeout(() => {
              refetch();
            }, 500);
            setSubCategory({});
          })
          .catch((error) => {
            console.log(error);
          });
        break;
    }
  }

  function deleteSubCategory(subCategory) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: ` ${subCategory.name}`,
      description: `Are you sure want to delete Sub Category ${subCategory.name} ?`,
      confrimHandler: async function () {
        dispatch(deleteSubCategoryData({ subCategory }))
          .unwrap()
          .then((response) => {
            setConfirmationParams({ open: false });
            hideAndClearSubCategoryDailog();
            setTimeout(() => {
              refetch();
            }, 500);
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  const hideAndClearSubCategoryDailog = () => {
    showSubCategoryModel(false);
    reset();
    setSubCategory("");
    setSubCategoryDailogAction("CREATE");
  };

  const editActionHandler = (subCategory) => {
    setSubCategoryDailogAction("UPDATE");
    setSubCategory(subCategory);
    showSubCategoryModel(true);
  };

  return (
    <>
      {isLoading ? (
        <>
          <h1>Loading...</h1>
        </>
      ) : (
        ""
      )}
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={2} padding={2}>
          <Grid item xs={12} md={12}>
            <Stack flexDirection={"row"} justifyContent={"space-between"}>
              <Typography level="h4">Sub Category</Typography>
                <MainButton
                  name={"Add New Sub Category"}
                  onClick={() => {
                    showSubCategoryModel(true);
                  }}
                />
            </Stack>
          </Grid>
        </Grid>

      </Box>

      {subCategories && subCategories?.length > 0 ? (
        <Grid container spacing={4} justifyContent="center" padding={2}>
          {subCategories.map((subCategory, index) => {
            return (
              <Grid item key={index}>
                <CategoryCard
                  link={`:category_id/sub-category/:sub_category_id`
                    .replace(":category_id", category_id)
                    .replace(":sub_category_id", subCategory.id)}
                  // cname={category}
                  name={subCategory}
                  deleteHandler={() => deleteSubCategory(subCategory, index)}
                />
              </Grid>
            );
          })}
        </Grid>
      ) : (
        <>
          <NoRecordFound />
        </>
      )}

      <>
        <Modal
          aria-labelledby="modal-title"
          aria-describedby="modal-desc"
          open={openSubCategoryModel}
          onClose={() => hideAndClearSubCategoryDailog()}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Sheet
            variant="outlined"
            sx={{
              maxWidth: 800,
              borderRadius: "md",
              p: 3,
              boxShadow: "lg",
            }}
          >
            <ModalClose
              variant="outlined"
              sx={{
                top: "calc(-1/4 * var(--IconButton-size))",
                right: "calc(-1/4 * var(--IconButton-size))",
                boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
                borderRadius: "50%",
                bgcolor: "background.body",
              }}
            />
            <Typography
              component="h2"
              id="modal-title"
              level="h4"
              textColor="inherit"
              fontWeight="lg"
              mb={1}
            >
              Sub Category { }
            </Typography>

            <Box margin={1}>
              <Formik
                initialValues={{
                  name: "",
                  description: "",
                  image: "",
                }}
                onSubmit={async (values) => {
                  saveSubCategory(values);
                }}
                // innerRef={formRef}
                validationSchema={subCategorySchema}
              >
                {({
                  values,
                  errors,
                  handleChange,
                  setValues,
                  touched,
                  setFieldValue,
                }) => (
                  <Form>
                    <Grid container spacing={2}>
                      <Grid item xs={12} md={6}>
                        <EditText
                          name="name"
                          placeholder="Name"
                          onChange={handleChange}
                          value={values.name}
                          error={errors.name ? true : false}
                          helpertext={errors.name}
                        />
                        {/* <TextField
                          size="md"
                          margin="dense"
                          fullWidth
                          name="name"
                          label="Name"
                          variant="outlined"
                          value={values.name}
                          onChange={handleChange}
                          error={errors.name ? true : false}
                          helperText={errors.name}
                        /> */}
                      </Grid>
                      <Grid item xs={12} md={6}>
                        <EditText
                          name="description"
                          placeholder="Description"
                          onChange={handleChange}
                          value={values.description}
                          error={errors.description ? true : false}
                          helpertext={errors.description}
                        />
                        {/* <TextField
                          size="md"
                          margin="dense"
                          fullWidth
                          name="description"
                          label="Description"
                          variant="outlined"
                          value={values.description}
                          onChange={handleChange}
                          error={errors.description ? true : false}
                          helperText={errors.description}
                        /> */}
                      </Grid>

                      <Grid item xs={12} md={6}>
                        <FormControl>
                          <FormLabel>Image</FormLabel>
                          <Button
                            component="label"
                            variant="outlined"
                            starticon={<UploadFileIcon />}
                            size={"sm"}
                          >
                            Upload Image
                            <input
                              type="file"
                              accept="image/*"
                              hidden
                              onChange={(e) =>
                                setFieldValue("image", e.currentTarget.files[0])
                              }
                            />
                          </Button>
                        </FormControl>
                        <Box>{values?.image?.name}</Box>
                      </Grid>

                      <Grid item xs={12} md={12}>
                        <Stack
                          direction={"row"}
                          justifyContent={"end"}
                          alignItems={"center"}
                          spacing={2}
                        >
                          <SaveButton />
                          <CancelButton
                            onClick={() => hideAndClearSubCategoryDailog()}
                          />
                        </Stack>
                      </Grid>
                    </Grid>
                  </Form>
                )}
              </Formik>
            </Box>
          </Sheet>
        </Modal>
      </>

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}

export default SubCategoryListPage;
