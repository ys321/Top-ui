import { useRef } from "react";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import { useProductData } from "src/Hooks/useProductData";
import { EditText } from "src/components/EditText";
import {
  Box,
  Grid,
  Stack,
  Alert,
  Button,
  TextField,
  Card,
  Typography,
  Chip,
} from "@mui/joy";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";

import { Model } from "src/components";
import { PageLoader } from "src/components/PageLoader/PageLoader";

import { VendorDropdown } from "src/components/Dropdown/VendorDropdown";
import { ProductDropdown } from "src/components/Dropdown/ProductDropdown";
import {
  usePurchaseOrder,
  usePurchaseOrderEntries,
} from "src/pages/inventory/PurchaseOrders/usePurchaseOrder";

import { PurchaseOrderService } from "src/services/api/PurchaseOrderService";
import SaveButton from "src/components/Button/SaveButton";
import MainButton from "src/components/Button/MainButton";
import CancelButton from "src/components/Button/CancelButton";

function PurchaseOrderForm() {
  let dataObj = null;

  let materialEntiresDialogRef = useRef(null);

  const products = useProductData();

  /* load and process data from database on the same page if it's load with purchase order id */
  const { purchase_order_id } = useParams();
  let purchaseOrderId = purchase_order_id;

  const { isLoading, refetch } = useQuery(
    ["getPurchaseOrder"],
    async () => {
      if (purchase_order_id) {
        return await PurchaseOrderService.get(purchaseOrderId);
      }
      return null;
    },
    {
      staleTime: 0,
      onSuccess: (response) => {
        if (response) {
          dataObj = {
            ...response.data,
            vendor: response.data.vendor.id,
            entries: [],
          };

          for (const entry of response.data.entries) {
            dataObj.entries.push({
              ...entry,
              product: entry.product.id,
            });
          }

          setValues({
            ...dataObj,
            action: "update",
          });
        }
      },
    }
  );

  const onSuccessSave = (id) => {
    purchaseOrderId = id;
    refetch();
  };

  const { formik, onSave } = usePurchaseOrder({
    onSuccess: onSuccessSave,
    dataObj: dataObj,
  });
  const { values, errors, setValues } = formik;

  const { formikForEntires, onEntrySave } = usePurchaseOrderEntries({
    onSuccess: () => {
      // pushing entry values to main form after success
      // note: does not require any api call for the same

      // find the object if it's already exists in main array then just update values
      // rather then pusing it

      const findIndex = values.entries.findIndex(
        (entry) => entry.product === formikForEntires.values.product
      );

      if (findIndex !== -1) {
        // if index -1 means entry available then just update it
        values.entries[findIndex] = formikForEntires.values;
      } else {
        // otherwise push the new object
        values.entries.push(formikForEntires.values);
      }

      // once entry added just reset the form, so user can put new values on the same
      formikForEntires.resetForm();
    },
    dataObj: null,
  });

  const inputHandler = (e) => {
    const { name, value } = e.target;

    setValues({
      ...values,
      [name]: value,
    });
  };

  // handling material entries values
  const inputHandlerEntries = (e) => {
    const { name, value } = e.target;

    formikForEntires.setValues({
      ...formikForEntires.values,
      [name]: value,
    });
  };

  const removeEntry = (index) => {
    values.entries.splice(index, 1);
    setValues({ ...values });
  };

  const getProductName = (product) => {
    const found = products.find((p) => p.id === product);

    if (found) {
      return found["name"];
    }
    return "";
  };

  if (isLoading) {
    return <PageLoader pageMessage={"Loading Purchase Order Data..."} />;
  }

  return (
    <>
      <Box margin={2}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={12}>
            <Stack
              direction={"row"}
              justifyContent={"space-between"}
              alignItems={"center"}
            >
              <Typography level={"h4"}>
                Purchase Order {values?.po_number && values?.po_number}
              </Typography>
              <SaveButton onClick={onSave} />
            </Stack>
          </Grid>

          <Grid item xs={12} md={3}>
            <VendorDropdown
              props={{
                name: "vendor",
                placeholder: "Select Vendor",
                size: "md",
                value: values.vendor,
                onChange: (e) => inputHandler(e),
                error: errors.vendor,
              }}
              label={"Send Purchase Order To"}
              helperText={errors.vendor}
            />
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="contact_person"
              placeholder="Name"
              onChange={(e) => inputHandler(e)}
              value={values.contact_person}
              error={errors.contact_person ? true : false}
              helpertext={errors.contact_person}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              name="contact_person"
              label="Contact Person"
              variant="outlined"
              value={values.contact_person}
              onChange={(e) => inputHandler(e)}
              error={errors.contact_person ? true : false}
              helperText={errors.contact_person}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="mobile_no"
              placeholder="Mobile No."
              onChange={(e) => inputHandler(e)}
              value={values.mobile_no}
              error={errors.mobile_no ? true : false}
              helpertext={errors.mobile_no}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              name="mobile_no"
              label="Mobile No."
              type={"number"}
              variant="outlined"
              value={values.mobile_no}
              onChange={(e) => inputHandler(e)}
              error={errors.mobile_no ? true : false}
              helperText={errors.mobile_no}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="email"
              placeholder="Email"
              onChange={(e) => inputHandler(e)}
              value={values.email}
              error={errors.email ? true : false}
              helpertext={errors.email}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Email"
              name="email"
              type={"email"}
              variant="outlined"
              value={values.email}
              onChange={(e) => inputHandler(e)}
              error={errors.email ? true : false}
              helperText={errors.email}
            /> */}
          </Grid>

          <Grid item xs={12} md={12}>
            <EditText
              name="remark"
              placeholder="Remarks"
              onChange={(e) => inputHandler(e)}
              value={values.remark}
              error={errors.remark ? true : false}
              helpertext={errors.remark}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              name="remark"
              label="Remarks"
              variant="outlined"
              onChange={(e) => inputHandler(e)}
              error={errors.remarks ? true : false}
              helperText={errors.remarks}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="sub_total"
              placeholder="Sub Total"
              onChange={(e) => inputHandler(e)}
              value={values.sub_total}
              error={errors.sub_total ? true : false}
              helpertext={errors.sub_total}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Sub Total"
              type={"number"}
              name="sub_total"
              variant="outlined"
              value={values.sub_total}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.sub_total ? true : false}
              helperText={errors.sub_total}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="total"
              placeholder="Total"
              onChange={(e) => inputHandler(e)}
              value={values.total}
              error={errors.total ? true : false}
              helpertext={errors.total}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Total"
              type={"number"}
              name="total"
              variant="outlined"
              value={values.total}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.total ? true : false}
              helperText={errors.total}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="packing_forwarding"
              placeholder="Packing & Forwarding"
              onChange={(e) => inputHandler(e)}
              value={values.packing_forwarding}
              error={errors.packing_forwarding ? true : false}
              helpertext={errors.packing_forwarding}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Packing & Forwarding"
              type={"number"}
              name="packing_forwarding"
              variant="outlined"
              value={values.packing_forwarding}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.packing_forwarding ? true : false}
              helperText={errors.packing_forwarding}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="other_charge"
              placeholder="Other Charges"
              onChange={(e) => inputHandler(e)}
              value={values.other_charge}
              error={errors.other_charge ? true : false}
              helpertext={errors.other_charge}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Other Charges"
              type={"number"}
              name="other_charge"
              variant="outlined"
              value={values.other_charge}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.other_charge ? true : false}
              helperText={errors.other_charge}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="frieght_charge"
              placeholder="Frieght"
              onChange={(e) => inputHandler(e)}
              value={values.frieght_charge}
              error={errors.frieght_charge ? true : false}
              helpertext={errors.frieght_charge}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Frieght"
              type={"number"}
              name="frieght_charge"
              variant="outlined"
              value={values.frieght_charge}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.frieght_charge ? true : false}
              helperText={errors.frieght_charge}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="insurance_amount"
              placeholder="Insurance"
              onChange={(e) => inputHandler(e)}
              value={values.insurance_amount}
              error={errors.insurance_amount ? true : false}
              helpertext={errors.insurance_amount}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              id="insurance_amount"
              label="Insurance"
              type={"number"}
              name="insurance_amount"
              variant="outlined"
              value={values.insurance_amount}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.insurance_amount ? true : false}
              helperText={errors.insurance_amount}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="load_unload_charge"
              placeholder="Load & Unloading"
              onChange={(e) => inputHandler(e)}
              value={values.load_unload_charge}
              error={errors.load_unload_charge ? true : false}
              helpertext={errors.load_unload_charge}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Load & Unloading"
              type={"number"}
              name="load_unload_charge"
              variant="outlined"
              value={values.load_unload_charge}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.load_unload_charge ? true : false}
              helperText={errors.load_unload_charge}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="central_tax"
              placeholder="Central Tax"
              onChange={(e) => inputHandler(e)}
              value={values.central_tax}
              error={errors.central_tax ? true : false}
              helpertext={errors.central_tax}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Central Tax"
              type={"number"}
              name="central_tax"
              variant="outlined"
              value={values.central_tax}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.central_tax ? true : false}
              helperText={errors.central_tax}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="state_tax"
              placeholder="State Tax"
              onChange={(e) => inputHandler(e)}
              value={values.state_tax}
              error={errors.state_tax ? true : false}
              helpertext={errors.state_tax}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="State Tax"
              type={"number"}
              name="state_tax"
              variant="outlined"
              value={values.state_tax}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.state_tax ? true : false}
              helperText={errors.state_tax}
            /> */}
          </Grid>

          <Grid item xs={12} md={3}>
            <EditText
              name="discount"
              placeholder="Discount"
              onChange={(e) => inputHandler(e)}
              value={values.discount}
              error={errors.discount ? true : false}
              helpertext={errors.discount}
            />
            {/* <TextField
              size="md"
              margin="dense"
              fullWidth
              label="Discount"
              type={"number"}
              name="discount"
              variant="outlined"
              value={values.discount}
              onChange={(e) => {
                inputHandler(e);
              }}
              error={errors.discount ? true : false}
              helperText={errors.discount}
            /> */}
          </Grid>

          <Grid item md={12} xs={12}>
            <Stack
              spacing={2}
              alignItems={"center"}
              direction={"row"}
              justifyContent={"space-between"}
            >
              {errors.entries && (
                <Alert
                  variant="outlined"
                  color={"danger"}
                  style={{ width: "80%" }}
                >
                  {errors.entries}
                </Alert>
              )}

              <MainButton
                name={"Add Products"}
                onClick={() => {
                  materialEntiresDialogRef.current?.open();
                }}
              />
            </Stack>
          </Grid>

          {values.entries.map((entry, index) => {
            return (
              <Grid item md={3} xs={12} key={index}>
                <Card
                  variant="outlined"
                  row
                  sx={{
                    "&:hover": {
                      boxShadow: "md",
                      borderColor: "neutral.outlinedHoverBorder",
                      cursor: "pointer",
                    },
                  }}
                >
                  <Stack sx={{ width: "100%" }}>
                    <Stack
                      direction={"row"}
                      alignItems={"center"}
                      justifyContent={"space-between"}
                      mb={2}
                    >
                      <Typography level="h2" fontSize="lg" mb={0.5}>
                        {getProductName(entry?.product)}
                      </Typography>
                      <Stack direction={"row"} spacing={1}>
                        <Button
                          aria-label="remove"
                          variant="soft"
                          color="info"
                          size="sm"
                          onClick={() => {
                            materialEntiresDialogRef.current?.open();
                            formikForEntires.setValues({ ...entry });
                          }}
                        >
                          <EditIcon />
                        </Button>
                        <Button
                          aria-label="remove"
                          variant="soft"
                          color="danger"
                          size="sm"
                          onClick={() => {
                            removeEntry(index);
                          }}
                        >
                          <DeleteIcon />
                        </Button>
                      </Stack>
                    </Stack>
                    <div
                      style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}
                    >
                      <Chip
                        variant="outlined"
                        color="primary"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Ordered Quantity {entry?.ordered_qty}
                      </Chip>
                      <Chip
                        variant="outlined"
                        color="info"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Basic Rate {entry?.basic_rate}
                      </Chip>
                      <Chip
                        variant="outlined"
                        color="info"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Discount {entry?.discount}
                      </Chip>
                      <Chip
                        variant="outlined"
                        color="success"
                        size="sm"
                        sx={{ pointerEvents: "none" }}
                      >
                        Amount {entry?.amount}
                      </Chip>
                      {entry?.extra_details && (
                        <Chip
                          variant="outlined"
                          color="warning"
                          size="sm"
                          sx={{ pointerEvents: "none" }}
                        >
                          Remarks: {entry?.extra_details}
                        </Chip>
                      )}
                    </div>
                  </Stack>
                </Card>
              </Grid>
            );
          })}
        </Grid>

        <Model
          fullWidth
          maxWidth={"lg"}
          ref={materialEntiresDialogRef}
          onClose={() => {
            materialEntiresDialogRef.current?.close();
            formikForEntires.resetForm();
          }}
          title={"Purchase Order Product Record"}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <ProductDropdown
                props={{
                  name: "product",
                  placeholder: "Select Product",
                  value: formikForEntires.values.product,
                  onChange: (e) => inputHandlerEntries(e),
                  error: formikForEntires.errors.product,
                }}
                label={"Select Product Item To Add Purchase Orde"}
                helperText={formikForEntires.errors.product}
              />
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="ordered_qty"
                placeholder="Order Quantiry"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.ordered_qty}
                error={formikForEntires.errors.ordered_qty ? true : false}
                helperText={formikForEntires.errors.ordered_qty}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="ordered_qty"
                label="Order Quantiry"
                variant="outlined"
                value={formikForEntires.values.ordered_qty}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.ordered_qty ? true : false}
                helperText={formikForEntires.errors.ordered_qty}
              /> */}
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="basic_rate"
                placeholder="Basic Rate"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.basic_rate}
                error={formikForEntires.errors.basic_rate ? true : false}
                helperText={formikForEntires.errors.basic_rate}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="basic_rate"
                label="Basic Rate"
                variant="outlined"
                value={formikForEntires.values.basic_rate}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.basic_rate ? true : false}
                helperText={formikForEntires.errors.basic_rate}
              /> */}
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="discount"
                placeholder="Discount"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.discount}
                error={formikForEntires.errors.discount ? true : false}
                helperText={formikForEntires.errors.discount}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="discount"
                label="Discount"
                variant="outlined"
                value={formikForEntires.values.discount}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.discount ? true : false}
                helperText={formikForEntires.errors.discount}
              /> */}
            </Grid>
            <Grid item xs={12} md={2}>
              <EditText
                name="amount"
                placeholder="Amount"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.amount}
                error={formikForEntires.errors.amount ? true : false}
                helperText={formikForEntires.errors.amount}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="amount"
                label="Amount"
                variant="outlined"
                value={formikForEntires.values.amount}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.amount ? true : false}
                helperText={formikForEntires.errors.amount}
              /> */}
            </Grid>
            <Grid item xs={12} md={12}>
              <EditText
                name="extra_details"
                placeholder="Remarks"
                onChange={(e) => inputHandlerEntries(e)}
                value={formikForEntires.values.extra_details}
                error={formikForEntires.errors.extra_details ? true : false}
                helperText={formikForEntires.errors.extra_details}
              />
              {/* <TextField
                margin="dense"
                fullWidth
                name="extra_details"
                label="Remarks"
                variant="outlined"
                value={formikForEntires.values.extra_details}
                onChange={(e) => inputHandlerEntries(e)}
                error={formikForEntires.errors.extra_details ? true : false}
                helperText={formikForEntires.errors.extra_details}
              /> */}
            </Grid>
            <Grid item xs={12} md={12}>
              <Stack spacing={2} direction={"row"} justifyContent={"flex-end"}>
                <CancelButton
                  onClick={() => {
                    materialEntiresDialogRef.current?.close();
                    formikForEntires.resetForm();
                  }}
                />
                <SaveButton onClick={onEntrySave} disabled={formikForEntires.values.ordered_qty < 1} />
              </Stack>
            </Grid>
          </Grid>
        </Model>
      </Box>
    </>
  );
}

export { PurchaseOrderForm };
