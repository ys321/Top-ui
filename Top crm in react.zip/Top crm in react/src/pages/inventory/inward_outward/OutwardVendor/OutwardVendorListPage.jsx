import _ from "lodash";

import {
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Link,
  Paper,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

import {
  StyledTableCell,
  StyledTableRow,
  Transition,
} from "src/components/Table/TableStyle";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { useQuery } from "@tanstack/react-query";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import DeleteIcon from "@mui/icons-material/Delete";
import TOPButton from "src/components/Button/TopButton";
import { useDispatch } from "react-redux";
import { deleteOutwardFromVendor } from "./useOutwardVendor";
import MainButton from "src/components/Button/MainButton";

function OutwardVendorListPage() {
  const [outwardVendor, setOutwardVendor] = useState([]);
  const [currentRow, setCurrentRow] = useState();
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { isLoading: OutwardVendorLoading, refetch: outwardVendorRefetch } =
    useQuery(
      ["getAllOutwardVendor"],
      async () => {
        return await InwardOutwardService.OutwardVendor.getAll();
      },
      {
        onSuccess: (response) => {
          console.log(response.data);
          setOutwardVendor(response.data);
        },
        staleTime: 0,
      }
    );

  function deleteRow() {
    dispatch(deleteOutwardFromVendor({ currentRow }))
      .unwrap()
      .then((res) => {
        handleClose();
        setTimeout(() => {
          outwardVendorRefetch();
        }, 500);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  if (OutwardVendorLoading) {
    return <>Loading...</>;
  }
  function addOutwardFromVendor() {
    navigate(`/inventory/outward-vendor/form`);
  }

  return (
    <>
      <Grid container spacing={1} padding={2}>
        <Grid item xs={12} md={12}>
          <MainButton name={"ADD NEW"} onClick={addOutwardFromVendor} />
        </Grid>
        <Grid item xs={12} md={12}>
          {outwardVendor && outwardVendor?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align={"center"}>ID</StyledTableCell>
                      <StyledTableCell align={"center"}>Branch</StyledTableCell>
                      <StyledTableCell align={"center"}>Vendor</StyledTableCell>
                      <StyledTableCell align={"center"}>Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {outwardVendor?.map((vendor, index) => {
                      return (
                        <StyledTableRow key={index}>
                          <StyledTableCell align={"center"}>
                            <Link
                              href={`/inventory/outward-vendor/:outward_vendor_id`.replace(
                                ":outward_vendor_id",
                                vendor.id
                              )}
                            >
                              {vendor.id}
                            </Link>
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {vendor.branch?.name}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {vendor.vendor?.name}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            <IconButton
                              aria-label="delete"
                              size="large"
                              color="error"
                              onClick={() => {
                                handleClickOpen();
                                setCurrentRow(vendor);
                              }}
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        aria-describedby="outward-vendor-delete-confirm-dailog"
      >
        <DialogTitle>{"Delete Outward From Vendor"}</DialogTitle>
        <DialogContent>
          Are you sure want to delete Outward From Vendor <br />{" "}
          <Chip label={currentRow?.id} />
        </DialogContent>
        <DialogActions>
          <TOPButton onClick={deleteRow} variant="danger" text={"Yes"} />
          <TOPButton onClick={handleClose} variant="info" text={"No"} />
        </DialogActions>
      </Dialog>
    </>
  );
}

export default OutwardVendorListPage;
