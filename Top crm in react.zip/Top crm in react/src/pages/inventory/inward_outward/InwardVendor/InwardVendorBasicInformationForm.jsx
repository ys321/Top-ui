import React, { useState, useRef } from "react";

import moment from "moment-timezone";
import _ from "lodash";
import { Box } from "@mui/material";
import { EditText } from "src/components/EditText";
import { Typography, TextField, Chip, ChipDelete, Grid, Stack } from "@mui/joy";
import { BaseCard, Dialog } from "src/components";
import { AddButton } from "src/components";

import { LocationDropdown } from "src/components/Dropdown/LocationDropdown";
import { PurchaseOrderService } from "src/services/api/PurchaseOrderService";
import { createInwardFromVendor, inwardSchema, updateInwardFromVendor } from "./useInwardVendor";
import { LocationComponent } from "src/components";

import { FieldArray, Form, Formik, ErrorMessage, getIn } from "formik";
import { VendorDropdown } from "src/components/Dropdown/VendorDropdown";
import { useDispatch } from "react-redux";
import { useProductData } from "src/Hooks/useProductData";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import SaveButton from "src/components/Button/SaveButton";

function InwardVendorBasicInformationForm() {
  const formRef = useRef();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  let productLocationDialogRef = useRef(null);

  const [purchaseOrder, setPurchaseOrder] = useState({});
  const [currentEntry, setCurrentEntry] = useState();
  const [inwardVendorAction, setInwardVendorAction] = useState("CREATE");

  // load and proccess data from database on the basis of inward_vendor_id
  const { inward_vendor_id } = useParams();

  const { isLoading, refetch } = useQuery(['getInwardFromVendor'], async () => {
    if (inward_vendor_id) {
      return await InwardOutwardService.InwardVendor.get(inward_vendor_id);
    } return null;
  }, {
    staleTime: 0,
    onSuccess: (response) => {
      if (response) {
        console.log(response.data);
        formRef.current.values.entries.length = 0;
        formRef.current.values.branch = '';

        // assign data to formik
        formRef?.current?.setValues({
          ...formRef?.current?.values
        })

        // assing Data based on request
        formRef.current.values.date = response.data.date;
        if (response.data.vendor) {
          formRef.current.values.vendor = response.data.vendor.id;
        }
        if (response.data.branch) {
          formRef.current.values.branch = response.data.branch.id;
        }
        formRef.current.values.purchase_order = response.data.purchase_order;
        formRef.current.values.site_name = response.data.site_name;
        formRef.current.values.transport = response.data.transport;
        formRef.current.values.lr_number = response.data.lr_number;
        formRef.current.values.lr_date = response.data.lr_date;
        formRef.current.values.received_date = response.data.received_date;
        formRef.current.values.supplier_bill_no = response.data.supplier_bill_no;
        formRef.current.values.supplier_bill_date = response.data.supplier_bill_date;

        for (const entry of response.data?.entries) {
          let temp = [];

          entry?.inventory_location.forEach(loc => {
            temp.push({
              alias: loc?.alias,
              branch: loc?.branch?.id,
              floor: loc?.floor.id,
              section: loc?.section?.id,
              rack: loc?.rack?.id,
              shelf: loc?.shelf?.id,
              bin: loc?.bin?.id,
              qty: loc?.qty,
            })
          })

          formRef?.current?.values?.entries.push({
            product: entry?.product?.id,
            order_qty: entry?.order_qty,
            rate_per_qty: entry?.rate_per_qty,
            received_qty: entry?.received_qty,
            amount: entry?.amount,
            branch: formRef?.current?.values?.branch,
            specification: false,
            inventory_location: temp
          })
        }


        formRef?.current?.setValues({
          ...formRef?.current?.values
        })
        setInwardVendorAction("UPDATE")
      }
    }
  })

  const distributeProduct = (obj) => {
    const indexOf = formRef.current.values.entries[
      currentEntry.index
    ]?.inventory_location?.findIndex((l) => l?.alias === obj?.alias);

    if (indexOf === -1) {
      formRef?.current?.values?.entries[
        currentEntry.index
      ]?.inventory_location.push(obj);
    } else {
      formRef.current.values.entries[currentEntry.index].inventory_location[
        indexOf
      ] = obj;
    }
    console.log(formRef.current.values.entries);

    productLocationDialogRef.current?.close();
    formRef.current.setValues({ ...formRef.current.values });
  };

  const addProductLocation = ({ index, entry }) => {
    productLocationDialogRef.current?.open();
    setCurrentEntry({
      index: index,
      entry: entry,
    });
  };

  const calculateAvailableProductToDistribute = () => {
    const received_qty =
      formRef.current.values.entries[currentEntry.index].received_qty;
    let remaningQuantity = received_qty;
    for (const location of formRef.current.values.entries[currentEntry.index]
      .inventory_location) {
      // todo : diduct values for each qty
      remaningQuantity -= location.qty;
    }

    return remaningQuantity;
  };

  function saveInwardFromVendor(values) {

    switch (inwardVendorAction) {
      case "CREATE":
        dispatch(createInwardFromVendor({ values }))
          .unwrap()
          .then((res) => {
            console.log("data Submitted");
            navigate(`/inventory/inward-vendor`)
          }).catch((e) => {
            console.log(e);
          })
        break;
      case "UPDATE":
        dispatch(updateInwardFromVendor({ values, inward_vendor_id }))
          .unwrap()
          .then((res) => {
            console.log("data Updated");
            navigate(`/inventory/inward-vendor`)
          }).catch((e) => {
            console.log(e);
          })

      default:
        break;
    }
  }

  const products = useProductData();

  const getProductName = (product) => {
    const found = products.find((p => p.id === product));
    if (found) {
      return found['name']
    } return ''
  }
  const getProductCode = (product) => {
    const found = products.find((p => p.id === product));
    if (found) {
      return found['code']
    } return ''
  }

  return (
    <>
      <Box margin={2}>
        <Formik
          initialValues={{
            date: moment().utc().tz(moment.tz.guess()).format("YYYY-MM-DD"),
            branch: "",
            vendor: "",
            purchase_order: "",
            po_date: moment().utc().tz(moment.tz.guess()).format("YYYY-MM-DD"),
            site_name: "",
            transport: "",
            lr_number: "",
            lr_date: moment().utc().tz(moment.tz.guess()).format("YYYY-MM-DD"),
            received_date: moment()
              .utc()
              .tz(moment.tz.guess())
              .format("YYYY-MM-DD"),
            supplier_bill_no: "",
            supplier_bill_date: moment()
              .utc()
              .tz(moment.tz.guess())
              .format("YYYY-MM-DD"),
            remarks: "",
            entries: [],
          }}
          innerRef={formRef}
          onSubmit={async (values) => {
            saveInwardFromVendor(values);
            console.log(values);
          }}
          validationSchema={inwardSchema}
        >
          {({
            values,
            errors,
            handleChange,
            setValues,
            touched,
          }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Typography level={"h4"}>Inward form Vendor</Typography>
                    <SaveButton />
                  </Stack>
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="date"
                    placeholder="Inward Date"
                    onChange={handleChange}
                    value={values.date}
                    error={errors.date ? true : false}
                    helpertext={errors.date}
                  />
                  {/* <TextField
                    type="date"
                    margin="dense"
                    fullWidth
                    name="date"
                    label="Inward Date"
                    variant="outlined"
                    value={values.date}
                    onChange={handleChange}
                    error={errors.date ? true : false}
                    helperText={errors.date}
                  /> */}
                </Grid>

                <Grid item xs={12} md={3}>
                  <VendorDropdown
                    props={{
                      name: "vendor",
                      placeholder: "Select Vendor",
                      size: "md",
                      onChange: handleChange,
                      value: values.vendor,
                      disabled: true
                    }}
                    label={"Select Vendor"}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <LocationDropdown
                    props={{
                      name: "branch",
                      placeholder: "Select Branch",
                      size: "md",
                      value: values.branch,
                      onChange: handleChange,
                      error: errors.branch,
                    }}
                    label={"Select Branch"}
                    helperText={errors.branch}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="purchase_order"
                    label="Purchase Order"
                    variant="outlined"
                    value={values.purchase_order}
                    onChange={handleChange}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        if (e.target.value) {
                          (async () => {
                            const response = await PurchaseOrderService.getByPONo(e.target.value);

                            // clear data on refetch purchase order
                            values.entries.length = 0;
                            values.vendor = '';

                            if (response.data?.results instanceof Array
                              && response.data?.results.length > 0) {

                              setValues({ ...values });

                              setPurchaseOrder(response.data?.results[0]);

                              // assign entries based on purchase order
                              for (const entry of response.data?.results[0]?.entries) {
                                values.entries.push({
                                  product: entry?.product?.id,
                                  order_qty: entry?.ordered_qty,
                                  rate_per_qty: entry?.basic_rate,
                                  received_qty: 0,
                                  amount: entry?.amount,
                                  branch: values?.branch,
                                  specification: false,
                                  inventory_location: [],
                                });
                              }

                              // assign vendor based on purchase order
                              values.vendor = response.data?.results[0]?.vendor?.id;
                              setValues({ ...values });
                            }
                          })();
                        }
                      }
                    }}
                    error={errors.purchase_order ? true : false}
                    helperText={errors.purchase_order}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="po_date"
                    label="Purchase Order Date"
                    variant="outlined"
                    value={values.po_date} // set purchase order date
                    onChange={handleChange}
                    type="date"

                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="site_name"
                    placeholder="Site Name / Job No."
                    onChange={handleChange}
                    value={values.site_name}
                    error={errors.site_name ? true : false}
                    helpertext={errors.site_name}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="site_name"
                    label="Site Name / Job No."
                    variant="outlined"
                    value={values.site_name}
                    onChange={handleChange}
                    error={errors.site_name ? true : false}
                    helperText={errors.site_name}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="transport"
                    placeholder="Transport"
                    onChange={handleChange}
                    value={values.transport}
                    error={errors.transport ? true : false}
                    helpertext={errors.transport}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="transport"
                    label="Transport"
                    variant="outlined"
                    value={values.transport}
                    onChange={handleChange}
                    error={errors.transport ? true : false}
                    helperText={errors.transport}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="lr_number"
                    placeholder="LR No."
                    onChange={handleChange}
                    value={values.lr_number}
                    error={errors.lr_number ? true : false}
                    helpertext={errors.lr_number}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="lr_number"
                    label="LR No."
                    variant="outlined"
                    value={values.lr_number}
                    onChange={handleChange}
                    error={errors.lr_number ? true : false}
                    helperText={errors.lr_number}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="lr_date"
                    placeholder="LR Date"
                    onChange={handleChange}
                    value={values.lr_date}
                    error={errors.lr_date ? true : false}
                    helpertext={errors.lr_date}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="lr_date"
                    label="LR Date"
                    variant="outlined"
                    value={values.lr_date}
                    onChange={handleChange}
                    type="date"
                    error={errors.lr_date ? true : false}
                    helperText={errors.lr_date}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="received_date"
                    placeholder="Received Date"
                    onChange={handleChange}
                    value={values.received_date}
                    error={errors.received_date ? true : false}
                    helpertext={errors.received_date}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="received_date"
                    label="Received Date"
                    variant="outlined"
                    value={values.received_date}
                    onChange={handleChange}
                    type="date"
                    error={errors.received_date ? true : false}
                    helperText={errors.received_date}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="supplier_bill_no"
                    placeholder="Supplier Bill No."
                    onChange={handleChange}
                    value={values.supplier_bill_no}
                    error={errors.supplier_bill_no ? true : false}
                    helpertext={errors.supplier_bill_no}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="supplier_bill_no"
                    label="Supplier Bill No."
                    variant="outlined"
                    value={values.supplier_bill_no}
                    onChange={handleChange}
                    error={errors.supplier_bill_no ? true : false}
                    helperText={errors.supplier_bill_no}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="supplier_bill_date"
                    placeholder="Supplier Bill Date"
                    onChange={handleChange}
                    value={values.supplier_bill_date}
                    error={errors.supplier_bill_date ? true : false}
                    helpertext={errors.supplier_bill_date}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="supplier_bill_date"
                    label="Supplier Bill Date"
                    variant="outlined"
                    value={values.supplier_bill_date}
                    onChange={handleChange}
                    type="date"
                    error={errors.supplier_bill_date ? true : false}
                    helperText={errors.supplier_bill_date}
                  /> */}
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="remarks"
                    placeholder="Remarks"
                    onChange={handleChange}
                    value={values.remarks}
                    error={errors.remarks ? true : false}
                    helpertext={errors.remarks}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="remarks"
                    label="Remarks"
                    variant="outlined"
                    value={values.remarks}
                    onChange={handleChange}
                    error={errors.remarks ? true : false}
                    helperText={errors.remarks}
                  /> */}
                </Grid>
              </Grid>
              <Grid container spacing={1} padding={1}>
                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Typography level={"h6"}>Product Detail</Typography>
                  </Stack>
                </Grid>
                <FieldArray name="entries">
                  {({ insert, remove, push }) => (
                    <>
                      {values.entries.length > 0 &&
                        values.entries.map((entry, index) => (
                          <Grid item md={3} xs={12} key={index}>
                            <BaseCard variant="outlined" row>
                              <Stack
                                sx={{ width: "100%" }}
                                spacing={2}
                                direction={"column"}
                              >
                                <Stack
                                  direction={"row"}
                                  alignItems={"center"}
                                  justifyContent={"space-between"}
                                  flexWrap={"wrap"}
                                  mb={2}
                                >
                                  <Typography level="h2" fontSize="lg" mb={0.5}>
                                    {getProductName(entry?.product)}
                                    {/* {entry?.product.name} */}
                                  </Typography>
                                  <Stack direction={"row"} spacing={1}>
                                    <AddButton
                                      variant="soft"
                                      size="sm"
                                      disabled={
                                        // recevied_qty < 1 means we can not disribute
                                        values.entries[index]?.received_qty <
                                        1 ||
                                        // recevied_qty > ordered_qty means invaid entry, then after we can not distribute
                                        values.entries[index]?.received_qty >
                                        values.entries[index]?.order_qty
                                      }
                                      onClick={() => {
                                        addProductLocation({
                                          index: index,
                                          entry: entry,
                                        });
                                      }}
                                    >
                                      distribute
                                    </AddButton>
                                  </Stack>
                                </Stack>
                                <div
                                  style={{
                                    display: "flex",
                                    flexWrap: "wrap",
                                    gap: "5px",
                                  }}
                                >
                                  <Chip
                                    variant="outlined"
                                    color="primary"
                                    size="sm"
                                    sx={{ pointerEvents: "none" }}
                                  >
                                    {getProductCode(entry?.product)}
                                    {/* {entry?.product.code} */}
                                  </Chip>

                                  <Chip
                                    variant="outlined"
                                    color="info"
                                    size="sm"
                                    sx={{ pointerEvents: "none" }}
                                  >
                                    Order Qty : {entry.order_qty}
                                  </Chip>

                                  <TextField
                                    margin="dense"
                                    fullWidth
                                    name={`entries[${index}].received_qty`}
                                    label="Received Quantity"
                                    variant="soft"
                                    type="number"
                                    value={values.entries[index]?.received_qty}
                                    onChange={handleChange}
                                    size="sm"
                                    error={
                                      getIn(
                                        errors,
                                        `entries[${index}].received_qty`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries[${index}].received_qty`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries[${index}].received_qty`}
                                      />
                                    }
                                  />

                                  <TextField
                                    margin="dense"
                                    fullWidth
                                    name={`entries.${index}.rate_per_qty`}
                                    label="Basic Rate"
                                    variant="soft"
                                    type="number"
                                    value={values.entries[index]?.rate_per_qty}
                                    size="sm"
                                    onChange={handleChange}
                                    error={
                                      getIn(
                                        errors,
                                        `entries.${index}.rate_per_qty`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries.${index}.rate_per_qty`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries.${index}.rate_per_qty`}
                                      />
                                    }
                                  />
                                  <TextField
                                    size="sm"
                                    label="Basic Amount"
                                    name={`entries.${index}.amount`}
                                    type="number"
                                    value={values.entries[index]?.amount}
                                    variant="soft"
                                    onChange={handleChange}
                                    fullWidth
                                    margin="dense"
                                    error={
                                      getIn(
                                        errors,
                                        `entries.${index}.amount`
                                      ) &&
                                      getIn(touched, `entries.${index}.amount`)
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries.${index}.amount`}
                                      />
                                    }
                                  />
                                </div>

                                <FieldArray name="product_location">
                                  {({ remove: removeProductLocation }) => (
                                    <Stack
                                      spacing={1}
                                      direction={"column"}
                                      flexWrap
                                    >
                                      {entry?.inventory_location?.length >
                                        0 && (
                                          <>
                                            <Typography>
                                              Product Location
                                            </Typography>
                                            {entry?.inventory_location?.map(
                                              (location, idx) => {
                                                return (
                                                  <Chip
                                                    variant="outlined"
                                                    color="success"
                                                    key={idx}
                                                    onClick={() => {
                                                      console.log(
                                                        entry?.inventory_location
                                                      );
                                                    }}
                                                    endDecorator={
                                                      <ChipDelete
                                                        color="danger"
                                                        variant="solid"
                                                        onClick={() => {
                                                          // remove current index element
                                                          entry?.inventory_location?.splice(
                                                            idx,
                                                            1
                                                          );

                                                          // reset all values whatever it has to be remaning
                                                          setValues({
                                                            ...values,
                                                          });

                                                        }}
                                                      />
                                                    }
                                                  >
                                                    {location?.alias}
                                                    <Typography
                                                      variant="plain"
                                                      color="primary"
                                                      fontWeight={800}
                                                      sx={{
                                                        marginLeft: 1,
                                                        padding: 0,
                                                      }}
                                                    >
                                                      Qty : {location?.quantity || location?.qty}
                                                    </Typography>
                                                  </Chip>
                                                );
                                              }
                                            )}
                                          </>
                                        )}
                                    </Stack>
                                  )}
                                </FieldArray>
                              </Stack>
                            </BaseCard>
                          </Grid>
                        ))}
                    </>
                  )}
                </FieldArray>
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>

      <Dialog ref={productLocationDialogRef} title={"Distribute Your Product"}>
        <LocationComponent
          defaultLocation={formRef.current?.values.branch}
          onSave={distributeProduct}
          availableProductToDistribute={calculateAvailableProductToDistribute}
        />
      </Dialog>
    </>
  );
}
export default InwardVendorBasicInformationForm;
