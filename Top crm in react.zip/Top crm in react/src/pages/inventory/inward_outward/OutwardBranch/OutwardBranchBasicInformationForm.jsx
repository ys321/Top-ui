import React, { useState, useRef } from "react";

import moment from "moment-timezone";
import _ from "lodash";
import { Box } from "@mui/material";
import { EditText } from "src/components/EditText";
import { Typography, TextField, Chip, ChipDelete, Grid, Stack } from "@mui/joy";
import { LocationDropdown } from "src/components/Dropdown/LocationDropdown";

import { FieldArray, Form, Formik, ErrorMessage, getIn } from 'formik';
import { BaseCard, Dialog, LocationComponent } from "src/components";
import { AddButton } from "src/components";

import { createOutwardFromBranch, outwardFromBranchSchema, updateOutwardFromBranch } from "./useOutwardBranch";
import { MaterialRequestService } from "src/services/api/MaterialRequestService";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { BaseDropdown } from "src/components/Dropdown/BaseDropdown";
import { useProductData } from "src/Hooks/useProductData";
import SaveButton from "src/components/Button/SaveButton";

const options = [
  {
    'id': 1,
    'name': 'PERSON'
  },
  {
    'id': 2,
    'name': 'TRANSPORT'
  },
  {
    'id': 3,
    'name': 'COURIER'
  },
  {
    'id': 4,
    'name': 'TRAVELLS'
  },

]

function OutwardBranchBasicInformationForm() {

  const formRef = useRef();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  let productLocationDialogRef = useRef(null);
  const [currentEntry, setCurrentEntry] = useState();
  const [materialrequest, setMaterialRequest] = useState();
  const [outwardBranchAction, setOutwardBranchAction] = useState("CREATE");

  const distributeProduct = (obj) => {
    const indexOf = formRef.current.values.entries[
      currentEntry.index
    ]?.inventory_location?.findIndex((l) => l?.alias === obj?.alias);

    if (indexOf === -1) {
      formRef?.current?.values?.entries[
        currentEntry.index
      ]?.inventory_location.push(obj);
    } else {
      formRef.current.values.entries[currentEntry.index].inventory_location[
        indexOf
      ] = obj;
    }

    console.log(formRef.current.values.entries);

    productLocationDialogRef.current?.close();
    formRef.current.setValues({ ...formRef.current.values });
  };

  const addProductLocation = ({ index, entry }) => {
    productLocationDialogRef.current?.open();
    setCurrentEntry({
      index: index,
      entry: entry,
    });
  };

  const calculateAvailableProductToDistribute = () => {
    const send_qty =
      formRef.current.values.entries[currentEntry.index].send_qty;
    let remaningQuantity = send_qty;
    for (const location of formRef.current.values.entries[currentEntry.index]
      .inventory_location) {
      // todo : diduct values for each qty
      remaningQuantity -= location.qty;
    }
    return remaningQuantity;
  };

  function saveOutwardBranch(values) {
    switch (outwardBranchAction) {
      case "CREATE":
        dispatch(createOutwardFromBranch({ values }))
          .unwrap()
          .then((res) => {
            console.log("data Submitted");
            // navigate(`${inward_outward_route_keys.inward_branch.all}`)
          })
        break;
      case "UPDATE":
        dispatch(updateOutwardFromBranch({ values }))
          .unwrap()
          .then((res) => {
            console.log("data updated");
            // navigate(`${inward_outward_route_keys.inward_vendor.all}`)
          })
          .catch((e) => {
            console.log(e);
          })
        break;

      default:
        break;
    }
  }

  const products = useProductData();

  const getProductName = (product) => {
    const found = products.find((p => p.id === product));
    if (found) {
      return found['name']
    } return ''
  }
  const getProductCode = (product) => {
    const found = products.find((p => p.id === product));
    if (found) {
      return found['code']
    } return ''
  }

  return (
    <>
      <Box margin={2}>
        <Formik
          initialValues={
            {
              date: moment().utc().tz(moment.tz.guess()).format('YYYY-MM-DD'),
              branch: '',
              material_request: '',
              recieved_type: '',
              person_name: '',
              lr_number: '',
              travells_name: '',
              remarks: '',
              entries: [],
            }
          }
          innerRef={formRef}
          onSubmit={async (values) => {
            alert('')
            saveOutwardBranch(values);
            console.log(values);
          }}
          validationSchema={outwardFromBranchSchema}
        >
          {({ values, errors, handleChange, setValues, touched }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Typography level={"h4"}>Outward From Branch</Typography>
                    <SaveButton />
                  </Stack>
                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="date"
                    placeholder="Inward Date"
                    onChange={handleChange}
                    value={values.date}
                  />
                  {/* <TextField
                    type="date"
                    margin="dense"
                    fullWidth
                    name="date"
                    label="Inward Date"
                    variant="outlined"
                    value={values.date}
                    onChange={handleChange}
                  /> */}
                </Grid>

                <Grid item xs={12} md={3}>
                  <LocationDropdown
                    props={{
                      name: "branch",
                      placeholder: "Select Branch",
                      size: "md",
                      onChange: handleChange,
                      value: values.branch,
                      disabled: true
                    }}
                    label={"Select Branch"}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="material_request"
                    label="Material Request"
                    variant="outlined"
                    value={values.material_request}
                    onChange={handleChange}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {

                        if (e.target.value) {
                          (async () => {
                            const response = await MaterialRequestService.getByMRNo(e.target.value);

                            if (response.data?.results instanceof Array && response.data?.results.length > 0) {

                              //clear data on refetch material Request
                              values.entries.length = 0;
                              setValues({ ...values });

                              setMaterialRequest(response.data.results[0]);

                              for (const entry of response.data?.results[0]?.entries) {
                                values.entries.push({
                                  product: entry?.product?.id,
                                  send_qty: 0,
                                  order_qty: entry?.ordered_qty,
                                  rate_per_qty: entry?.basic_rate,
                                  received_qty: 0,
                                  amount: entry?.amount,
                                  branch: values?.branch,
                                  specification: false,
                                  inventory_location: []
                                });
                              }

                              //assign location based on Material Request
                              values.branch = response.data?.results[0]?.branch?.id;
                              setValues({ ...values });
                            }
                          })();

                          console.log(values.entries)
                        }

                      }
                    }}
                    error={errors.material_request ? true : false}
                    helperText={errors.material_request}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <BaseDropdown
                    props={{
                      name: 'recieved_type',
                      onChange: handleChange,
                      value: values.recieved_type,
                    }}
                    options={options}
                    label={"Recieved Type"}
                    error={errors.recieved_type ? true : false}
                    helperText={errors.recieved_type}
                  />

                </Grid>
                <Grid item xs={12} md={3}>
                  <EditText
                    name="person_name"
                    placeholder="Person Name"
                    onChange={handleChange}
                    value={values.person_name}
                  />
                  {/* <TextField
                    id="person_name"
                    label="Person Name"
                    type="text"
                    fullWidth
                    variant="outlined"
                    name="person_name"
                    onChange={handleChange}
                    margin="dense"
                    disabled={values.recieved_type !== 1}
                  /> */}
                </Grid>

                <Grid item xs={12} md={3}>
                  <EditText
                    name="lr_number"
                    placeholder="LR No"
                    onChange={handleChange}
                    value={values.lr_number}
                  />
                  {/* <TextField
                    id="lr_number"
                    name="lr_number"
                    label="LR No"
                    type="text"
                    fullWidth
                    variant="outlined"
                    onChange={handleChange}
                    margin="dense"
                    disabled={values.recieved_type !== 2 && values.recieved_type !== 3}
                  /> */}
                </Grid>

                <Grid item xs={12} md={3}>
                  <EditText
                    name="travells_name"
                    placeholder="Travells name"
                    onChange={handleChange}
                    value={values.travells_name}
                  />
                  {/* <TextField
                    id=""
                    label="Travells name"
                    type="text"
                    fullWidth
                    variant="outlined"
                    name="travells_name"
                    onChange={handleChange}
                    margin="dense"
                    disabled={values.recieved_type !== 4}
                  /> */}
                </Grid>

                <Grid item xs={12} md={3}>
                  <EditText
                    name="remarks"
                    placeholder="Remarks"
                    onChange={handleChange}
                    value={values.remarks}
                    error={errors.remarks ? true : false}
                    helpertext={errors.remarks}
                  />
                  {/* <TextField
                    id="remakrs"
                    name="remarks"
                    label="Remarks"
                    type="text"
                    fullWidth
                    variant="outlined"
                    onChange={handleChange}
                    margin="dense"
                    error={errors.remarks ? true : false}
                    helperText={errors.remarks}
                  /> */}
                </Grid>
              </Grid>
              <Grid container spacing={1} padding={1}>
                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    <Typography level={"h6"}>Product Detail</Typography>
                  </Stack>
                </Grid>
                <FieldArray name="entries">
                  {({ insert, remove, push }) => (
                    <>
                      {values.entries.length > 0 &&
                        values.entries.map((entry, index) => (
                          <Grid item md={3} xs={12} key={index}>
                            <BaseCard variant="outlined" row>
                              <Stack
                                sx={{ width: "100%" }}
                                spacing={2}
                                direction={"column"}
                              >
                                <Stack
                                  direction={"row"}
                                  alignItems={"center"}
                                  justifyContent={"space-between"}
                                  flexWrap={"wrap"}
                                  mb={2}
                                >
                                  <Typography level="h2" fontSize="lg" mb={0.5}>
                                    {getProductName(entry?.product)}
                                    {/* {entry?.product.name} */}
                                  </Typography>
                                  <Stack direction={"row"} spacing={1}>
                                    <AddButton
                                      variant="soft"
                                      size="sm"
                                      disabled={
                                        // recevied_qty < 1 means we can not disribute
                                        values.entries[index]?.send_qty <
                                        1
                                        ||
                                        // recevied_qty > ordered_qty means invaid entry, then after we can not distribute
                                        values.entries[index]?.send_qty >
                                        values.entries[index]?.order_qty
                                      }
                                      onClick={() => {
                                        addProductLocation({
                                          index: index,
                                          entry: entry,
                                        });
                                      }}
                                    >
                                      distribute
                                    </AddButton>
                                  </Stack>
                                </Stack>
                                <div
                                  style={{
                                    display: "flex",
                                    flexWrap: "wrap",
                                    gap: "5px",
                                  }}
                                >
                                  <Chip
                                    variant="outlined"
                                    color="primary"
                                    size="sm"
                                    sx={{ pointerEvents: "none" }}
                                  >
                                    {getProductCode(entry?.product)}
                                    {/* {entry?.product.code} */}
                                  </Chip>

                                  <Chip
                                    variant="outlined"
                                    color="info"
                                    size="sm"
                                    sx={{ pointerEvents: "none" }}
                                  >
                                    Order Qty : {entry.order_qty}
                                  </Chip>

                                  <TextField
                                    margin="dense"
                                    fullWidth
                                    name={`entries[${index}].send_qty`}
                                    label="Send Quantity"
                                    variant="soft"
                                    type="number"
                                    value={values.entries[index]?.send_qty}
                                    onChange={handleChange}
                                    size="sm"
                                    error={
                                      getIn(
                                        errors,
                                        `entries[${index}].send_qty`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries[${index}].send_qty`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries[${index}].send_qty`}
                                      />
                                    }
                                  />

                                  <TextField
                                    margin="dense"
                                    fullWidth
                                    name={`entries.${index}.rate_per_qty`}
                                    label="Basic Rate"
                                    variant="soft"
                                    type="number"
                                    value={values.entries[index]?.rate_per_qty}
                                    size="sm"
                                    onChange={handleChange}
                                    error={
                                      getIn(
                                        errors,
                                        `entries.${index}.rate_per_qty`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries.${index}.rate_per_qty`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries.${index}.rate_per_qty`}
                                      />
                                    }
                                  />
                                  <TextField
                                    size="sm"
                                    label="Basic Amount"
                                    name={`entries.${index}.amount`}
                                    type="number"
                                    value={values.entries[index]?.amount}
                                    variant="soft"
                                    onChange={handleChange}
                                    fullWidth
                                    margin="dense"
                                    error={
                                      getIn(
                                        errors,
                                        `entries.${index}.amount`
                                      ) &&
                                      getIn(touched, `entries.${index}.amount`)
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries.${index}.amount`}
                                      />
                                    }
                                  />
                                </div>

                                <FieldArray name="product_location">
                                  {({ remove: removeProductLocation }) => (
                                    <Stack
                                      spacing={1}
                                      direction={"column"}
                                      flexWrap
                                    >
                                      {entry?.inventory_location?.length >
                                        0 && (
                                          <>
                                            <Typography>
                                              Product Location
                                            </Typography>
                                            {entry?.inventory_location?.map(
                                              (location, idx) => {
                                                return (
                                                  <Chip
                                                    variant="outlined"
                                                    color="success"
                                                    key={idx}
                                                    onClick={() => {
                                                      console.log(
                                                        entry?.inventory_location
                                                      );
                                                    }}
                                                    endDecorator={
                                                      <ChipDelete
                                                        color="danger"
                                                        variant="solid"
                                                        onClick={() => {
                                                          // remove current index element
                                                          entry?.inventory_location?.splice(
                                                            idx,
                                                            1
                                                          );

                                                          // reset all values whatever it has to be remaning
                                                          setValues({
                                                            ...values,
                                                          });

                                                        }}
                                                      />
                                                    }
                                                  >
                                                    {location?.alias}
                                                    <Typography
                                                      variant="plain"
                                                      color="primary"
                                                      fontWeight={800}
                                                      sx={{
                                                        marginLeft: 1,
                                                        padding: 0,
                                                      }}
                                                    >
                                                      Qty : {location?.qty}
                                                    </Typography>
                                                  </Chip>
                                                );
                                              }
                                            )}
                                          </>
                                        )}
                                    </Stack>
                                  )}
                                </FieldArray>
                              </Stack>
                            </BaseCard>
                          </Grid>
                        ))}
                    </>
                  )}
                </FieldArray>
              </Grid>
            </Form>
          )}
        </Formik>

      </Box>
      <Dialog ref={productLocationDialogRef} title={"Distribute Your Product"}>
        <LocationComponent
          defaultLocation={formRef.current?.values.branch}
          onSave={distributeProduct}
          availableProductToDistribute={calculateAvailableProductToDistribute}
        />
      </Dialog>
    </>
  );
}
export default OutwardBranchBasicInformationForm;