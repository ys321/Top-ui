import { useRef, useState } from "react";
import { Box } from "@mui/material";
import { EditText } from "src/components/EditText";
import { TextField, Typography, Chip, ChipDelete, Grid, Stack } from "@mui/joy";
import moment from "moment";

import { ProductDropdown } from "src/components/Dropdown/ProductDropdown";
import { BaseCard } from "src/components";
import { AddButton } from "src/components";
import { Dialog } from "src/components/Model";
import {
  createOutwardFromSite,
  outwardSiteValidationSchema,
  updateOutwardFromSite,
} from "./useOutwardSite";

import { FieldArray, Form, Formik, ErrorMessage, getIn } from "formik";
import { LocationDropdown } from "src/components/Dropdown/LocationDropdown";
import OutwardSiteLocation from "./OutwardSiteLocation";
import { useDispatch } from "react-redux";
import SaveButton from "src/components/Button/SaveButton";
import MainButton from "src/components/Button/MainButton";

export default function OutwardSiteForm({ onClose }) {
  let productLocationDialogRef = useRef(null);

  const formRef = useRef();
  const dispatch = useDispatch();

  const [currentEntry, setCurrentEntry] = useState();
  const [outwardSiteAction, setOutwardSiteAction] = useState("CREATE");

  const addProductLocation = ({ index, entry }) => {
    productLocationDialogRef.current?.open();
    setCurrentEntry({
      index: index,
      entry: entry,
    });
  };

  function saveLocation(obj) {
    const indexOf = formRef.current.values.entries[
      currentEntry.index
    ]?.inventory_location?.findIndex((l) => l?.alias === obj?.alias);
    if (indexOf === -1) {
      formRef.current.values.entries[
        currentEntry.index
      ]?.inventory_location.push(obj);
    } else {
      formRef.current.values.entries[currentEntry.index].inventory_location[
        indexOf
      ] = obj;
    }

    console.log(formRef.current.values.entries);
    productLocationDialogRef.current?.close();
    formRef.current.setValues({ ...formRef.current.values });
  }

  const calculateAvailableProductToDistribute = () => {
    const send_qty =
      formRef.current.values.entries[currentEntry.index].send_qty;
    let remaningQuantity = send_qty;
    for (const location of formRef.current.values.entries[currentEntry.index]
      .inventory_location) {
      // todo : diduct values for each qty
      remaningQuantity -= location.qty;
    }
    return remaningQuantity;
  };

  function saveOutwardFromSite(values) {
    switch (outwardSiteAction) {
      case "CREATE":
        dispatch(createOutwardFromSite({ values }))
          .then((res) => {
            console.log("data submitted");
          })
          .catch((e) => {
            console.log(e);
          });
        break;
      case "UPDATE":
        dispatch(updateOutwardFromSite({ values }))
          .then((res) => {
            console.log("data updated");
          })
          .catch((e) => {
            console.log(e);
          });
        break;
    }
  }

  return (
    <>
      <Box margin={2}>
        <Formik
          initialValues={{
            date: moment().utc().tz(moment.tz.guess()).format("YYYY-MM-DD"),
            branch: "",
            site_name: "",
            remarks: "",
            entries: [],
          }}
          innerRef={formRef}
          onSubmit={async (values) => {
            alert("");
            saveOutwardFromSite(values);
            console.log(values);
          }}
          validationSchema={outwardSiteValidationSchema}
        >
          {({ values, errors, handleChange, setValues, touched }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    spacing={3}
                    alignItems={"center"}
                  >
                    <Typography level={"h4"}>Outward form Site</Typography>
                    <SaveButton />
                  </Stack>
                </Grid>

                <Grid item xs={12} md={3}>
                  <EditText
                    name="date"
                    placeholder="Inward Date"
                    onChange={handleChange}
                    value={values.date}
                  />
                  {/* <TextField
                    type="date"
                    margin="dense"
                    fullWidth
                    name="date"
                    label="Inward Date"
                    variant="outlined"
                    value={values.date}
                    onChange={handleChange}
                  /> */}
                </Grid>

                <Grid item xs={12} md={3}>
                  <LocationDropdown
                    props={{
                      name: "branch",
                      placeholder: "Select Branch",
                      size: "md",
                      values: values.branch,
                      onChange: (e) => handleChange(e),
                      error: errors.branch,
                    }}
                    label={"Select Branch"}
                    helperText={errors.branch}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <EditText
                    name="site_name"
                    placeholder="Site Name"
                    onChange={handleChange}
                    value={values.site_name}
                    error={errors.site_name ? true : false}
                    helpertext={errors.site_name}
                  />
                  {/* <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="site_name"
                    label="Site Name"
                    variant="outlined"
                    value={values.site_name}
                    onChange={handleChange}
                    error={errors.site_name ? true : false}
                    helperText={errors.site_name}
                  /> */}
                </Grid>

                <Grid item xs={12} md={3}>
                  <EditText
                    name="remarks"
                    placeholder="Remarks"
                    onChange={handleChange}
                    value={values.remarks}
                    error={errors.remarks ? true : false}
                    helpertext={errors.remarks}
                  />
                  {/* <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="remarks"
                    label="Remarks "
                    variant="outlined"
                    value={values.remarks}
                    onChange={handleChange}
                  /> */}
                </Grid>
              </Grid>

              <Grid container spacing={1} padding={1}>
                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    alignItems={"center"}
                  >
                    {/* <Typography level={"h6"}>Product Detail</Typography>
                    <Button variant="solid" onClick={() => {
                      inwardSiteItemModelRef.current?.open();

                    }} >
                      Add Product
                    </Button> */}
                  </Stack>
                </Grid>
                <FieldArray name="entries">
                  {({ insert, remove, push }) => (
                    <>
                      <>
                        <Grid item xs={12} md={12} marginTop={1}>
                          <Stack
                            spacing={2}
                            direction={"row"}
                            justifyContent={"end"}
                          >
                            <MainButton
                              name={"Add Products"}
                              onClick={() =>
                                push({
                                  id: Math.random(),
                                  product: "",
                                  send_qty: "",
                                  reason: "",
                                  remarks: "",
                                  branch: values?.branch,
                                  inventory_location: [],
                                })
                              }
                              disabled={!values.branch}
                            />
                          </Stack>
                        </Grid>
                      </>
                      {values.entries.length > 0 &&
                        values.entries.map((entry, index) => {
                          const product = `entries[${index}].product`;
                          const send_qty = `entries[${index}].send_qty`;
                          return (
                            <Grid item md={3} xs={12} key={index}>
                              <BaseCard variant="outlined" row>
                                <Stack
                                  sx={{ width: "100%" }}
                                  direction={"column"}
                                >
                                  <Stack
                                    direction={"row"}
                                    alignItems={"center"}
                                    justifyContent={"space-between"}
                                    flexWrap={"wrap"}
                                    mb={2}
                                  >
                                    <Stack direction={"row"} spacing={1}>
                                      <AddButton
                                        variant="soft"
                                        size="sm"
                                        onClick={() => {
                                          addProductLocation({
                                            index: index,
                                            entry: entry,
                                          });
                                        }}
                                        disabled={
                                          // ordered_qty < 1 means we can not disribute
                                          values.entries[index]?.send_qty < 1
                                        }
                                      >
                                        distribute
                                      </AddButton>
                                    </Stack>
                                    <Stack direction={"row"} spacing={1}>
                                      <ChipDelete
                                        sx={{
                                          textAlign: "end",
                                        }}
                                        color="danger"
                                        variant="solid"
                                        onClick={() => {
                                          remove(index);
                                        }}
                                      />
                                    </Stack>
                                  </Stack>

                                  <ProductDropdown
                                    props={{
                                      name: product,
                                      placeholder: "Select Product",
                                      values: entry.product,
                                      onChange: (e) => handleChange(e),
                                      variant: "soft",
                                      size: "sm",
                                    }}
                                    label={
                                      "Select Product Item To Add Outward from Vendor"
                                    }
                                  />
                                  <TextField
                                    margin="dense"
                                    fullWidth
                                    name={send_qty}
                                    label="Send Qty."
                                    variant="soft"
                                    size="sm"
                                    value={entry.send_qty || ""}
                                    onChange={handleChange}
                                    error={
                                      getIn(
                                        errors,
                                        `entries[${index}].send_qty`
                                      ) &&
                                      getIn(
                                        touched,
                                        `entries[${index}].send_qty`
                                      )
                                    }
                                    helperText={
                                      <ErrorMessage
                                        name={`entries[${index}].send_qty`}
                                      />
                                    }
                                  />

                                  <Stack
                                    spacing={1}
                                    direction={"column"}
                                    flexWrap
                                  >
                                    <>
                                      {entry?.inventory_location.length > 0 ? (
                                        <Typography fontWeight={"sm"}>
                                          Product Location
                                        </Typography>
                                      ) : (
                                        <Typography
                                          fontWeight={"sm"}
                                        ></Typography>
                                      )}
                                      {entry?.inventory_location?.map(
                                        (location, idx) => {
                                          return (
                                            <Chip
                                              variant="outlined"
                                              color="success"
                                              key={idx}
                                              onClick={() => {
                                                console.log(
                                                  entry?.inventory_location
                                                );
                                              }}
                                              endDecorator={
                                                <ChipDelete
                                                  color="danger"
                                                  variant="solid"
                                                  onClick={() => {
                                                    values.entries[
                                                      index
                                                    ].inventory_location.splice(
                                                      idx,
                                                      1
                                                    );
                                                    setValues({ ...values });
                                                  }}
                                                />
                                              }
                                            >
                                              {location?.alias}

                                              <Typography
                                                variant="plain"
                                                color="primary"
                                                fontWeight={800}
                                                sx={{
                                                  marginLeft: 1,
                                                  padding: 0,
                                                }}
                                              >
                                                Qty : {location?.qty}
                                              </Typography>
                                            </Chip>
                                          );
                                        }
                                      )}
                                    </>
                                  </Stack>
                                </Stack>
                              </BaseCard>
                            </Grid>
                          );
                        })}
                    </>
                  )}
                </FieldArray>

                <Dialog
                  ref={productLocationDialogRef}
                  title={"Distribute Your Product"}
                >
                  <OutwardSiteLocation
                    defaultValue={formRef.current?.values.branch}
                    onSave={saveLocation}
                    handleChange={handleChange}
                    availableProductToDistribute={
                      calculateAvailableProductToDistribute
                    }
                  />
                </Dialog>
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>
    </>
  );
}
