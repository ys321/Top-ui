import { createAsyncThunk } from "@reduxjs/toolkit";
import { useFormik } from "formik";
import moment from "moment";
import { useDispatch } from "react-redux";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { errorAlert, successAlert, warningAlert } from "src/store/slices/alert.slice";
import { toggleProcess } from "src/store/slices/process.slice";
import * as yup from "yup";

const errorMessage = {
  outward_date: "Please Select Outward Date",
  branch: "Please Select Valid Branch",
  site_name: "Please Enter Site Name",
  remark: "Please Enter Remark",

  //entries message
  product: "Product Not Added",
  send_qty: "Please Provide Valid Received Quentity",
};

const outwardSiteEntriesValidationSchema = yup.object().shape({
  product: yup.number().required(errorMessage.product).typeError(errorMessage.product),
  send_qty: yup.number().integer().required(errorMessage.send_qty).typeError(errorMessage.send_qty),
});

export const outwardSiteValidationSchema = yup.object().shape({
  branch: yup.string().required("Branch is required"),
  site_name: yup.string().required("Site name is required"),
  // remarks: yup.string().required(errorMessage.remarks).typeError(errorMessage.remarks),
  entries: yup.array(yup.object({
    send_qty: yup.number().integer().required(errorMessage.send_qty).typeError(errorMessage.send_qty).min(1, 'You Have to set More Then 0 Quantity'),
})),
});

let entriesInitialValues = {
  product: '',
  location: '',
  received_qty: 0,
}

let initialValues = {
  date: '',
  location: '',
  site_name: '',
  remarks: '',
  entries: [],
  action: 'save'
};

export const outwardSchema = yup.object().shape({
  branch: yup.number().nullable().required(errorMessage.branch).typeError(errorMessage.branch),
  site_name: yup.string().required(errorMessage.site_name).typeError(errorMessage.site_name),
  entries: yup.array(yup.object({
    received_qty: yup.number().integer().required(errorMessage.received_qty).typeError(errorMessage.received_qty).min(1, 'You Have to set More Then 0 Quantity'),
  })),
});

export const createOutwardFromSite = createAsyncThunk(
  "@inwardFromSite/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true
      })
    );
    (async () => {
      const res = await InwardOutwardService.OutwardSite.create(params.values);
      return res;
    })()
      .them((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: 'Outward From Site',
            message: 'Outward From Site Create Successfully'
          })
        )
      })
      .catch((e) => {
        dispatch(
          warningAlert({
            visible: true,
            title: 'Outward From Site Create Failed',
            message: e.error.response.data.details
          })
        )
      })
  }
)

export const updateOutwardFromSite = createAsyncThunk(
  "@outwardFromSite/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true
      })
    );
    (async () => {
      const res = InwardOutwardService.OutwardSite.update(params.values, params.outward_site_id);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: 'Outward From Site',
            message: 'Outward From Site Record Update Successfully'
          })
        )
      })
      .catch((e) => {
        dispatch(
          warningAlert({
            visible: true,
            title: 'Outward From Site Update Failed',
            message: e.error.response.data.details
          })
        )
      })
  }
)

const saveOutwardSite = createAsyncThunk("outwardSite/save", (info, thunk) => {
  const { dispatch } = thunk;
  const { callback, ...params } = info;

  dispatch(
    toggleProcess({
      visible: true,
      open: true,
      loading: true,
    })
  );

  const { action } = params;

  if (action === "save") {
    InwardOutwardService.InwardSite.create(params)
      .then((res) => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );

        dispatch(
          successAlert({
            visible: true,
            title: "New Outward Site",
            message: "New Outward Site has been Saved !",
          })
        );
        callback?.();
      })
      .catch(() => {
        dispatch(
          errorAlert({
            visible: true,
            title: "New Outward Site",
            message: "Failed to save Outward Site :(",
          })
        );
      })
      .finally(() => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );
      });
  }
  if (action === "update") {
    InwardOutwardService.InwardSite.update(params?.id, params)
      .then(() => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );
        dispatch(
          successAlert({
            visible: true,
            title: "Update Outward Site",
            message: "Outward Site has been Saved !",
          })
        );
        callback?.();
      })
      .catch(() => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Update Outward Site",
            message: "Failed to save Outward Site",
          })
        );
      })
      .finally(() => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );
      });
  }
});

export const useOutwardSite = (props) => {
  const { onSuccess, dataObj } = props;
  const dispatch = useDispatch();

  let finalInitValues = initialValues;
  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: outwardSiteValidationSchema,
    validateOnChange: true,
    onSubmit: (values, { ressetForm }) => {
      console.log(values);
      const callback = () => {
        ressetForm?.();
        onSuccess?.();
      };

      const params = { ...values, callback };
      dispatch(saveOutwardSite(params));
    },
  });
  return {
    formik,
    onSave: formik.handleSubmit,
  };
};

export const useOutwardSiteEntries = (props) => {
  const { onSuccess, dataObj } = props;

  let finalInitValues = entriesInitialValues;

  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formikForEntires = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: outwardSiteEntriesValidationSchema,
    validateOnChange: true,
    onSubmit: (values, { resetForm }) => {
      const callback = () => {
        onSuccess?.();
      };
      callback();
      console.log(values);
    },
  });
  return {
    formikForEntires,
    onEntrySave: formikForEntires.handleSubmit,
  };
};