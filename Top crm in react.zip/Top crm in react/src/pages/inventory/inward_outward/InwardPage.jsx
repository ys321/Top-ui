import React from "react";
import { Grid } from "@mui/material";
import TOPButton from "src/components/Button/TopButton";

function InwardPage() {
  return (
    <>
      <Grid container spacing={2} padding={2}>
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Inward From Vendor"}
            variant={"info"}
            link="/inventory/inward-vendor"
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Inward From Branch"}
            variant={"info"}
            link="/inventory/inward-branch"
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Inward From Customer"}
            variant={"info"}
            link="/inventory/inward-customer"
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Inward From Site"}
            variant={"info"}
            link="/inventory/inward-site"
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Outward From Site"}
            variant={"info"}
            link="/inventory/outward-site"
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Outward From Branch"}
            variant={"info"}
            link="/inventory/outward-branch"
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <TOPButton
            text={"Outward From Vendor"}
            variant={"info"}
            link="/inventory/outward-vendor"
          />
        </Grid>
      </Grid>
    </>
  );
}

export default InwardPage;
