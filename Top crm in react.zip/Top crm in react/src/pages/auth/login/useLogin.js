import { useFormik } from "formik";
import AuthStorage from "src/storage/Helpers/AuthStorage";
import * as yup from "yup";
import { useAuth } from "../useAuth";

const loginValidationSchema = yup.object().shape({
  username: yup.string().required("Username is Required"),
  password: yup.string().required("Password is Required"),
});

const initialValues = {
  username: "",
  password: "",
};
export const useLogin = (props) => {
  const { onSuccess } = props;
  const { tryLogin } = useAuth(); 
  const formik = useFormik({
    initialValues,
    enableReinitialize: true,
    validationSchema: loginValidationSchema,
    validateOnChange: false,
    onSubmit: (values, { ressetForm }) => {
      const callback = () => {
        ressetForm?.();
        onSuccess?.();
      };
      callback();
      const params = { ...values, callback };
      AuthStorage.saveData(params);
      tryLogin(params);
    },
  });

  return {
     formik,
     onLogin : formik.handleSubmit
  }
};
