import { Box, Grid, LinearProgress } from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { ProductService } from "src/services/api/ProductService";
import { QueryKeys } from "src/services/queryKey";
import ProductTable from "./ProductTable";
import ProductFilterForm from "./ProductFilterForm";

export default function Test() {
  const [productData, setProductData] = useState();
  const [filterParam, setFilterParams] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchParms, setSearchParams] = useState("");
  console.log(productData);
  console.log(filterParam);
  console.log(searchQuery);
  console.log(searchParms);
  const { isLoading: ProductLoading, refetch: refetchProduct } = useQuery(
    [QueryKeys.getAllProducts],
    async () => {
      return await ProductService.getAll({
        filter: filterParam,
        searchParms: searchParms,
      });
    },
    {
      enabled: true,
      onSuccess: (response) => {
        setProductData(response.data);
      },
      staleTime: 500,
    }
  );
  const filter = ({ code, vendors, category }) => {
    let params = [];

    if (code) {
      params.push(`code=${code}`);
    }
    if (vendors) {
      params.push(`vendors=${vendors}`);
    }
    if (category) {
      params.push(`category=${category}`);
    }

    setFilterParams(params.join("&"));
    setTimeout(() => {
      refetchProduct();
    }, 500);
  };

  const clearFilter = () => {
    setFilterParams("");
  };

  const onSearch = () => {
    if (searchQuery && searchQuery.length > 1) {
      setSearchParams(`search=${searchQuery}`);
    } else {
      setSearchParams("");
    }
  };
  return (
    <>
  

      <Grid container padding={2}>
        <>
          <ProductFilterForm
            onFilter={filter}
            onClear={clearFilter}
            tableData={productData}
            onSearch={onSearch}
            searchQuery={setSearchQuery}
          />
        </>
        <Grid item xs={12} md={12}>
          {ProductLoading ? (
            <Box sx={{ width: "100%" }}>
              <LinearProgress />
            </Box>
          ) : (
            <>
              {productData?.results?.length > 0 ? (
                <ProductTable rows={productData} refreshData={refetchProduct} />
              ) : (
                <NoRecordFound />
              )}
            </>
          )}
        </Grid>
      </Grid>
    </>
  );
}
