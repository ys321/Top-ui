import React from "react";
import {
  Box,
  Card,
  Typography,
  Tooltip,
  ChipDelete,
} from "@mui/joy";
import { Paper } from "@mui/material";

export default function GlobalCard({
  name,
  prepareForDelete,
  prepareForUpdate,
}) {
  return (
    <>
      <Paper style={{ borderRadius: 15 }}>
        <Card
          variant="outlined"
          sx={{
            backgroundColor: "#D9D9D9",
          }}
        >
          <Box
            flexDirection={"row-reverse"}
            sx={{
              display: "flex",
              marginTop: "-30px",
              marginRight: "-25px",
            }}
          >
            <Tooltip title={`Delele ${name.name}`} variant="soft">
              <ChipDelete
                color="danger"
                onClick={() => {
                  prepareForDelete(name);
                }}
              />
            </Tooltip>
          </Box>
          <Tooltip title={`Update ${name.name}`} variant="soft">
            <Typography
              textAlign={"center"}
              level="h5"
              // fontWeight="lg"
              onClick={() => {
                prepareForUpdate(name);
              }}
            >
              {name.name}
            </Typography>
          </Tooltip>
        </Card>
      </Paper>
    </>
  );
}
