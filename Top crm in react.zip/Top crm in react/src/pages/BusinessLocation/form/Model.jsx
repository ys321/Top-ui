import {
  Button,
  Grid,
  Modal,
  ModalClose,
  Sheet,
  TextField,
  Typography,
} from "@mui/joy";

export default function Model({
  open,
  close,
  name,
  textFieldName,
  label,
  inputHandler,
  defaultValue,
  save,
  handleSubmit,
  register,
  errors,
  setValue
}) {
  return (
    <>
      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={close}
        sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            {name}
          </Typography>
          <TextField
            autoFocus
            fullWidth
            margin="dense"
            type={"text"}
            variant={"outlined"}
            id={textFieldName}
            name={textFieldName}
            {...register(textFieldName)}
            label={label}
            onChange={(e) => {
              inputHandler(e.target.value);
            }}
            defaultValue={defaultValue}
            error={errors[textFieldName] ? true : false}
            helperText={errors[textFieldName]?.message}
            {...setValue(textFieldName, defaultValue)}
          />

          <Grid container marginTop={1} spacing={1}>
            <Grid item xs={12} md={6}>
              <Button
                fullWidth
                variant="solid"
                color="success"
                onClick={handleSubmit(save)}
              >
                Save
              </Button>
            </Grid>
            <Grid item xs={12} md={6}>
              <Button fullWidth variant="solid" color="danger" onClick={close}>
                Cancel
              </Button>
            </Grid>
          </Grid>
        </Sheet>
      </Modal>
    </>
  );
}

