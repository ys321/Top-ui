import { useState } from "react";
import { BASE_URL, topApiClient } from "../topApiClient";

export default function TOPAuthentication() {
  const getToken = () => {
    const tokenString = localStorage.getItem("token");
    return tokenString;
  };

  const [token, setToken] = useState(getToken());

  if (token) {
    (async () => {
      await verifyToken({ askForAuthenticate: null });
    })();
  }

  async function verifyToken({ askForAuthenticate }) {
    if (token) {
      await topApiClient
        .get(BASE_URL + "/verify", {
          headers: {
            Authorization: token,
          },
        })
        .catch((response) => {
          setToken(response.httpError !== true);
          if (askForAuthenticate) askForAuthenticate(null);
        });
    }
  }

  const saveToken = (userToken) => {
    localStorage.setItem("token", `Bearer ${userToken}`);
    setToken(`Bearer ${userToken}`);
  };

  const authenticate = async (crendetials) => {
    return topApiClient.post(BASE_URL + "/login", crendetials, {
      "Content-type": "application/json",
    });
  };

  return {
    setToken: saveToken,
    token,
    authenticate,
    verifyToken,
  };
}
