import _ from "lodash";
import { topApiClient } from "src/services/topApiClient";

const business_settings_service = {
    city_service : {
        create: async function (data) {
            const headers = {
                'Content-type': 'application/json'
            }
            return await topApiClient.post(`/city`, data, headers);
        },
        get: async function (id) {
            return await topApiClient.get(`/city/${id}`);        
        },
        update: async function (id, data, _headers = {}) {
            let headers = { 'Content-type': 'multipart/form-data' };
            if (!_.isEmpty(_headers)) {
                headers = _headers;
            }
            return topApiClient.patch(`city/${id}`, data, headers)
        },
        remove: async function (id) {
            return topApiClient.delete(`/city/${id}`);
        },
        getAll: async function() {
            return await topApiClient.get('/cities');
        }
    },

    transport_service : {
        getAll: async function() {
            return await topApiClient.get('/transport-partners')
        }
    }
}

export { business_settings_service };