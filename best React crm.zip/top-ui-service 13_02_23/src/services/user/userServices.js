const { topApiClient, headers } = require("../topApiClient")


const UserService = {
    auth : async (data) => {
        return topApiClient.post('/login', data);
    },

    create : async (data) => {
        return await topApiClient.post('/account/staff', data, { headers : headers });
    },
    getUser : async(id,params) => {
        const url = `/user/${id}`
        const res = await topApiClient.get(url, { params })
        return res.data
    }
}

export default UserService;