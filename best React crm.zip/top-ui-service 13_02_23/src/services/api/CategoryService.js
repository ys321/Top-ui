import { topApiClient } from "src/services/topApiClient";
import _ from "lodash";

const CategoryService = {
  create: async function (data) {
    const headers = {
      "Content-type": "multipart/form-data",
    };
    return await topApiClient.post(`/category`, data, headers);
  },
  update: async function (id, data, _headers = {}) {
    let headers = { "Content-type": "multipart/form-data" };
    if (!_.isEmpty(_headers)) {
      headers = _headers;
    }
    return topApiClient.patch(`/category/${id}`, data, headers);
  },
  destroy: async function (id) {
    return await topApiClient.delete(`/category/${id}`);
  },
  get: async function (id) {
    return await topApiClient.get(`/category/${id}`);
  },
  getAll: async function (filter) {
    let url = `/categories`;
    if (filter) {
      url += `${filter}`;
    }
    return await topApiClient.get(url);
  },

  SubCategoryService: {
    create: async function (data) {
      return topApiClient.post(`/sub-category`, data);
    },
    update: async function (id, data) {
      return topApiClient.patch(`/sub-category/${id}`, data);
    },
    remove: async function (id) {
      return topApiClient.delete(`/sub-category/${id}`);
    },
    get: async function (id) {
      return await topApiClient.get(`/sub-category/${id}`);
    },
    getAll: async function (category, filter) {
      let url = `/category/${category}`;
      return await topApiClient.get(url);
    },
    // getAll: async function (category, filter) {
    //   let url = `/category/${category}/sub-categories`;
    //   if (filter) {
    //     url += filter;
    //   }
    //   return await topApiClient.get(url);
    // },

    AttributeService: {
      create: async function (data) {
        return topApiClient.post(`/product-attribute`, data);
      },
      update: async function (id, data) {
        return topApiClient.patch(`/product-attribute/${id}`, data);
      },
      remove: async function (id) {
        return topApiClient.delete(`/product-attribute/${id}`);
      },
      get: async function (id) {
        return await topApiClient.get(`/product-attribute/${id}`);
      },
      getAll: async function (subcategory) {
        const url = `/sub-category/${subcategory}`;
        return await topApiClient.get(url);
      },
      // getAll: async function (subcategory) {
      //   const url = `/sub-category/${subcategory}/product-attributes`;
      //   return await topApiClient.get(url);
      // },

      getAllValues: async function (attribute) {
        const url = `/product-attribute/${attribute}/values`;
        return await topApiClient.get(url);
      },

      addValue: async function (data) {
        return topApiClient.post(`/attribute-value`, data);
      },
      // addValue: async function (data) {
      //   return topApiClient.post(`/product-attribute-value`, data);
      // },

      updateValue: async function (id, data) {
        return topApiClient.patch(`/attribute-value/${id}`, data);
      },
    },
  },

  CategoryMediaService: {
    create: async function (data) {
      const headers = {
        "Content-type": "multipart/form-data",
      };
      return topApiClient.post(`/category-media`, data, headers);
    },
    get: async function (id) {
      return topApiClient.delete(`/category-media/${id}`);
    },
    remove: async function (id) {
      return topApiClient.delete(`/category-media/${id}`);
    },
    getAll: async function (category) {
      const url = `/category/${category}/category-all-media`;
      return await topApiClient.get(url);
    },
  },

  CategoryVendorLink: {
    update: async function (category, data) {
      const headers = {
        "Content-type": "application/json",
      };
      return await topApiClient.patch(
        `/category-vendor-link/${category}`,
        data,
        headers
      );
    },
    remove: async function (category, data) {
      const headers = {
        "Content-Type": "application/json",
      };
      return await topApiClient.delete(`/category-vendor-link/${category}`, {
        data: JSON.stringify(data),
        headers,
      });
    },
  },
};

export { CategoryService };
