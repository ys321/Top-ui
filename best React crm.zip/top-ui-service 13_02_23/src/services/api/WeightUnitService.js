import { topApiClient } from "src/services/topApiClient";

const headers = {
  "Content-type": "application/json",
};

const WeightUnitService = {
  getAll: async () => {
    return await topApiClient.get(`/product-units`);
  },
  create: async (data) => {
    return await topApiClient.post(`/product-units`, data, headers);
  },
  update: async (id, data) => {
    return topApiClient.patch(`product-unit/${id}`, data, headers);
  },
  remove: async function (id) {
    return topApiClient.delete(`/product-unit/${id}`);
},
};

export default WeightUnitService;
