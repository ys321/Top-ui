import { topApiClient } from "../topApiClient";
import _ from 'lodash';

const LocationService = {
    create: async function (data) {
        const headers = {
            'Content-type': 'multipart/form-data'
        }

        // data.data = {};
        return topApiClient.post(`/business-location`, data, headers)
    },
    update: async function (id, data, _headers = {}) {
        let headers = { 'Content-type': 'multipart/form-data' };
        if (!_.isEmpty(_headers)) {
            headers = _headers;
        }
        return topApiClient.patch(`/business-location/${id}`, data, headers)
    },
    get: async function (id) {
        return await topApiClient.get(`/business-location/${id}`);        
    },
    remove: async function (id) {
        return topApiClient.delete(`/business-location/${id}`);
    },
    getAll: async function() {
        const url = '/business-locations';
        return await topApiClient.get(url);        
    },
    getAllDetails: async function() {
        const url = '/business-locations-details';
        const { data } = await topApiClient.get(url);
        return data;
    },

    FloorService: {
        create: async function (data) {
            return topApiClient.post(`/floor`, data)
        },
        update: async function (id, data) {
            console.log(id);
            return topApiClient.patch(`/floor/${id}`, data)
        },
        get: async function (id) {
            return await topApiClient.get(`/floor/${id}`);        
        },
        remove: async function (id) {
            return topApiClient.delete(`/floor/${id}`);
        },
        getAll: async function(location) {
            const url = `/business-location/${location}/floors`;
            return await topApiClient.get(url);            
        },

        SectionService: {
            create: async function (data) {
                return topApiClient.post(`/section`, data)
            },
            update: async function (id, data) {
                console.log(id);
                return topApiClient.patch(`/section/${id}`, data)
            },
            get: async function (id) {
                return await topApiClient.get(`/section/${id}`);        
            },
            remove: async function (id) {
                return topApiClient.delete(`/section/${id}`);
            },
            getAll: async function(floor) {
                const url = `/floor/${floor}/sections`;
                return await topApiClient.get(url);            
            },

            RackService : {
                create: async function (data) {
                    return topApiClient.post(`/rack`, data)
                },
                update: async function (id, data) {
                    console.log(id);
                    return topApiClient.patch(`/rack/${id}`, data)
                },
                get: async function (id) {
                    return await topApiClient.get(`/rack/${id}`);        
                },
                remove: async function (id) {
                    return topApiClient.delete(`/rack/${id}`);
                },
                getAll: async function(section) {
                    const url = `/section/${section}/racks`;
                    return await topApiClient.get(url);            
                },

                ShelfService : {
                    create: async function (data) {
                        return topApiClient.post(`/shelf`, data)
                    },
                    update: async function (id, data) {
                        console.log(id);
                        return topApiClient.patch(`/shelf/${id}`, data)
                    },
                    get: async function (id) {
                        return await topApiClient.get(`/shelf/${id}`);        
                    },
                    remove: async function (id) {
                        return topApiClient.delete(`/shelf/${id}`);
                    },
                    getAll: async function(rack) {
                        const url = `/rack/${rack}/shelfs`;
                        return await topApiClient.get(url);            
                    },

                    BinServices : {
                        create: async function (data) {
                            return topApiClient.post(`/bin`, data)
                        },
                        update: async function (id, data) {
                            console.log(id);
                            return topApiClient.patch(`/bin/${id}`, data)
                        },
                        get: async function (id) {
                            return await topApiClient.get(`/bin/${id}`);        
                        },
                        remove: async function (id) {
                            return topApiClient.delete(`/bin/${id}`);
                        },
                        getAll: async function(shelf) {
                            const url = `/shelf/${shelf}/bins`;
                            return await topApiClient.get(url);            
                        },
                    }
                }
            }
        },

        
    }
}

export {
    LocationService
}