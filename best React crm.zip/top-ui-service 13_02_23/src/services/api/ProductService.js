import { topApiClient } from '../topApiClient';
import _ from 'lodash';

const ProductService = {
    create: async function (data) {
        const headers = {
            'Content-type': 'application/json'
        }
        return await topApiClient.post(`/product`, data, headers);   
    },
    update: async function ({product, data}) {
        const headers = {
            'Content-type': 'multipart/form-data'
        }
        return await topApiClient.patch(`/product/${product.id}`, data, headers);    
    },
    
    remove: async function (id) {
        return await topApiClient.delete(`/product/${id}`);
    },

    removeProduct: async function (id) {
        return await topApiClient.delete(`/product/${id}/delete`);
    },

    get: async function (id) {
        return await topApiClient.get(`/product/${id}`);
    },
    getAll: async function ({ page, filter }) {

        const params = [];

        if (page) {
            params.push(`page=${page}`);
        }

        let url = '/products';
        // if (page) url += `?page=${page}`;

        if (filter) {
            params.push(filter)
        }       

        url += `?${params.join('&')}`;

        return await topApiClient.get(url);
    },

    getAllForDD: async function () {
        return await topApiClient.get(`/products?all=true&dd=true`);
    },

    ProductUnits: {
        getAll: async function () {
            return await topApiClient.get('/product-units');
        },  
    },

    ProductVendorLink: {
        update: async function (product, data) {
            const headers = {
                'Content-type': 'application/json'
            }
            return await topApiClient.patch(`/product-vendor-link/${product}`, data, headers);
        },
        remove: async function (product, data) {
            const headers = {
                "Content-Type": "application/json",
              };
            return await topApiClient.delete(`/product-vendor-link/${product}`,{
                data : JSON.stringify(data),
                headers
            });
        },

    },

    ProductLocationSerivce : {
        create: async function (data) {
            const headers = {
                'Content-type': 'application/json'
            }
            return topApiClient.post(`/product-location`, data, headers)
        },
        update: async function (id, data, _headers = {}) {
            let headers = { 'Content-type': 'multipart/form-data' };
            if (!_.isEmpty(_headers)) {
                headers = _headers;
            }
            return topApiClient.patch(`/product-location/${id}/update`, data, headers)
        },
        get: async function (id) {
            return await topApiClient.get(`/product-location/${id}`);        
        },
        remove: async function (id) {
            return topApiClient.delete(`/product-location/${id}/delete`);
        },
        getAll: async function() {
            const url = '/product-locations';
            const { data } = await topApiClient.get(url);
            return data;
        }
    },

    ProductMediaService : {
        create: async function (data) {
            const headers = {
                'Content-type': 'multipart/form-data'
            }
            return topApiClient.post(`/product-media`, data, headers)
        },
        get: async function (id) {
            return topApiClient.delete(`/product-media/${id}`)
        },
        remove: async function (id) {
            return topApiClient.delete(`/product-media/${id}`);
        },
        getAll: async function(product) {
            const url = `/product/${product}/product-all-media`;
            return await topApiClient.get(url);            
        }
    },
}

export { ProductService };