import { makeStyles } from "@mui/styles";
import clsx from "clsx";
import { Box } from "@mui/joy";
import { LinearProgress } from "@mui/material";
import { APP_BAR_HEIGHT } from "src/Config/constant";

const useStyles = makeStyles((theme) => ({
  root: {
    height: `calc(100vh - ${APP_BAR_HEIGHT}px)`,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.palette.background.default,
  },
  fullScreen: {
    height: '100vh',
  },
}))

export default function LoadingScreen({ isFullScreen = false }) {

  const classes = useStyles();

  return (
    <div
      className={clsx(
        classes.root, {
        [classes.fullScreen]: isFullScreen,
      }
      )}
    >
      <Box maxWidth={400} width="90%">
        <LinearProgress />
      </Box>
    </div>
  )
}