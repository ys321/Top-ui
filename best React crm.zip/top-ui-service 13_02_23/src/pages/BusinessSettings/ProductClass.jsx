import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ProductClassService } from "src/services/api/ProductClass.service";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import LinearProgress from "@mui/material/LinearProgress";
import { QueryKeys } from "src/services/queryKey";
import { Slide } from "@material-ui/core";
import { useDispatch } from "react-redux";
import {
  createProductClass,
  deleteProductClass,
  updateProductClass,
} from "src/store/slices/BusinessSettings/productClass.slice";
import {
  Divider, 
  Grid,
  Breadcrumbs,
  Link,
  Stack,
  Tooltip,
  Box,
  Typography,
} from "@mui/joy";
import DeleteModel from "src/components/Model/DeleteModel";
import BusinessSettingsModel from "./model/BusinessSettingModel";
import GlobalCard from "./card/BaseCard";
import NoRecordFound from "src/components/Table/NoRecordFound";
import MainButton from "src/components/Button/MainButton";

const productClassValidationSchema = yup.object().shape({
  name: yup.string().required("Product Class is Required"),
});

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function ProductClass() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(productClassValidationSchema),
  });

  const dispatch = useDispatch();

  const [productClassDialog, setProductClassDialog] = useState(false);
  const [productClasses, setProductClasses] = useState([]);
  const [productClass, setProductClass] = useState({});
  const [productClassAction, setProductClassAction] = useState("CREATE");
  const [conformationParams, setConfirmationParams] = useState({ open: false });

  const handleCloseDialog = () => {
    setConfirmationParams({ open: false });
  };

  const { isLoading: productClassLoading, refetch: productClassRefetch } =
    useQuery(
      [QueryKeys.getAllProductClasses],
      async () => {
        return await ProductClassService.getAll();
      },
      {
        onSuccess: (response) => {
          setProductClasses(response.data);
        },
        staleTime: 0,
      }
    );

  function saveProductClass() {
    // eslint-disable-next-line default-case
    switch (productClassAction) {
      case "CREATE":
        dispatch(createProductClass({ productClass }))
          .unwrap()
          .then((response) => {
            hideAndClearProductClassDialog();
            setTimeout(() => {
              productClassRefetch();
            }, 500);
          })
          .catch((error) => {
            console.log(error);
          });
        break;
      case "UPDATE":
        dispatch(updateProductClass({ productClass }))
          .unwrap()
          .then((response) => {
            hideAndClearProductClassDialog();
            setTimeout(() => {
              productClassRefetch();
            }, 500);
          })
          .catch((error) => {
            console.log(error);
          });
        break;
    }
  }

  if (productClassLoading) {
    return (
      <>
        <LinearProgress />
      </>
    );
  }

  function hideAndClearProductClassDialog() {
    setProductClassDialog(false);
    setProductClass({});
    reset();
    setProductClassAction("CREATE");
  }

  function prepareForUpdate(pc) {
    setProductClass(pc);
    setProductClassDialog(true);
    setProductClassAction("UPDATE");
  }
  function productClassInputHandler(e) {
    const { name, value } = e.target;
    if (!value) return;

    setProductClass({
      ...productClass,
      [name]: value,
    });
  }

  function prepareForDelete(pc) {
    setConfirmationParams({
      open: true,
      cencelTitle: "Cancel",
      confrimTitle: "Yes",
      title: "Product Class",
      description: `Are you sure want to delete ${pc.name} ?`,
      confrimHandler: async function () {
        dispatch(deleteProductClass({ pc }))
          .unwrap()
          .then((response) => {
            handleCloseDialog();
            setTimeout(() => {
              productClassRefetch();
            }, 500);
            setProductClass("");
          })
          .catch((e) => {
            console.log(e);
          });
      },
    });
  }

  return (
    <>
      <Grid container spacing={2} padding={2}>
        <Grid>
          <Grid item>
            <Breadcrumbs area-label="breadcrumb">
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/"
              >
                Top Lift
              </Link>
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/business-setting"
              >
                Business Settings
              </Link>
              <Link
                underline="hover"
                color="neutral"
                fontSize="inherit"
                href="/business-setting/product-class"
              >
                Product-Class
              </Link>
            </Breadcrumbs>
          </Grid>
        </Grid>
        <Grid item xs={12} md={11.8}>
          <Stack flexDirection={"row"} justifyContent={"space-between"}>
            <Typography level="h4" fontWeight="lg">
              Product Class
            </Typography>
            <Tooltip title={`Add New Product Class`} variant="soft">
              <MainButton
                name={"Add New"}
                onClick={() => {
                  setProductClassDialog(true);
                }}
              />
            </Tooltip>
          </Stack>
        </Grid>

        <Grid container spacing={2} padding={2}>
          <Grid item xs={12} md={12}>
            <Divider style={{ width: "100%", marginTop: "1px" }} />
          </Grid>
        </Grid>
        <Box sx={{ flexGrow: 1 }}>
          <Grid container flexDirection={"column"} padding={2}>
            <Grid item style={{ marginTop: "10px" }}>
              <Grid
                container
                spacing={{ xs: 2, md: 2 }}
                columns={{ xs: 4, sm: 8, md: 11 }}
              >
                {productClasses && productClasses?.length > 0 ? (
                  <>
                    {productClasses.map((f, index) => {
                      return (
                        <Grid item xs={4} sm={4} md={1} key={index}>
                          <GlobalCard
                            productClassRefetch={productClassRefetch}
                            name={f}
                            prepareForDelete={prepareForDelete}
                            prepareForUpdate={prepareForUpdate}
                          />
                        </Grid>
                      );
                    })}
                  </>
                ) : (
                  <>
                    <NoRecordFound />
                  </>
                )}
              </Grid>
            </Grid>
          </Grid>
        </Box>
        {/* End Grid */}
      </Grid>

      <BusinessSettingsModel
        open={productClassDialog}
        close={() => {
          hideAndClearProductClassDialog();
        }}
        name={"Product Class"}
        textFieldName={"name"}
        label={`Product Class Name`}
        defaultValue={productClass.name}
        inputHandler={productClassInputHandler}
        save={saveProductClass}
        handleSubmit={handleSubmit}
        register={register}
        errors={errors}
      />

      <div>
        <DeleteModel
          open={conformationParams.open}
          close={() => {
            setConfirmationParams({ open: false });
          }}
          title={conformationParams.title}
          description={conformationParams.description}
          cancel={conformationParams.cencelTitle}
          final={conformationParams.confrimHandler}
          final_title={conformationParams.confrimTitle}
        />
      </div>
    </>
  );
}
