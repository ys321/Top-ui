import { useRef } from "react";


import FormControl from '@mui/joy/FormControl';
import FormLabel from '@mui/joy/FormLabel';

import { Button, Link, Option, Select, TextField, Typography,Grid, Stack, Box } from "@mui/joy";
import { Form, Formik } from "formik";
import moment from "moment";
import { useNavigate } from "react-router-dom";
import CRMBasicInfo from "./BasicInquiry";

function CRMPage() {
  const formRef = useRef();
  const navigate = useNavigate();
  console.log(formRef);

  return (
    <>
      <Box >
        <Formik
          initialValues={{
            warehouse: '',
            ref_no: '',
            date: moment().utc().tz(moment.tz.guess()).format("YYYY-MM-DD"),
            site_job_name: '',
            company_name: '',
            billing_name: '',
            customer_name: '',
            phone: '',
            email: '',
            city: '',
            site_name: '',
            billing_address: '',
            site_address: '',
            no_lift: '',
            no_distinct: '',
          }}
          innerRef={formRef}
          onSubmit={async (values) => {
            alert(JSON.stringify(values,null, 2));
            console.log(values);
            navigate(`/crm/basic-info`)
          }}
        >

          {({ values, errors, handleChange, setValues, touched }) => (
            <Form>

              <Grid container spacing={2} padding={2}>
                <Grid item xs={12} md={12}>
                  <Stack direction={'row'} justifyContent={'space-between'} alignItems={'center'}>
                    <Typography level={'h4'}>Lift Inquiry</Typography>
                    {/* <Link href='/crm/basic-info'> */}
                    <Button variant="solid" type="submit">Save</Button>
                    {/* </Link> */}
                  </Stack>
                </Grid>

                <Grid item xs={12} md={3}>
                  <FormControl>
                    <FormLabel name='warehouse' htmlFor="warehouse">
                      Warehouse
                    </FormLabel>
                    <Select defaultValue={values.warehouse} name='warehouse' onChange={handleChange}>
                      <Option value="Warehouse 1">Warehouse 1</Option>
                      <Option value="Warehouse 2">Warehouse 2</Option>
                      <Option value="Warehouse 3">Warehouse 3</Option>
                      <Option value="Warehouse 4">Warehouse 4</Option>
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="ref_no"
                    label="Ref No."
                    variant="outlined"
                    value={values.ref_no}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="date"
                    margin="dense"
                    fullWidth
                    name="date"
                    label="Inward Date"
                    variant="outlined"
                    value={values.date}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3} >
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="site_job_name"
                    label="Site Name / Job No."
                    variant="outlined"
                    value={values.site_job_name}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="company_name"
                    label="Company Name"
                    variant="outlined"
                    value={values.company_name}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="billing_name"
                    label="Billing Name"
                    variant="outlined"
                    value={values.billing_name}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="customer_name"
                    label="Customer Name"
                    variant="outlined"
                    value={values.customer_name}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="phone"
                    label="Phone No."
                    variant="outlined"
                    value={values.phone}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="email"
                    label="Email"
                    variant="outlined"
                    value={values.email}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="city"
                    label="City"
                    variant="outlined"
                    value={values.city}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={3}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="site_name"
                    label="Site Name"
                    variant="outlined"
                    value={values.site_name}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={6}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="billing_address"
                    label="Billing Address"
                    variant="outlined"
                    value={values.billing_address}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={6}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="site_address"
                    label="Site Address"
                    variant="outlined"
                    value={values.site_address}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={6}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="no_lift"
                    label="No of Lift."
                    variant="outlined"
                    value={values.no_lift}
                    onChange={handleChange}
                  />
                </Grid>

                <Grid item xs={12} md={6}>
                  <TextField
                    type="text"
                    margin="dense"
                    fullWidth
                    name="no_distinct"
                    label="No of Distinct."
                    variant="outlined"
                    value={values.no_distinct}
                    onChange={handleChange}
                  />
                </Grid>

              </Grid>
            </Form>
          )}

        </Formik>
      </Box>
      {/* <CRMBasicInfo data={formRef.current.values} /> */}
    </>
  );
}

export default CRMPage;