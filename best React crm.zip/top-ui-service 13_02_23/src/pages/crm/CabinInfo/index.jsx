import { Breadcrumbs, Button, Chip, TextField,Box, Grid, Stack } from "@mui/joy";
import { Form, Formik } from "formik";
import PropTypes from 'prop-types';
import { BaseDropdown } from "src/components/Dropdown/BaseDropdown";
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';

const options = [
    {
        'id': 1,
        'name': 'Test 1'
    },
    {
        'id': 2,
        'name': 'Test 2'
    },
    {
        'id': 3,
        'name': 'Test 3'
    },
]

export const CabinInfo = ({ formData, setFormData, nextStep, prevStep, jumpStep }) => {

    return (
        <>
            <Box margin={2}>
                <Formik
                    initialValues={formData}
                    onSubmit={values => {
                        setFormData(values);
                        nextStep();
                    }}
                // validationSchema={validationSchema}
                >
                    {({ errors, touched, handleChange }) => (
                        <Form >
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={12}>
                                    <Breadcrumbs area-label="breadcrumb">
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(1)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Site Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(2)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Machine Room</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(3)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Door Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(4)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                            endDecorator={<RadioButtonCheckedIcon fontSize="md" />}
                                        >Cabin Info</Chip>
                                    </Breadcrumbs>
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="carInsideWide"
                                        label='Car Inside (in mm) Wide'
                                        defaultValue={formData.carInsideWide}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carInsideWide && errors.carInsideWide}
                                    // helperText={touched.carInsideWide && errors.carInsideWide}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="carInsideDeep"
                                        label='Car Inside (in mm) Deep'
                                        defaultValue={formData.carInsideDeep}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carInsideDeep && errors.carInsideDeep}
                                    // helperText={touched.carInsideDeep && errors.carInsideDeep}
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "carEnclosure",
                                            onChange: handleChange,
                                            defaultValue: formData.carEnclosure ?? '',
                                        }}
                                        options={options}
                                        label='Car Enclosure'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="carCarpetArea"
                                        label='Car Carpet Area'
                                        defaultValue={formData.carCarpetArea}
                                        variant="outlined"
                                        onChange={handleChange}
                                    // error={touched.carCarpetArea && errors.carCarpetArea}
                                    // helperText={touched.carCarpetArea && errors.carCarpetArea}
                                    />
                                </Grid>

                                <Grid item xs={12} md={12}>
                                    <Stack
                                        direction={"row"}
                                        justifyContent={"space-between"}
                                        alignItems={"center"}
                                    >
                                        <Button
                                            variant='outlined'
                                            color="info"
                                            onClick={() => prevStep()}
                                        >
                                            Back To Door Info
                                        </Button>
                                        <Button
                                            type='submit'
                                            variant='outlined'
                                            color='primary'
                                        >
                                            Continue To Controller Info
                                        </Button>
                                    </Stack>
                                </Grid>

                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Box>
        </>
    );
}

CabinInfo.propTypes = {
    formData: PropTypes.object.isRequired,
    setFormData: PropTypes.func.isRequired,
    nextStep: PropTypes.func.isRequired
};

export default CabinInfo;