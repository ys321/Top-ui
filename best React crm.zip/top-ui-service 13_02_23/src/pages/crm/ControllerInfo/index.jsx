import { Breadcrumbs, Button, Chip, TextField,Box, Grid, Stack  } from "@mui/joy";
import { Form, Formik } from "formik";
import PropTypes from 'prop-types';

import { BaseDropdown } from "src/components/Dropdown/BaseDropdown";
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';

const options = [
    {
        'id': 1,
        'name': 'Test 1'
    },
    {
        'id': 2,
        'name': 'Test 2'
    },
    {
        'id': 3,
        'name': 'Test 3'
    },
]

export const ControllerInfo = ({ formData, setFormData, nextStep, prevStep, jumpStep }) => {
    return (
        <>
            <Box margin={2}>
                <Formik
                    initialValues={formData}
                    onSubmit={values => {
                        setFormData(values);
                        nextStep();
                    }}
                // validationSchema={validationSchema}
                >
                    {({ errors, touched, handleChange }) => (
                        <Form >
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={12}>
                                    <Breadcrumbs area-label="breadcrumb">
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(1)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Site Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(2)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Machine Room</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(3)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Door Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(4)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                        >Cabin Info</Chip>
                                        <Chip
                                            color="primary"
                                            onClick={() => {
                                                jumpStep(5)
                                            }}
                                            variant="outlined"
                                            size="lg"
                                            endDecorator={<RadioButtonCheckedIcon fontSize="md" />}
                                        >Controller Info</Chip>
                                    </Breadcrumbs>
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "driveType",
                                            onChange: handleChange,
                                            defaultValue: formData.driveType ?? '',
                                        }}
                                        options={options}
                                        label='Drive Type'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "controllerOperation",
                                            onChange: handleChange,
                                            defaultValue: formData.controllerOperation ?? '',
                                        }}
                                        options={options}
                                        label='Controller Operation'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "ard",
                                            onChange: handleChange,
                                            defaultValue: formData.ard ?? '',
                                        }}
                                        options={options}
                                        label='ARD'
                                    />
                                </Grid>
                                <Grid item xs={12} md={3}>
                                    <BaseDropdown
                                        props={{
                                            name: "olns",
                                            onChange: handleChange,
                                            defaultValue: formData.olns ?? '',
                                        }}
                                        options={options}
                                        label='OLNS'
                                    />
                                </Grid>
                                <Grid item xs={12} md={12}>
                                    <TextField
                                        margin="dense"
                                        fullWidth
                                        name="controlOperation"
                                        label='Control Operation'
                                        // defaultValue={formData.controlOperation}
                                        defaultValue={formData.driveType + formData.controllerOperation + formData.ard + formData.olns || ''}
                                        variant="outlined"
                                        // onChange={handleChange}
                                        disabled
                                    />
                                </Grid>

                                <Grid item xs={12} md={12}>
                                    <Stack
                                        direction={"row"}
                                        justifyContent={"space-between"}
                                        alignItems={"center"}
                                    >
                                        <Button
                                            variant='outlined'
                                            color="info"
                                            onClick={() => prevStep()}
                                        >
                                            Back To Cabin Info
                                        </Button>
                                        <Button
                                            type='submit'
                                            variant='outlined'
                                            color='primary'
                                        >
                                            Continue To Lift Spacification
                                        </Button>
                                    </Stack>
                                </Grid>

                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Box>
        </>
    );
}

ControllerInfo.propTypes = {
    formData: PropTypes.object.isRequired,
    setFormData: PropTypes.func.isRequired,
    nextStep: PropTypes.func.isRequired
}

export default ControllerInfo;