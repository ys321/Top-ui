import { Button, Card,  List, ListItem, Typography,Grid,Link, Stack } from "@mui/joy";
import { KeyboardArrowRight } from "@mui/icons-material";
import React from "react";
function CRMBasicInfo() {
  return (
    <>
      <Grid container spacing={4} padding={2}>
        <Grid item md={4} xs={12}>
          <Card variant="outlined" row sx={{
            '&:hover': { boxShadow: 'md', borderColor: 'neutral.outlinedHoverBorder', cursor: 'pointer' },
          }} >
            <Stack sx={{ width: '100%' }}>
              <Stack direction={'row'} justifyContent={'space-between'} alignItems={'center'}>
                <Typography
                  sx={{ display: 'inline' }}
                  level="h5" component="h5"
                  color="text.primary"
                >
                  Basic Details
                </Typography>
                <Link href='/crm/proposal'>
                  <Button variant="solid">Next</Button>
                </Link>
              </Stack>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
                <List>
                  <ListItem>
                    Warehouse
                    <KeyboardArrowRight />
                    <b>Warehouse 1</b>
                  </ListItem>
                  <ListItem>
                    Site Name
                    <KeyboardArrowRight />
                    <b>Rajkot Top/207</b>
                  </ListItem>
                  <ListItem>
                    Company Name
                    <KeyboardArrowRight />
                    <b>ICEBIT</b>
                  </ListItem>
                  <ListItem>
                    Billing Name
                    <KeyboardArrowRight />
                    <b>ICEBIT Test</b>
                  </ListItem>
                  <ListItem>
                    Customer Name
                    <KeyboardArrowRight />
                    <b>Top India Elevator</b>
                  </ListItem>
                  <ListItem>
                    Phone Number
                    <KeyboardArrowRight />
                    <b>9852364125</b>
                  </ListItem>
                  <ListItem>
                    Email
                    <KeyboardArrowRight />
                    <b>icebit@mail.com</b>
                  </ListItem>
                  <ListItem>
                    City
                    <KeyboardArrowRight />
                    <b>Rajkot</b>
                  </ListItem>
                  <ListItem>
                    Billing Address
                    <KeyboardArrowRight />
                    <b>Rajkot</b>
                  </ListItem>
                  <ListItem>
                    Site Address
                    <KeyboardArrowRight />
                    <b>Indira Circle , sadhu vasvani road , Decora Squere 314, ICEBIT Rajkot.</b>
                  </ListItem>
                  <ListItem>
                    No. of Lift
                    <KeyboardArrowRight />
                    <b>10</b>
                  </ListItem>
                  <ListItem>
                    No. of Distinct Lift
                    <KeyboardArrowRight />
                    <b>5</b>
                  </ListItem>
                </List>
              </div>
            </Stack>
          </Card>
        </Grid>
        {/* <Grid item md={4} xs={12}>
          <Card
            variant="outlined"
            row
            sx={{
              '&:hover': { boxShadow: 'md', borderColor: 'neutral.outlinedHoverBorder', cursor: 'pointer' },
            }}
          >
            <Stack sx={{ width: '100%' }}>
              <Stack direction={'row'} alignItems={'center'} justifyContent={'space-between'} mb={2} >
                <Typography level="h2" fontSize="lg" mb={0.5}>
                  Warehouse 1
                </Typography>
                <Stack direction={'row'} spacing={1}>
                  <Button aria-label="remove" variant="soft" color="info" size="sm" onClick={() => {
                    // materialEntiresDialogRef.current?.open();
                    // formikForEntires.setValues({ ...entry });
                  }}>
                    <EditIcon />
                  </Button>
                  <Button aria-label="remove" variant="soft" color="danger" size="sm" onClick={() => {
                    // removeEntry(index);
                  }}>
                    <DeleteIcon />
                  </Button>
                </Stack>
              </Stack>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Site Name : {'Rajkot Top/207'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Company Name : {'ICEBIT'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Billing Name : {'ICEBIT Test'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Customer Name : {'Top India Elevator'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Phone Number : {'9852364125'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Email : {'icebit@mail.com'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  City : {'Rajkot'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Billing Address : {'Rajkot'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  Site Address : {'sadhu vasvani road , Decora Squere 314, ICEBIT Rajkot.'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  No. of Lift : {'10'}
                </Chip>
                <Chip
                  variant="outlined"
                  color="primary"
                  size="sm"
                  sx={{ pointerEvents: 'none' }}
                >
                  No. of Distinct Lift : {'5'}
                </Chip>
              </div>
            </Stack>
          </Card>
        </Grid> */}
      </Grid>
    </>
  );
}

export default CRMBasicInfo;