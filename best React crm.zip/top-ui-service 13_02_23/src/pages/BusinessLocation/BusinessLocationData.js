import * as yup from "yup";

const errorMessage = {
  name: "Location Name is Required",
  phone: "Phone is Required",
};

export const locationValidationSchema = yup.object().shape({
  name: yup.string().required(errorMessage.name).typeError(errorMessage.name),
  phone: yup
    .string()
    .required(errorMessage.phone)
    .typeError(errorMessage.phone),
});
