import { Box, Button, Grid, Stack, TextField } from "@mui/joy";
import { EditText } from "src/components/EditText";
import { Form, Formik } from "formik";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import AddLocationAltIcon from "@mui/icons-material/AddLocationAlt";
import CancelIcon from "@mui/icons-material/Cancel";
import { FormControl, FormLabel } from "@mui/material";
import SaveButton from "src/components/Button/SaveButton";
import CancelButton from "src/components/Button/CancelButton";

export default function BusinessLocationForm({
  save,
  locationValidationSchema,
  close,
}) {
  return (
    <>
      <Box margin={1}>
        <Formik
          initialValues={{
            name: "",
            address: "",
            phone: "",
            email: "",
            state: "",
            image: "",
          }}
          onSubmit={async (values) => {
            save(values);
          }}
          validationSchema={locationValidationSchema}
        >
          {({ values, errors, handleChange, setFieldValue }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <EditText
                    name="name"
                    placeholder="Name"
                    //   startDecorator={<Phone />}
                    onChange={handleChange}
                    value={values.name}
                    error={errors.name ? true : false}
                    helpertext={errors.name}
                  />

                </Grid>
                <Grid item xs={12} md={6}>
                  <EditText

                    name="address"
                    placeholder="Address"
                    onChange={handleChange}
                    value={values.address}
                    error={errors.address ? true : false}
                    helperText={errors.address}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="address"
                    label="Address"
                    variant="outlined"
                    value={values.address}
                    onChange={handleChange}
                    error={errors.address ? true : false}
                    helperText={errors.address}
                  /> */}
                </Grid>
                <Grid item xs={12} md={6}>
                  <EditText

                    name="phone"
                    placeholder="Phone"
                    onChange={handleChange}
                    value={values.phone}
                    error={errors.phone ? true : false}
                    helperText={errors.phone}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="phone"
                    label="Phone"
                    variant="outlined"
                    value={values.phone}
                    onChange={handleChange}
                    error={errors.phone ? true : false}
                    helperText={errors.phone}
                  /> */}
                </Grid>
                <Grid item xs={12} md={6}>
                  <EditText

                    name="email"
                    placeholder="Email"
                    onChange={handleChange}
                    value={values.email}
                    error={errors.email ? true : false}
                    helperText={errors.email}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="email"
                    label="Email"
                    variant="outlined"
                    value={values.email}
                    onChange={handleChange}
                    error={errors.email ? true : false}
                    helperText={errors.email}
                  /> */}
                </Grid>
                <Grid item xs={12} md={6}>
                  <EditText

                    name="state"
                    placeholder="State"
                    onChange={handleChange}
                    value={values.state}
                    error={errors.state ? true : false}
                    helperText={errors.state}
                  />
                  {/* <TextField
                    size="md"
                    margin="dense"
                    fullWidth
                    name="state"
                    label="State"
                    variant="outlined"
                    value={values.state}
                    onChange={handleChange}
                    error={errors.state ? true : false}
                    helperText={errors.state}
                  /> */}
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormControl>
                    <FormLabel>Image</FormLabel>
                    <Button
                      component="label"
                      variant="outlined"
                      starticon={<UploadFileIcon />}
                      size={"sm"}
                    >
                      Upload Image
                      <input
                        type="file"
                        accept="image/*"
                        hidden
                        onChange={(e) =>
                          setFieldValue("image", e.currentTarget.files[0])
                        }
                      />
                    </Button>
                  </FormControl>
                  <Box>{values?.image?.name}</Box>
                </Grid>

                <Grid item xs={12} md={12}>
                  <Stack
                    direction={"row"}
                    justifyContent={"end"}
                    alignItems={"center"}
                    spacing={2}
                  >
                    <SaveButton startDecorator={<AddLocationAltIcon />} />
                    <CancelButton
                      startDecorator={<CancelIcon />}
                      onClick={close}
                    />
                  </Stack>
                </Grid>
              </Grid>
            </Form>
          )}
        </Formik>
      </Box>
    </>
  );
}
