import { useDispatch } from "react-redux";
import { loginUser } from "src/store/slices/user.slice";

export function useAuth(){
    const dispatch = useDispatch();
    const tryLogin = (params) => {
        dispatch(loginUser(params));
    }

    return {
        tryLogin
    }
}