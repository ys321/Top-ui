import {
  Box,
  Paper,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { Fragment } from "react";
import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";

export default function ProductTable({ rows, refreshData }) {
  return (
    <>
      <Box display={{ md: "block", lg: "block", xl: "block", xs: "none" }}>
        <TableContainer component={Paper} style={{ marginTop: 10 }}>
          <Table sx={{ minWidth: 1280 }} aria-label="customized table">
            <TableHead>
              <TableRow>
                <StyledTableCell >Code</StyledTableCell>
                <StyledTableCell >Product Name</StyledTableCell>
                <StyledTableCell >Product Class</StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.results.map((row, index) => (
                <Fragment key={index}>
                  <StyledTableRow>
                    <StyledTableCell  component="th" scope="row">
                      {row?.code}
                    </StyledTableCell>
                    <StyledTableCell  component="th" scope="row">
                      {row?.name}
                    </StyledTableCell>
                    <StyledTableCell  component="th" scope="row">
                      {row?.product_class?.name}
                    </StyledTableCell>
                  </StyledTableRow>
                </Fragment>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </>
  );
}
