import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MaterialRequestService } from "src/services/api/MaterialRequestService";
import {
  Slide,
  IconButton,
  Paper,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  styled,
  tableCellClasses,
  Table,
  TableBody,
} from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import DeleteIcon from "@mui/icons-material/Delete";
import { useNavigate } from "react-router-dom";
import { QueryKeys } from "src/services/queryKey";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { deleteMaterialRequest } from "src/store/slices/material-request";
import { useDispatch } from "react-redux";
import { Button, Modal, ModalClose, Sheet, Typography,Grid,Chip,Link,Stack} from "@mui/joy";
import MainButton from "src/components/Button/MainButton";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#3d97d4",
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function MaterialRequestListPage() {
  const [page, setPage] = useState(1);
  const [materialRequests, setMaterialRequests] = useState([]);
  const [currentRow, setCurrentRow] = useState();
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  let navigate = useNavigate();

  const { isLoading: materialRequestLoading, refetch: materialRequestRefetch } =
    useQuery(
      [QueryKeys.getAllMaterialRequests, page],
      async () => {
        return await MaterialRequestService.getAll(page);
      },
      {
        onSuccess: (response) => {
          setMaterialRequests(response.data);
        },
        keepPreviousData: true,
        staleTime: 0,
      }
    );

  const dispatch = useDispatch();
  function deleteRow() {
    dispatch(deleteMaterialRequest({ currentRow }))
      .unwrap()
      .then((response) => {
        handleClose();
        setTimeout(() => {
          materialRequestRefetch();
        }, 500);
        setCurrentRow(null);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  if (materialRequestLoading) {
    return (
      <>
        <h1>Loading...</h1>
      </>
    );
  }

  function addMaterialRequest() {
    navigate(`/inventory/material-request/form`);
  }

  return (
    <>
      <Grid container spacing={2} padding={2}>
        <Grid item xs={5} md={2} sm={5}>
          <MainButton name={"Add New"} onClick={addMaterialRequest} />
        </Grid>
      </Grid>

      <Stack spacing={6} direction="row" justifyContent={"flex-end"}>
        <IconButton
          color="primary"
          aria-label="Previous"
          component="button"
          onClick={() => setPage((prevState) => Math.max(prevState - 1, 0))}
          disabled={materialRequests.previous === null}
        >
          <ArrowBackIosIcon /> &nbsp; Previous
        </IconButton>
        <IconButton
          color="primary"
          aria-label="Next"
          component="button"
          onClick={() => setPage((prevState) => prevState + 1)}
          disabled={materialRequests.next === null}
        >
          Next &nbsp; <ArrowForwardIosIcon />
        </IconButton>
      </Stack>

      <Grid container spacing={3} padding={2}>
        <Grid item xs={12} md={12}>
          {materialRequests && materialRequests?.results?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align="center">MR No.</StyledTableCell>
                      <StyledTableCell align="center">Branch</StyledTableCell>
                      <StyledTableCell align="center">Date</StyledTableCell>
                      <StyledTableCell align="center">
                        Contact Person
                      </StyledTableCell>
                      <StyledTableCell align="center">
                        Mobile No.
                      </StyledTableCell>
                      <StyledTableCell align="center">Email</StyledTableCell>
                      <StyledTableCell align="center">Status</StyledTableCell>
                      <StyledTableCell align="center">Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {materialRequests.results.map((mr, index) => {
                      return (
                        <StyledTableRow key={index}>
                          <StyledTableCell align="center">
                            <Link
                              href={`/inventory/material-request/:material_request_id`.replace(
                                ":material_request_id",
                                mr.id
                              )}
                            >
                              {mr.mr_number}
                            </Link>
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {mr.branch?.name}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {mr.date}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {mr.contact_person}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {mr.mobile_no}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {mr.email}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            {mr.status}
                          </StyledTableCell>
                          <StyledTableCell align="center">
                            <IconButton
                              aria-label="delete"
                              size="large"
                              color="error"
                              onClick={() => {
                                handleClickOpen();
                                setCurrentRow(mr);
                              }}
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>

      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={handleClose}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: "md",
            p: 3,
            boxShadow: "lg",
          }}
        >
          <ModalClose
            variant="outlined"
            sx={{
              top: "calc(-1/4 * var(--IconButton-size))",
              right: "calc(-1/4 * var(--IconButton-size))",
              boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
              borderRadius: "50%",
              bgcolor: "background.body",
            }}
          />
          <Typography
            component="h2"
            id="modal-title"
            level="h4"
            textColor="inherit"
            fontWeight="lg"
            mb={1}
          >
            {"Delete Purchase Order"}
          </Typography>
          <Typography
            component={"div"}
            id="modal-desc"
            marginBottom={2}
            textColor="text.tertiary"
          >
            Are you sure want to delete Purchase Order <br />{" "}
            <Chip label={currentRow?.mr_number} />
          </Typography>

          <Grid container spacing={1}>
            <Grid item xs={12} md={6}>
              <Button
                fullWidth
                variant="solid"
                color="success"
                onClick={handleClose}
              >
                No
              </Button>
            </Grid>
            <Grid item xs={12} md={6}>
              <Button
                fullWidth
                variant="solid"
                color="danger"
                onClick={deleteRow}
              >
                Yes
              </Button>
            </Grid>
          </Grid>
        </Sheet>
      </Modal>
    </>
  );
}
