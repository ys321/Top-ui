import { createAsyncThunk } from "@reduxjs/toolkit";
import { useFormik } from "formik";
import { useDispatch } from "react-redux";
import { PurchaseOrderService } from "src/services/api/PurchaseOrderService";
import { errorAlert, successAlert } from "src/store/slices/alert.slice";
import { toggleProcess } from "src/store/slices/process.slice";
import moment from "moment-timezone";
import * as yup from "yup";

const poValidation = yup.object().shape({
  //   vendor: yup.string().required("Required"),
  contact_person: yup.string().required("contact person is required"),
  mobile_no: yup
    .number()
    .typeError("only numbers")
    .required("phone no. is required"),
  email: yup.string().required("email is required"),
});

const errorMessage = {
  vendor: 'Please Select Valid Vendor',
  contact_person: 'Please Provide Contact Person for communication',
  mobile_no: 'Please Provide Contact Number for communication',
  email: 'Please Provide valid Email Address for communication',
  sub_total: 'Sub Total can be valid decimal point numbers only',
  packing_forwarding: 'Packaging & Forwarding',
  other_charge: 'Other Charges can be valid decimal point numbers only',
  frieght_charge: 'Frieght Charges can be valid decimal point numbers only',
  insurance_amount: 'Insurance Amount can be valid decimal point numbers only',
  load_unload_charge: 'Load / Unload can be valid decimal point numbers only',
  discount: 'Discount Amount can be valid decimal point numbers only',
  central_tax: 'Central Tax can be valid decimal point numbers only',
  state_tax: 'Central Tax can be valid decimal point numbers only',
  total: 'Total Amount can be valid decimal point numbers only',
  status: 'Status Can be valid Selection of Purchase Order Status',

  // entires message
  product: 'Please select valid Product',
  ordered_qty: 'Please provide valid ordered quantity',
  basic_rate: 'Basic Rate can be valid decimal point numbers only',
  amount: 'Amount can be valid decimal point numbers only',
  extra_details: 'Remarks / Additional Information should be maximum 255 character long',
  request_no: 'Request Number is automatic generated & can not be modified for any reasons'
}

const purchaseOrderEntiresValidationSchema = yup.object().shape({
  date: yup.date().optional(),
  product: yup.number().required(errorMessage.product).typeError(errorMessage.product),
  ordered_qty: yup.number().integer().required(errorMessage.ordered_qty).typeError(errorMessage.ordered_qty) ,
  basic_rate: yup.number().required(errorMessage.basic_rate).typeError(errorMessage.basic_rate),
  discount: yup.number().optional().typeError(errorMessage.discount),
  amount: yup.number().required(errorMessage.amount).typeError(errorMessage.amount),
  extra_details: yup.string(errorMessage.extra_details).optional().nullable().max(255)
});

let entriesInitialValues = {
  product: '',
  ordered_qty: 0,
  basic_rate: 0,
  discount: 0,
  amount: 0,
  extra_details: ''
}

const purchaseOrderValidationSchema = yup.object().shape({
  vendor: yup.number().required(errorMessage.vendor).min(0).typeError(errorMessage.vendor),
  contact_person: yup.string().required(errorMessage.contact_person),
  mobile_no: yup
    .number()
    .typeError(errorMessage.mobile_no)
    .required(errorMessage.mobile_no),
  email: yup.string().required(errorMessage.email),
  sub_total: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.sub_total),
  packing_forwarding: yup.string().optional().nullable().max(255),
  other_charge: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.other_charge),
  frieght_charge: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.frieght_charge),
  insurance_amount: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.insurance_amount),
  load_unload_charge: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.load_unload_charge),
  discount: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.discount),
  central_tax: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.central_tax),
  state_tax: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.state_tax),
  total: yup.number().optional().nullable().min(0).default(0).typeError(errorMessage.total),
  status: yup.number().optional().nullable().min(0).default(1).typeError(errorMessage.status),
  entries: yup.array().of(purchaseOrderEntiresValidationSchema).min(1, 'One or more products are required for sending Purchase Order to Vendor')
});

let initialValues = {
  vendor: '',
  contact_person: '',
  mobile_no: '',
  email: '',
  remarks: '',
  sub_total: 0,
  packing_forwarding: 0,
  other_charge: 0,
  frieght_charge: 0,
  insurance_amount: 0,
  load_unload_charge: 0,
  discount: 0,
  central_tax: 0,
  state_tax: 0,  
  total: 0,
  entries: [],
  status: 1,
  action: "save",
};

const savePurchaseOrder = createAsyncThunk(
  "purchaseOrder/save",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );

    const { action } = params;
    delete params['action'];
    if (action === "save") {
      PurchaseOrderService.create(params)
        
        .then((response) => {
          dispatch(
            toggleProcess({
              visible: false,
              open: false,
              loading: false,
            })
          );

          dispatch(
            successAlert({
              visible: true,
              title: "Purchase Order",
              message: "Purchase Order has been Saved !",
            })
          );

          callback?.();
        })

        .catch(() => {
          dispatch(
            errorAlert({
              visible: true,
              title: "New Purchase Order",
              message: "Failed to save Purchase Order :(",
            })
          );
        })

        .finally(() => {
          dispatch(
            toggleProcess({
              visible: false,
              open: false,
              loading: false,
            })
          );
        });
    }
    if (action === "update") {
      PurchaseOrderService.update(params?.id, params)
        .then(() => {
          dispatch(
            toggleProcess({
              visible: false,
              open: false,
              loading: false,
            })
          );
          dispatch(
            successAlert({
              visible: true,
              title: "Update Purchase Order",
              message: "Purchase Order has been Saved !",
            })
          );
          callback?.();
        })
        .catch((error) => {
          console.log(error);
          dispatch(
            errorAlert({
              visible: true,
              title: "Update Purchase Order",
              message: "Failed to save Purchase Order",
            })
          );
        })
        .finally(() => {
          dispatch(
            toggleProcess({
              visible: false,
              open: false,
              loading: false,
            })
          );
        });
    }
  }
);

export const usePurchaseOrder = (props) => {
  const { onSuccess, dataObj } = props;
  const dispatch = useDispatch();

  let finalInitValues = initialValues;
  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formik = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: purchaseOrderValidationSchema,
    validateOnChange: true,
    onSubmit: (values, { resetForm }) => {
      
      const callback = () => {
        onSuccess?.();
      };

      const params = { ...values, callback };
      
      dispatch(savePurchaseOrder(params));
    },
  });
  return {
    formik,
    onSave: formik.handleSubmit,
  };
};


export const usePurchaseOrderEntries = (props) => {
  const { onSuccess, dataObj } = props; 

  let finalInitValues = entriesInitialValues;
  if (dataObj) {
    finalInitValues = dataObj;
  }
  const formikForEntires = useFormik({
    initialValues: finalInitValues,
    enableReinitialize: true,
    validationSchema: purchaseOrderEntiresValidationSchema,
    validateOnChange: true,
    onSubmit: (values, { resetForm }) => {
      
      const callback = () => {
        onSuccess?.();
      };

      callback();
    },
  });
  return {
    formikForEntires,
    onEntrySave: formikForEntires.handleSubmit,
  };
}