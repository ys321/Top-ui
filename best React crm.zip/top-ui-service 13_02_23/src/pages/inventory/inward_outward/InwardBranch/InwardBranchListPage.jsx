import _ from "lodash";

import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Grid,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
} from "@mui/material";
import {
  StyledTableCell,
  StyledTableRow,
  Transition,
} from "src/components/Table/TableStyle";
import { useQuery } from "@tanstack/react-query";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import DeleteIcon from "@mui/icons-material/Delete";
import TOPButton from "src/components/Button/TopButton";
import { useDispatch } from "react-redux";
import MainButton from "src/components/Button/MainButton";

function InwardBranchListPage() {
  const navigate = useNavigate();

  const [inwardBranch, setInwardBranch] = useState([]);
  const [currentRow, setCurrentRow] = useState();
  const [open, setOpen] = useState(false);
  const dispatch = useDispatch();

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const { isLoading: InwardBranchLoading, refetch: InwardBranchRefetch } =
    useQuery(
      ["GetAllInwardBranch"],
      async () => {
        return await InwardOutwardService.InwardBranch.getAll();
      },
      {
        onSuccess: (response) => {
          setInwardBranch(response.data);
        },
        staleTime: 0,
      }
    );

  function deleteRow() {
    dispatch({ currentRow })
      .unwrap()
      .then((res) => {
        handleClose();
        setTimeout(() => {
          InwardBranchRefetch();
        }, 500);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  if (InwardBranchLoading) {
    return <>Loading...</>;
  }

  function addInwardBranch() {
    navigate(`/inventory/inward-branch/form`);
  }

  return (
    <>
      <Grid container spacing={1} padding={2}>
        <Grid item xs={12} md={12}>
          <MainButton name={"ADD NEW"} onClick={addInwardBranch} />
        </Grid>
        <Grid item xs={12} md={12}>
          {inwardBranch && inwardBranch?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align={"center"}>Name</StyledTableCell>
                      <StyledTableCell align={"center"}>
                        Address
                      </StyledTableCell>
                      <StyledTableCell align={"center"}>Email</StyledTableCell>
                      <StyledTableCell align={"center"}>
                        Phone No.
                      </StyledTableCell>
                      <StyledTableCell align={"center"}>State</StyledTableCell>
                      <StyledTableCell align={"center"}>Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {inwardBranch?.map((branch, index) => {
                      return (
                        <StyledTableRow>
                          <StyledTableCell align={"center"}>
                            {branch.name}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.address}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.email}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.phone}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.state}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            <IconButton
                              aria-label="delete"
                              size="large"
                              color="error"
                              onClick={() => {
                                handleClickOpen();
                                setCurrentRow(branch);
                              }}
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        aria-describedby="inward-branch-delete-confirm-dailog"
      >
        <DialogTitle>{" Delete Inward From Branch "}</DialogTitle>
        <DialogContent>
          Are You Sure want to delete Inward From Branch <br />{" "}
          <Chip label={currentRow?.id} />
        </DialogContent>
        <DialogActions>
          <TOPButton onClick={deleteRow} variant="danger" text={"Yes"} />
          <TOPButton onClick={handleClose} variant="info" text={"No"} />
        </DialogActions>
      </Dialog>
    </>
  );
}

export default InwardBranchListPage;
