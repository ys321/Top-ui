import _ from "lodash";

import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Grid,
} from "@mui/material";
import {
  StyledTableCell,
  StyledTableRow,
} from "src/components/Table/TableStyle";
import { InwardOutwardService } from "src/services/api/InwardOutwardService";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import NoRecordFound from "src/components/Table/NoRecordFound";
import { useNavigate } from "react-router-dom";
import MainButton from "src/components/Button/MainButton";

function OutwardBranchListPage({ branch }) {
  const [outwardBranch, setOutwardBranch] = useState([]);
  const navigate = useNavigate();

  const { isLoading: OutwardBranchLoading, refetch: OutwardBranchRefetch } =
    useQuery(
      ["getAllOutwardBranch"],
      async () => {
        return await InwardOutwardService.OutwardBranch.getAll();
      },
      {
        onSuccess: (response) => {
          setOutwardBranch(response.data);
        },
        staleTime: 0,
      }
    );

  if (OutwardBranchLoading) {
    return <>Loading...</>;
  }

  function addOutwardBranch() {
    navigate(`/inventory/outward-branch/form`);
  }

  return (
    <>
      <Grid container spacing={1} padding={2}>
        <Grid item xs={12} md={12}>
          <MainButton name={"ADD NEW"} onClick={addOutwardBranch} />
        </Grid>
        <Grid item xs={12} md={12}>
          {outwardBranch && outwardBranch?.length > 0 ? (
            <>
              <TableContainer component={Paper} style={{ marginTop: "15px" }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align={"center"}>Name</StyledTableCell>
                      <StyledTableCell align={"center"}>
                        Address
                      </StyledTableCell>
                      <StyledTableCell align={"center"}>Email</StyledTableCell>
                      <StyledTableCell align={"center"}>
                        Phone No.
                      </StyledTableCell>
                      <StyledTableCell align={"center"}>State</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {outwardBranch?.map((branch, index) => {
                      return (
                        <StyledTableRow>
                          <StyledTableCell align={"center"}>
                            {branch.name}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.address}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.email}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.phone}
                          </StyledTableCell>
                          <StyledTableCell align={"center"}>
                            {branch.state}
                          </StyledTableCell>
                        </StyledTableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <>
              <NoRecordFound />
            </>
          )}
        </Grid>
      </Grid>
    </>
  );
}

export default OutwardBranchListPage;
