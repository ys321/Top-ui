import React, { useState } from "react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { QueryKeys } from "src/services/queryKey";

import { styled } from "@mui/material/styles";
import {
  TableCell,
  tableCellClasses,
  TableRow,
  Slide,
} from "@mui/material";

import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";

import { ProductService } from "src/services/api/ProductService";
import NoRecordFound from "src/components/Table/NoRecordFound";
import {
  Stack,
  Grid,
  Alert,
  Box,
  Button,
  Chip,
  ChipDelete,
  IconButton,
  Modal,
  ModalClose,
  Sheet,
  TextField,
  Typography,
} from "@mui/joy";
import { Form, Formik } from "formik";
import { useRef } from "react";
import ProductLocation from "./ProductLocation";
import * as yup from "yup";
import jsPDF from "jspdf";
import { renderToString } from "react-dom/server";
import ProductCard from "./card/ProductCard";

const errorMessage = {
  opening_stock: "Opening Stock is Required",
};
const inventoryLocationSchema = yup.object().shape({
  floor: yup
    .number()
    .integer()
    .optional()
    .nullable()
    .typeError("Please select valid Floor"),
  section: yup
    .number()
    .integer()
    .optional()
    .nullable()
    .typeError("Please select valid Section"),
  rack: yup
    .number()
    .integer()
    .optional()
    .nullable()
    .typeError("Please select valid Rack"),
  shelf: yup
    .number()
    .integer()
    .optional()
    .nullable()
    .typeError("Please select valid Shelf"),
  bin: yup
    .number()
    .integer()
    .optional()
    .nullable()
    .typeError("Please select valid Bin"),
  qty: yup
    .number()
    .integer()
    .optional()
    .nullable()
    .typeError("Please set valid Quantity for product"),
});
export const stockValidationSchema = yup.object().shape({
  opening_stock: yup.string().required(errorMessage.opening_stock),
  inventory_location: yup
    .array()
    .of(inventoryLocationSchema)
    .min(
      1,
      "You have distribute your product based on your warehouse location"
    ),
});

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#3d97d4",
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },

  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
  gap: "clamp(0px, (100% - 360px + 32px) * 999, 16px)",
  transition: "transform 0.3s, border 0.3s",
  "&:hover": {
    borderColor: theme.vars.palette.primary.outlinedHoverBorder,
    transform: "translateY(-5px)",
    backgroundColor: "#D9E3DA !important",
  },
}));

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function ProductTable({ rows, paginationHelper, successCallback }) {
  const formRef = useRef();
  const productCardRef = useRef();
  const navigate = useNavigate();

  let specifications_string = "";
  const [open, setOpen] = React.useState(false);
  const [openingStockModel, setOpeningStockModel] = useState(false);

  const [currentRow, setCurrentRow] = useState();
  const [currentEntry, setCurrentEntry] = useState();

  const printInvoice = (product) => {
    // const string = renderToString(<Prints product={product} />);
    console.log(product);
    const string = renderToString(
      <>
        <div>
          <h1>TOP INDIA ELEVATOR</h1>
          <p>Address : Metoda, Rajkot</p>

          <ul>
            <li>product Name : {product.name}</li>
            <li>Product Code : {product.code}</li>
          </ul>

          <p>Terms And Notes</p>
          <h3>Thank For Your Valued Business</h3>
        </div>
      </>
    );
    const pdf = new jsPDF();
    pdf.fromHTML(string);
    pdf.save("productTest");
  };

  const Prints = (product) => (
    <div>
      <ul>
        <li>{product.name}</li>
        <li>{product.code}</li>
        {/* <li>line 3</li> */}
      </ul>
    </div>
  );

  const queryClient = useQueryClient();
  const { mutate: deleteRow } = useMutation(
    async () => {
      return await ProductService.remove(currentRow.id);
    },
    {
      onSuccess: (response) => {
        if (response.status === 204) {
          successCallback();
          setCurrentRow(null);
          handleClose();
        }
        queryClient.invalidateQueries([QueryKeys.getAllProducts]);
      },
    }
  );

  const OpeningStockOpen = () => {
    setOpeningStockModel(true);
  };

  const OpeningStockClose = () => {
    setOpeningStockModel(false);
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const calculateAvailableProductToDistribute = () => {
    const opening_stock = formRef?.current?.values?.opening_stock;
    let remaningQuantity = opening_stock;

    formRef.current?.values?.inventory_location?.forEach((e) => {
      remaningQuantity -= e.qty;
    });

    return remaningQuantity;
  };

  function saveLocation(obj) {
    const indexOf = formRef.current.values.inventory_location?.findIndex(
      (l) => l?.alias === obj?.alias
    );

    if (indexOf === -1) {
      formRef.current.values.inventory_location.push(obj);
    } else {
      formRef.current.values.inventory_location[indexOf] = obj;
    }
    console.log(formRef.current.values.inventory_location);
    formRef.current.setValues({ ...formRef.current.values });
  }

  return (
    <>
      {rows.results && rows.results?.length > 0 ? (
        <>
          <Stack spacing={6} direction="row" justifyContent={"flex-end"}>
            <IconButton
              color="primary"
              aria-label="Previous"
              component="button"
              onClick={() =>
                paginationHelper((prevState) => Math.max(prevState - 1, 0))
              }
              disabled={rows.previous === null}
            >
              <ArrowBackIosIcon /> &nbsp; Previous
            </IconButton>
            <IconButton
              color="primary"
              aria-label="Next"
              component="button"
              onClick={() => paginationHelper((prevState) => prevState + 1)}
              disabled={rows.next === null}
            >
              Next &nbsp; <ArrowForwardIosIcon />
            </IconButton>
          </Stack>
          <Grid container spacing={2}>
          {rows.results.map((product, index) => (
            <>
            <Grid item key={index}>
              <ProductCard
                product={product}
                openingStock={openingStockModel}
                setCurrentRow={setCurrentRow}
                setOpeningStockModel={setOpeningStockModel}
              />
              </Grid>
            </>
          ))}
          </Grid>
        </>
      ) : (
        <>
          <NoRecordFound />
        </>
      )}

      {/* 
<Box sx={{ display: "flex", gap: 1.5, mt: "auto" }}>
                      <Grid container spacing={1} justifyContent={"center"}>
                        <Grid item>
                          <Chip
                            color="neutral"
                            onClick={function () {}}
                            size="md"
                            variant="soft"
                          >
                            Category : {product?.category?.name}
                          </Chip>
                        </Grid>
                        <Grid item>
                          <Chip
                            color="neutral"
                            onClick={function () {}}
                            size="md"
                            variant="soft"
                          >
                            Sub Category : {product?.sub_category?.name}
                          </Chip>
                        </Grid>
                        <Grid item>
                          <Chip
                            color="neutral"
                            onClick={function () {}}
                            size="md"
                            variant="soft"
                          >
                            CF : {product?.inventory_unit?.name} {"*"}{" "}
                            {product?.purchase_unit?.name} {"="}{" "}
                            {product?.inventory_unit_value}{" "}
                            {product?.purchase_unit_value} for each item
                          </Chip>
                        </Grid>
                        <Grid item></Grid>
                        <Grid item>
                          <Button
                            variant="soft"
                            onClick={() => {
                              printInvoice(product);
                            }}
                            startDecorator={<AddIcon />}
                          >
                            Print PDF
                          </Button>
                        </Grid>
                      </Grid>
                    </Box> */}

      <div>
        <Modal
          aria-labelledby="modal-title"
          aria-describedby="modal-desc"
          open={openingStockModel}
          onClose={OpeningStockClose}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Sheet
            variant="outlined"
            sx={{
              maxWidth: 700,
              borderRadius: "md",
              p: 3,
              boxShadow: "lg",
            }}
          >
            <ModalClose
              variant="outlined"
              sx={{
                top: "calc(-1/4 * var(--IconButton-size))",
                right: "calc(-1/4 * var(--IconButton-size))",
                boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
                borderRadius: "50%",
                bgcolor: "background.body",
              }}
            />
            <Typography
              component="h2"
              id="modal-title"
              level="h4"
              textColor="inherit"
              fontWeight="lg"
              mb={1}
            >
              {"Opening Stock / Distribute Product"}
            </Typography>

            <Box margin={1}>
              <Formik
                initialValues={{
                  branch: "",
                  product: currentEntry?.product?.id,
                  opening_stock: "",
                  inventory_location: [],
                }}
                innerRef={formRef}
                onSubmit={async (values) => {
                  console.log(values);
                  OpeningStockClose();
                }}
                validationSchema={stockValidationSchema}
              >
                {({ values, errors, handleChange, setValues }) => (
                  <Form>
                    <TextField
                      margin="dense"
                      fullWidth
                      name="opening_stock"
                      label="Opening Stock."
                      variant="soft"
                      value={values.opening_stock || ""}
                      onChange={handleChange}
                      error={errors.opening_stock ? true : false}
                      helperText={errors.opening_stock}
                    />

                    <ProductLocation
                      // defaultValue={formRef.current?.values.branch}
                      onSave={saveLocation}
                      handleChange={handleChange}
                      availableProductToDistribute={
                        calculateAvailableProductToDistribute
                      }
                    />

                    {errors.inventory_location && (
                      <Alert
                        sx={{
                          marginTop: "10px",
                        }}
                        variant="outlined"
                        color={"danger"}
                        style={{ width: "100%" }}
                      >
                        {errors.inventory_location}
                      </Alert>
                    )}

                    <Stack spacing={1} direction={"column"} flexWrap>
                      <>
                        {values?.inventory_location.length > 0 ? (
                          <Typography fontWeight={"sm"}>
                            Product Location
                          </Typography>
                        ) : (
                          <Typography fontWeight={"sm"}></Typography>
                        )}
                        {values?.inventory_location?.map((location, idx) => {
                          return (
                            <Chip
                              variant="outlined"
                              color="success"
                              key={idx}
                              onClick={() => {
                                console.log(values?.inventory_location);
                              }}
                              endDecorator={
                                <ChipDelete
                                  color="danger"
                                  variant="solid"
                                  onClick={() => {
                                    values.inventory_location.splice(idx, 1);
                                    setValues({ ...values });
                                  }}
                                />
                              }
                            >
                              {location?.alias}

                              <Typography
                                variant="plain"
                                color="primary"
                                fontWeight={800}
                                sx={{
                                  marginLeft: 1,
                                  padding: 0,
                                }}
                              >
                                Qty : {location?.qty}
                              </Typography>
                            </Chip>
                          );
                        })}
                      </>
                    </Stack>

                    <Grid container spacing={1} marginTop={2}>
                      <Grid item xs={12} md={6}>
                        <Button
                          fullWidth
                          variant="solid"
                          color="success"
                          type="submit"
                          onLoad={() => {}}
                          // disabled={!values?.opening_stock}
                        >
                          Save
                        </Button>
                      </Grid>
                      <Grid item xs={12} md={6}>
                        <Button
                          fullWidth
                          variant="solid"
                          color="danger"
                          onClick={OpeningStockClose}
                        >
                          No
                        </Button>
                      </Grid>
                    </Grid>
                  </Form>
                )}
              </Formik>
            </Box>
          </Sheet>
        </Modal>
      </div>

      <div>
        <Modal
          aria-labelledby="modal-title"
          aria-describedby="modal-desc"
          open={open}
          onClose={handleClose}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Sheet
            variant="outlined"
            sx={{
              maxWidth: 500,
              borderRadius: "md",
              p: 3,
              boxShadow: "lg",
            }}
          >
            <ModalClose
              variant="outlined"
              sx={{
                top: "calc(-1/4 * var(--IconButton-size))",
                right: "calc(-1/4 * var(--IconButton-size))",
                boxShadow: "0 2px 12px 0 rgba(0 0 0 / 0.2)",
                borderRadius: "50%",
                bgcolor: "background.body",
              }}
            />
            <Typography
              component="h2"
              id="modal-title"
              level="h4"
              textColor="inherit"
              fontWeight="lg"
              mb={1}
            >
              {"Delete Product"}
            </Typography>
            <Typography
              component={"div"}
              id="modal-desc"
              marginBottom={2}
              textColor="text.tertiary"
            >
              Are you sure want to delete product <br />{" "}
              <Chip>{currentRow?.code}</Chip> - <Chip>{currentRow?.name}</Chip>{" "}
              ?
            </Typography>

            <Grid container spacing={1}>
              <Grid item xs={12} md={6}>
                <Button
                  fullWidth
                  variant="solid"
                  color="success"
                  onClick={handleClose}
                >
                  No
                </Button>
              </Grid>
              <Grid item xs={12} md={6}>
                <Button
                  fullWidth
                  variant="solid"
                  color="danger"
                  onClick={deleteRow}
                >
                  Yes
                </Button>
              </Grid>
            </Grid>
          </Sheet>
        </Modal>
      </div>
    </>
  );
}

export default ProductTable;