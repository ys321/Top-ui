import { Box, Grid, Typography } from "@mui/joy";

export default function Dashboard() {
  return (
    <div>
      <Box>
        <Grid container spacing={2} justifyContent={"center"}>
          <Grid item>
            <Typography variant="h2">Top India Elevator Dashboard</Typography>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
}
