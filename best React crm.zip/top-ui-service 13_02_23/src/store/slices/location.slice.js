const { createSlice } = require("@reduxjs/toolkit");

const initialState = {
  locations: [],
};

const locations = createSlice({
  name: 'locations',
  initialState: initialState,
  reducers: {
    setLocations: (state, { payload }) => {
      state.locations = payload;
    },
  },
});

export const { setLocations } = locations.actions;
export const locationReducer = locations.reducer;
