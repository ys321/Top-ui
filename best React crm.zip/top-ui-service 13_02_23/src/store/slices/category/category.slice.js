import { createAsyncThunk } from "@reduxjs/toolkit";
import { CategoryService } from "src/services/api/CategoryService";
import { errorAlert, successAlert, warningAlert } from "../alert.slice";
import { toggleProcess } from "../process.slice";

export const createCategory = createAsyncThunk(
  "@category/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );

    (async () => {
      const CategoryData = new FormData();
      CategoryData.append("name", params.values.name);
      CategoryData.append("description", params.values.description);
      CategoryData.append("identifier", params.values.identifier);
      if (params.values.image) {
        CategoryData.append("image", params.values.image);
      }

      const res = await CategoryService.create(CategoryData);
      return res;
    })()
      .then((res) => {
        dispatch(
          toggleProcess({
            visible: false,
            open: false,
            loading: false,
          })
        );

        dispatch(
          successAlert({
            visible: true,
            title: "Category",
            message: "Category Create Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Category Create Failed",
            message: "Invelid Data !",
          })
        );
      });
  }
);

export const createCategoryVendorLink = createAsyncThunk(
  "@categoryVendor/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const res = await CategoryService.CategoryVendorLink.update(
        params.values.category,
        params.values.vendor
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Category Vendor Link",
            message: "Category Vendor Link Create Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Category Vendor Link Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updateProductCategory = createAsyncThunk(
  "@productCategoryUpdate/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      const CategoryData = new FormData();
      CategoryData.append("name", params.values.name);
      CategoryData.append("description", params.values.description);
      CategoryData.append("identifier", params.values.identifier);
      
      if (params.values?.image.name) {
        CategoryData.append("image", params.values.image,params.values.image.name);
      }

      const res = await CategoryService.update(
        params.values.category,
        CategoryData
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Category",
            message: "Category Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Category Update Failed",
            message: "Invalid Data !",
          })
        );
      });
  }
);

export const deleteProductCategory = createAsyncThunk(
  "@category/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await CategoryService.destroy(params.category.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Category",
            message: "Category Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Category Delete Failed !",
            message: "Category Delete Failed !",
          })
        );
      });
  }
);

export const deleteCategoryVendorLink = createAsyncThunk(
  "@categoryVendorLink/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    console.log(params.category);
    console.log(params.vendor);
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await CategoryService.CategoryVendorLink.remove(params.category, {
        vendor: params.vendor.id,
      });
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Category Vendor Link",
            message: "Category Vendor Link Delete Successfully !",
          })
        );
      })
      .catch((res) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Category Vendor Link Delete Failed",
            message: "Category Vendor Link Delete Failed",
          })
        );
      });
  }
);
