/*** the above section can be removed in future */

import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    categories: []
  }
  
  const categories = createSlice({
    name: 'categories',
    initialState: initialState,
    reducers: {
        setCategories : (state, { payload }) => {
            state.categories = payload;
        }
    }
  });
  
  export const { setCategories } = categories.actions;
  export const categoryReducers = categories.reducer; 