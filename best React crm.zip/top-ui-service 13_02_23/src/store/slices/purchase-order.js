import { createAsyncThunk } from "@reduxjs/toolkit";
import { PurchaseOrderService } from "src/services/api/PurchaseOrderService";
import { errorAlert, successAlert, warningAlert } from "./alert.slice";
import { toggleProcess } from "./process.slice";

export const createPurchaseOrder = createAsyncThunk(
  "@purchaseOrder/create",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.entries === null) {
        console.log(null);
      } else {
        params.purchaseOrder.vendor = params.vendor;
        params.purchaseOrder.status = 1;
        params.purchaseOrder.entries = [];
        params.entries.forEach((entry) => {
          params.purchaseOrder.entries.push({
            product: entry?.product?.id,
            amount: entry?.amount,
            discount: entry?.discount,
            ordered_qty: entry?.ordered_qty,
            extra_details: entry?.extra_details,
            basic_rate: entry.basic_rate,
            // uom: entry?.uom?.id,
          });
        });
      }

      const res = await PurchaseOrderService.create(params.purchaseOrder);
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Purchase Order",
            message: "Purchase Order Create Successfully",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Purchase Order Create Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const updatePurchaseOrder = createAsyncThunk(
  "@purchaseOrder/update",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.vendor) {
        params.purchaseOrder.vendor = params.vendor;
      }
      params.purchaseOrder.status = 2;
      if (params.entries) {
        params.purchaseOrder.entries = [];
        params.entries.forEach((entry) => {
          params.purchaseOrder.entries.push({
            product: entry?.product?.id,
            amount: entry?.amount,
            discount: entry?.discount,
            ordered_qty: entry?.ordered_qty,
            extra_details: entry?.extra_details,
            basic_rate: entry.basic_rate,
            // uom: entry?.uom?.id,
          });
        });
      }
      const res = await PurchaseOrderService.update(
        params.productItem.id,
        params.purchaseOrder
      );
      return res;
    })()
      .then((res) => {
        dispatch(
          successAlert({
            visible: true,
            title: "Purchase Order",
            message: "Purchase Order Update Successfully !",
          })
        );
      })
      .catch((error) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Purchase Order Update Failed",
            message: "Invalid Data",
          })
        );
      });
  }
);

export const deletePurchaseOrder = createAsyncThunk(
  "@purchaseOrder/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      await PurchaseOrderService.delete(params.currentRow.id);
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Purchase Order",
            message: "Purchase Order Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Purchase Order Delete Failed",
            message: "Purchase Order Delete Failed",
          })
        );
      });
  }
);

export const deleteProductItem = createAsyncThunk(
  "@productItem/delete",
  (info, thunk) => {
    const { dispatch } = thunk;
    const { callback, ...params } = info;
    console.log(params.currentRow);

    dispatch(
      toggleProcess({
        visible: true,
        open: true,
        loading: true,
      })
    );
    (async () => {
      if (params.currentRow?.id) {
        await PurchaseOrderService.Item.delete(params.currentRow?.id);
      } else return null;
    })()
      .then((res) => {
        dispatch(
          warningAlert({
            visible: true,
            title: "Purchase Order Item",
            message: "Purchase Order Item Delete Successfully !",
          })
        );
      })
      .catch((e) => {
        dispatch(
          errorAlert({
            visible: true,
            title: "Purchase Order Item Delete Failed",
            message: "Purchase Order Item Delete Failed",
          })
        );
      });
  }
);
