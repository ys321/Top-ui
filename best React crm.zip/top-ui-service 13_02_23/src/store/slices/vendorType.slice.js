import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  vendor_type: [],
};

const vendortypes = createSlice({
  name: 'vendor_type',
  initialState: initialState,
  reducers: {
    setVendorTypes: (state, { payload }) => {
      state.vendor_type = payload;
    },
  },
});

export const { setVendorTypes } = vendortypes.actions;
export const vendorTypeReducer = vendortypes.reducer;
