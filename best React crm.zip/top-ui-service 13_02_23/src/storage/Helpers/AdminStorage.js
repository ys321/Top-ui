import StorageService from "../StorageService"

export const BaseAdminStorageKey = 'top-india-elevator'

export const AdminStorageKeys = {
  API_ENV: 'apiEnv',
  ROLE_OVERRIDE: 'roleOverride',
  MONTHLY_SEGMENT_COUNT_OVERRIDE: 'monthlySegmentCountOverride',
  BUSINESS_DETAILS_REFETCH_INTERVAL_OVERRIDE:
    'businessDetailsRefetchIntervalOverride',
  HTTP_LOGGING: 'httpLogging',
  HTTP_ERROR_LOGGING: 'httpErrorLogging',
  FORM_ERROR_LOGGING: 'formErrorLogging',
  SHOW_QA_DETAILS: 'showQaDetails',
  SELECT_AUTOCOMPLETE_DEBUG: 'selectAutocompleteDebug',
}

export default class AdminStorage {
  static loadData(key = BaseAdminStorageKey) {
    return StorageService.loadJson(key)
  }

  static saveData(data, key = BaseAdminStorageKey) {
    const storage = this.loadData()

    StorageService.saveJson(key, { ...storage, ...data })
  }

  static saveValue(key, value) {
    this.saveData({ [key]: value })
  }

  static getApiEnv() {
    const data = this.loadData() || {}

    return data[AdminStorageKeys.API_ENV]
  }

  static getRoleOverride() {
    const data = this.loadData() || {}

    return data[AdminStorageKeys.ROLE_OVERRIDE] || null
  }

  static getMonthlySegmentCountOverride() {
    const data = this.loadData() || {}

    return data[AdminStorageKeys.MONTHLY_SEGMENT_COUNT_OVERRIDE]
  }

  static getBusinessDetailsRefetchIntervalOverride() {
    const data = this.loadData() || {}

    return data[AdminStorageKeys.BUSINESS_DETAILS_REFETCH_INTERVAL_OVERRIDE]
  }

  static isSettingEnabled(key) {
    const data = this.loadData() || {}

    return data[key] === 1
  }

  static isSettingDisabled(key) {
    const data = this.loadData() || {}

    return data[key] === 0
  }
}
