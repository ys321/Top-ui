import { LinearProgress } from "@mui/material";
import { Navigate } from "react-router-dom";
import useAdminUserDetails from "./userAdminUserDetails";


function AdminGuard({ fallback= null, roles, children }){
    const { userDetailsQuery, userHasRole } = useAdminUserDetails();   
    const { isLoading } = userDetailsQuery

    if(isLoading){
        return <LinearProgress />
    }

    const hasRole = Array.isArray(roles) ? roles.some(userHasRole) : userHasRole(roles);

    if(!hasRole){
        return fallback || <Navigate replace to='/' />
    }

    return children

}

export default AdminGuard;