import PropTypes from "prop-types";
import { Navigate, useLocation } from "react-router-dom";
import { useUserInfo } from "src/Hooks/useUserInfo";
import buildUrlSearchFromObj from "./buildUrlSearchFromObj";

AuthGuard.propTypes = {
  children: PropTypes.node.isRequired,
}

function AuthGuard({ children }) {
  const location = useLocation();
  const authState = useUserInfo();

  if (!authState.isLoggedIn) {
    const redirectUrl = `${location.pathname}${location.search}`
    const urlSearch = buildUrlSearchFromObj({ redirectUrl })

    return <Navigate replace to={`/login${urlSearch}`} />
  }
  return children;
}

export default AuthGuard;
