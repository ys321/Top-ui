import * as yup from "yup";

const InwardOutwardFormValidationSchema = yup.object().shape({
  location: yup.string().required("Location is Required."),
  site_name: yup.string().required("site name is required."),

});

const InwardOutwardItemValidationSchema = yup.object().shape({
  //   Inward Item Validation
  item_code: yup
    .number()
    .required("Item Code is Required")
    .typeError("only Number"),
  item_name: yup
    .string()
    .required("Item Name is Required"),
  order_qty: yup
    .number()
    .required("Order Qty is Required")
    .typeError("only Number"),
  recieved_qty: yup
    .number()
    .required("Recieved Qty is Required")
    .typeError("only Number"),
  rate_per_qty: yup
    .number()
    .required("Rate per Qty is Required")
    .typeError("only Number"),
  uom: yup
    .string()
    .required("UOM is Required"),
  amount: yup
    .number()
    .required("Amount is Required")
    .typeError("only Number"),
});

export {
  InwardOutwardFormValidationSchema,
  InwardOutwardItemValidationSchema,
};
