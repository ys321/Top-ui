import React, { lazy } from "react";
//WAREHOUSE IMPORT
const LocationList = React.lazy(() => import('src/pages/BusinessLocation/BusinessLocationPage'))
const LocationDetailPage = React.lazy(() => import('src/pages/BusinessLocation/BusinessLocationDetails'))
const SectionPage = React.lazy(() => import('src/pages/BusinessLocation/SectionPage'))
const RackPage = React.lazy(() => import('src/pages/BusinessLocation/RackPage'))
const ShelfPage = React.lazy(() => import('src/pages/BusinessLocation/ShelfPage'))
const BinPage = React.lazy(() => import('src/pages/BusinessLocation/BinPage'))

//INVENTORY/PRODUCT IMPORT
const ProductPage = React.lazy(() => import('src/pages/inventory/products/ProductPage'))
const ProductDetails = React.lazy(() => import('src/pages/inventory/products/ProductDetails'))

//INWARD IMPORT
const InwardPage = React.lazy(() => import('src/pages/inventory/inward_outward/InwardPage'))
const InwardBranchBasicInformationForm = React.lazy(() => import('src/pages/inventory/inward_outward/InwardBranch/InwardBranchBasicInformationForm'))
const InwardBranchListPage = React.lazy(() => import('src/pages/inventory/inward_outward/InwardBranch/InwardBranchListPage'))
const InwardSiteForm = React.lazy(() => import('src/pages/inventory/inward_outward/InwardSite/InwardSiteForm'))
// const InwardSiteListPage = React.lazy(() => import('src/pages/inventory/inward_outward/InwardSite/InwardSiteListPage'))
import InwardSiteListPage from "src/pages/inventory/inward_outward/InwardSite/InwardSiteListPage";
const InwardVendorBasicInformationForm = React.lazy(() => import('src/pages/inventory/inward_outward/InwardVendor/InwardVendorBasicInformationForm'))
const InwardListVendorPage = React.lazy(() => import('src/pages/inventory/inward_outward/InwardVendor/InwardListVendorPage'))
const InwardCustomerListPage = React.lazy(() => import('src/pages/inventory/inward_outward/InwardCustomer/InwardCustomerListPage'))
const InwardCustomerForm = React.lazy(() => import('src/pages/inventory/inward_outward/InwardCustomer/InwardCustomerForm'))


//OUTWARD IMPORT
const OutwardBranchBasicInformationForm = React.lazy(() => import('src/pages/inventory/inward_outward/OutwardBranch/OutwardBranchBasicInformationForm'))
const OutwardBranchListPage = React.lazy(() => import('src/pages/inventory/inward_outward/OutwardBranch/OutwardBranchListPage'))
const OutwardSiteForm = React.lazy(() => import('src/pages/inventory/inward_outward/OutwardSite/OutwardSiteForm'))
const OutwardSiteListPage = React.lazy(() => import('src/pages/inventory/inward_outward/OutwardSite/OutwardSiteListPage'))
const OutwardVendorForm = React.lazy(() => import('src/pages/inventory/inward_outward/OutwardVendor/OutwardVendorForm'))
const OutwardVendorListPage = React.lazy(() => import('src/pages/inventory/inward_outward/OutwardVendor/OutwardVendorListPage'))

//CATEGORY MANAGEMENT IMPORT
const CategoryPage = React.lazy(() => import('src/pages/inventory/category/CategoryPage'))
const CategoryDetails = React.lazy(() => import('src/pages/inventory/category/CategoryDetails'))
const SubCategoryDetailPage = React.lazy(() => import('src/pages/inventory/category/sub_category/SubCategoryDetailPage'))

//VENDOR MANAGEMENT IMPORT
const VendorList = React.lazy(() => import('src/pages/vendors/VendorList'))
const VendorDetails = React.lazy(() => import('src/pages/vendors/VendorDetails'))

//PURCHASE ORDER IMPORT
const PurchaseOrderForm = React.lazy(() => import('src/pages/inventory/PurchaseOrders/PurchaseOrderForm'))
const PurchaseOrdersListPage = React.lazy(() => import('src/pages/inventory/PurchaseOrders/PurchaseOrdersListPage'))

//MATERIAL REQUEST IMPORT
const MaterialRequestForm = React.lazy(() => import('src/pages/inventory/MaterialRequest/MaterialRequestForm'))
const MaterialRequestListPage = React.lazy(() => import('src/pages/inventory/MaterialRequest/MaterialRequestListPage'))


//BUSINESS SETTING IMPORT
const BusinessSettings = React.lazy(() => import('src/pages/BusinessSettings/BusinessSettings'))
const CityManagement = React.lazy(() => import('src/pages/BusinessSettings/CityManagement'))
const ProductClass = React.lazy(() => import('src/pages/BusinessSettings/ProductClass'))
const ProductUnit = React.lazy(() => import('src/pages/BusinessSettings/ProductUnit'))
const VendorType = React.lazy(() => import('src/pages/BusinessSettings/VendorType'))

//CRM PAGE IMPORT
const CRMPage = React.lazy(() => import('src/pages/crm'))
const CRMBasicInfo = React.lazy(() => import('src/pages/crm/BasicInquiry'))
const LiftProposal = React.lazy(() => import('src/pages/crm/LiftProposal'))


const NoPageFound = React.lazy(() => import('src/components/NoPageFound'))
const AuthGuard = React.lazy(() => import('./Guards/AuthGuard'))
const Test = React.lazy(() => import('src/pages/Test'))
const Navigate = React.lazy(() => import('react-router-dom'))
const Login = React.lazy(() => import('src/pages/auth/login/index'))

const Dashboard = React.lazy(() => import('src/pages/Dashboard'))
const UserRoles = React.lazy(() => import('./Guards/UserRoles'))
const AdminGuard = React.lazy(() => import('./Guards/AdminGuard'))

export const routes = [
  //STARTING ROUTE
  {
    //after login success, page redirect to dashboard
    path: "/",
    element: (
      // <AuthGuard>
        <Dashboard />
      // </AuthGuard>
    ),
  },
  // {
  //   path: "/login",
  //   element: <Login />,
  // },
  {
    path: "test",
    element: <Test />,
  },

  // WAREHOUSE ROUTES
  {
    path: "/business-location",
    children: [
     
      {
        index : true,
        element: (
            // <AdminGuard
            //   fallback={<Navigate replace to='/' />}
            //   roles={[UserRoles.TOP_ADMIN, UserRoles.TOP_EMPLOYEE]}
            // >
            <LocationList />
            // </AdminGuard>
        ),
      },
      {
        path: ":location_id",
        element: (
          // floor data based on location id or location details
          // <AuthGuard>
            <LocationDetailPage />
          // </AuthGuard>
        ),
      },
      {
        //section data based on floor id
        path: ":location_id/floor/:floor_id",
        element: (
          // <AuthGuard>
            <SectionPage />
          // </AuthGuard>
        ),
      },
      {
        //rack data based on section id
        path: ":location_id/floor/:floor_id/section/:section_id",
        element: (
          // <AuthGuard>
            <RackPage />
          // </AuthGuard>
        ),
      },
      {
        //shelf data based on rack id
        path: ":location_id/floor/:floor_id/section/:section_id/rack/:rack_id",
        element: (
          // <AuthGuard>
            <ShelfPage />
          // </AuthGuard>
        ),
      },
      {
        //bin data based on shelf id
        path: ":location_id/floor/:floor_id/section/:section_id/rack/:rack_id/shelf/:shelf_id",
        element: (
          // <AuthGuard>
            <BinPage />
          // </AuthGuard>
        ),
      },
      {
        path: ":location_id/floor/:floor_id/section/:section_id/rack/:rack_id/shelf/:shelf_id/bin/:bin_id",
        element: (
          // <AuthGuard>
            <BinPage />
          // </AuthGuard>
        ),
      },
    ],
  },

  //INVENTORY/PRODUCT ROUTES
  {
    path: "inventory/product",
    children: [
      {
        index: true,
        element: (
          // <AuthGuard>
            <ProductPage />
          // </AuthGuard>
        ),
      },
      {
        path: ":product_id",
        element: (
          //product details based on product id
          // <AuthGuard>
            <ProductDetails />
          // </AuthGuard>
        ),
      },
    ],
  },

  //INWARD-OUWARD ROUTES
  {
    path: "/inventory/inward-outward",
    children: [
      {
        index: true,
        element: (
          // <AuthGuard>
            <InwardPage />
          // </AuthGuard>
        ),
      },
    ],
  },
  //INWARD VENDOR ROUTE
  {
    path: "/inventory/inward-vendor",
    children: [
      {
        index: true,
        element: <InwardListVendorPage />,
      },
      {
        path: "form",
        element: <InwardVendorBasicInformationForm />,
      },
      {
        path: ":inward_vendor_id",
        element: (
          //inward vendor details based on inward_vendor_id
          <InwardVendorBasicInformationForm />
        ),
      },
    ],
  },
  //INWARD BRANCH ROUTE
  {
    path: "/inventory/inward-branch",
    children: [
      {
        index: true,
        element: <InwardBranchListPage />,
      },
      {
        path: "form",
        element: <InwardBranchBasicInformationForm />,
      },
      
    ],
  },
  //INWARD SITE ROUTE
  {
    path: "/inventory/inward-site",
    children: [
      {
        index: true,
        element: <InwardSiteListPage />,
      },
      {
        path: "form",
        element: <InwardSiteForm />,
      },
      {
        //inward site details based on inward_site_id
        path: ":inward_site_id",
        element: <InwardSiteForm />,
      },
    ],
  },

   //INWARD CUSTOMER ROUTE
   {
    path: "/inventory/inward-customer",
    children: [
      {
        index: true,
        element: <InwardCustomerListPage />,
      },
      {
        path: "form",
        element: <InwardCustomerForm />,
      },
      {
        //inward customer details based on inward_customer_id
        path: ":inward_customer_id",
        element: <InwardCustomerForm />,
      },
    ],
  },

  //OUTWARD ROUTES
  //OUTWARD VENDOR ROUTE
  {
    path: "/inventory/outward-vendor",
    children: [
      {
        index: true,
        element: <OutwardVendorListPage />,
      },
      {
        path: "form",
        element: <OutwardVendorForm />,
      },
      {
        //ouward vendor details based on outward vendor id
        path: ":outward_vendor_id",
        element: <OutwardVendorForm />,
      },
    ],
  },

  //OUTWARD BRANCH ROUTE
  {
    path: "/inventory/outward-branch",
    children: [
      {
        index: true,
        element: <OutwardBranchListPage />,
      },
      {
        path: "form",
        element: <OutwardBranchBasicInformationForm />,
      },
      {
        //outward branch details based on outward branch id
        path: ":outward_branch_id",
        element: <OutwardBranchBasicInformationForm />,
      },
    ],
  },

  //OUTWARD SITE ROUTE
  {
    path: "/inventory/outward-site",
    children: [
      {
        index: true,
        element: <OutwardSiteListPage />,
      },
      {
        path: "form",
        element: <OutwardSiteForm />,
      },
      {
        //ouward site details based on outward site id
        path: ":outward_site_id",
        element: <OutwardSiteForm />,
      },
    ],
  },

  //CATEGORY MANAGEMENT
  {
    path: "inventory/product-category",
    children: [
      {
        index: true,
        element: (
          // <AuthGuard>
            <CategoryPage />
          // </AuthGuard>
        ),
      },
      {
        path: ":category_id",
        element: (
          //product-category details based on category id
          // <AuthGuard>
            <CategoryDetails />
          // </AuthGuard>
        ),
      },
      {
        path: ":category_id/sub-category/:sub_category_id",
        element: (
          //sub category details based on category id
          <SubCategoryDetailPage />
        ),
      },
    ],
  },

  //VENDOR MANAGEMENT
  {
    path: "/vendor",
    children: [
      {
        index: true,
        element: <VendorList />,
      },
      {
        path: ":vendor_id",
        element: (
          //vendor details based on vendor id
          <VendorDetails />
        ),
      },
    ],
  },

  //PURCHASE ORDER
  {
    path: "/inventory/purchase-order",
    children: [
      {
        index: true,
        element: <PurchaseOrdersListPage />,
      },
      {
        path: "form",
        element: <PurchaseOrderForm />,
      },
      {
        //purchase order details based on purchase order id
        path: ":purchase_order_id",
        element: <PurchaseOrderForm />,
      },
    ],
  },

  //MATERIAL REQUEST
  {
    path: "/inventory/material-request",
    children: [
      {
        index: true,
        element: <MaterialRequestListPage />,
      },
      {
        path: "form",
        element: <MaterialRequestForm />,
      },
      {
        //material request details based on material request id
        path: ":material_request_id",
        element: <MaterialRequestForm />,
      },
    ],
  },

  //BUSINESS SETTINGS
  {
    path: "/business-setting",
    children: [
      {
        index: true,
        element: <BusinessSettings />,
      },
      {
        path: "product-class",
        element: <ProductClass />,
      },
      {
        path: "product-unit",
        element: <ProductUnit />,
      },
      {
        path: "vendor-type",
        element: <VendorType />,
      },
      {
        path: "city-management",
        element: <CityManagement />,
      },
    ],
  },

  //CRM
  {
    path: "/crm",
    children: [
      {
        index: true,
        element: <CRMPage />,
      },
      {
        path: "basic-info",
        element: <CRMBasicInfo />,
      },
      {
        path: "proposal",
        element: <LiftProposal />,
      },
    ],
  },

  {
    //if url pattern not matched than redirect to no page found
    path: "*",
    element: <NoPageFound />,
  },
];
