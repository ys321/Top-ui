import React from "react";
import "./App.css";
import { Provider } from "react-redux";
import { store } from "./store/store";
import { TOPAlert } from "./components/Alert/TopAlert";
import { PreProcessors } from "src/storage/PreProcessors";

import ThemeProvider from "./Provider/ThemeProvider";

import { HttpQueryClientProvider } from "src/Provider";

import PropTypes from "prop-types";
import { BrowserRouter } from "react-router-dom";
import { TimeoutLogic } from "./utils/Session/TimeoutLogic";
import AppRoutes from "./AppRoutes";

App.propTypes = {
  router: PropTypes.elementType,
};

function App({ router }) {
  const Router = router || BrowserRouter;
  return (
    <>
      <HttpQueryClientProvider>
        <Provider store={store}>
          <ThemeProvider>
            <TOPAlert />
            <Router ignoreScrollBehavior>
              <PreProcessors />
              <AppRoutes />
              <TimeoutLogic />
            </Router>
          </ThemeProvider>
        </Provider>
      </HttpQueryClientProvider>
    </>
  );
}

export default App;
